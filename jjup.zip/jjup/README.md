# Jj Up

A freelance marketplace. Clients post jobs, freelancers offer services and send proposals, they chat, the client pays through PayPal into escrow, and the freelancer withdraws what they earn. Includes an admin dashboard, a support desk, and privacy settings.

Built with **no dependencies**. It needs only **Node.js 22.5 or newer**. There is nothing to `npm install`.

## What is in it

| Area | What it does |
|---|---|
| Accounts | Sign up with email, phone and password. Email verification code (optional SMS code for phone). Password reset. Optional two-step login with an authenticator app. Account deletion. |
| Jobs and services | Anyone can post. Public posts are searchable by everyone, including visitors who are not logged in. Private posts are link-only. |
| Proposals and hiring | Freelancers send proposals; clients accept or decline. Clients can hire straight from a service. |
| Messages | Direct chat between any two users, with unread counts, blocking, and a "connections only" setting. |
| Payments | PayPal Checkout (PayPal balance, or debit/credit card including Mastercard, handled by PayPal). Money is held in escrow, then released to the freelancer minus your fee. |
| Withdrawals | Freelancers withdraw to their PayPal account through PayPal Payouts. Review-before-send is on by default. |
| Disputes | Either side can open a dispute. Money stays held until an admin pays the freelancer or refunds the client. |
| Support | Users send tickets and reports. Staff reply from the admin dashboard. Users are emailed. |
| Admin dashboard | Stats, users (suspend, roles, force log out), posts (remove), orders (resolve disputes), withdrawals (approve, reject), tickets, reports, email outbox and announcements, platform settings (fee, minimums, maintenance mode), audit log. Roles: `user`, `support` (read plus support actions), `admin` (everything). |
| Privacy | Public or private profile, who can message you, email preferences, blocked users. |
| Email | Every email is stored first, then sent over SMTP with retries, so a provider outage never loses a message. |

## Run it on your computer

```bash
node -v                      # must be 22.5 or newer
ADMIN_EMAIL=you@example.com ADMIN_PASSWORD='a long passphrase here' npm start
# open http://localhost:3000
```

With no settings, PayPal runs in **mock mode** (fake payments, no money) and emails are printed in the terminal. Verification codes are shown on screen. This is only for testing and is refused in production.

Run the automated tests: `npm test` (44 checks covering signup, security, payments, withdrawals, disputes, chat, privacy, support and admin).

Make an admin later: `ADMIN_PASSWORD='...' npm run create-admin -- you@example.com "Your Name"`.

## Go live checklist

1. **Hosting.** Any host that runs Node 22 with a **persistent disk** works. Example files are included: `Dockerfile`, `fly.toml`, `render.yaml`. Use HTTPS and set `APP_URL` to your https address. Set `TRUST_PROXY=1` when you are behind a host proxy, otherwise rate limits treat all visitors as one person.
2. **PayPal.** Create a PayPal **Business** account. At developer.paypal.com create an app, first in **Sandbox**. Put its Client ID and Secret in `PAYPAL_CLIENT_ID` and `PAYPAL_SECRET`, set `PAYPAL_MODE=sandbox`, and test with PayPal sandbox accounts. Then create a **Live** app and switch to `PAYPAL_MODE=live`.
3. **PayPal Payouts.** Withdrawals use the Payouts product. It must be enabled on your Business account (PayPal reviews this). Keep a funded balance, because payouts come from your PayPal balance.
4. **PayPal webhook.** In the app settings add a webhook to `https://your-domain/api/paypal/webhook` for the payment capture reversed, denied and refunded events and for customer disputes. Put its ID in `PAYPAL_WEBHOOK_ID`.
5. **Email.** Pick an SMTP provider (Brevo, Mailgun, Amazon SES, Postmark). Set `SMTP_*` and `MAIL_FROM`. Verify your sending domain (SPF and DKIM) or emails land in spam. Without this, nobody receives verification codes.
6. **First admin.** Set `ADMIN_EMAIL` and `ADMIN_PASSWORD` for the first start, log in, turn on two-step login under Settings, then remove `ADMIN_PASSWORD` from the environment.
7. **Backups.** Run `npm run backup -- /backups/jjup-DATE.db` on a schedule and copy the file somewhere off the server. Test a restore once.
8. **Legal.** The Terms and Privacy pages are drafts. Have a lawyer complete them. Check what your country requires for taking payments, taxes, and holding customer money.

All settings are listed in `.env.example`. The fee, minimum withdrawal, auto-release days, withdrawal review, sign-up switch and maintenance mode are changed in the admin dashboard under Settings.

## How money moves

1. Client accepts a proposal (or hires from a service). An order is created: *awaiting payment*.
2. Client pays through PayPal. The server captures the payment with PayPal and checks the amount, currency and order. Order becomes *in escrow*, with your fee fixed at that moment.
3. Freelancer delivers. Client releases payment, or it releases automatically after the review period (default 7 days).
4. The freelancer's balance rises by the amount minus the fee. The fee is recorded as platform income.
5. Freelancer withdraws to PayPal. An admin approves it (default) and the server sends it with PayPal Payouts. If PayPal refuses, the money returns to the freelancer's balance.

Every movement is written to a ledger. The admin Overview shows fees earned, money held, and money owed to freelancers.

## Security in brief

Passwords use scrypt with a unique salt. Sessions are random tokens stored hashed, in HttpOnly cookies. Logins lock for 15 minutes after 5 failures. Signup and login do not reveal which emails have accounts. Every state-changing request needs a custom header and a same-site origin. Strict content security policy. All database access uses parameters. Card details never reach this server. Money, role and settings changes are written to the audit log. Admin sessions last 12 hours.

## Known limits (be aware before launch)

- **Not tested against live PayPal here.** Everything was tested in mock mode. The PayPal code follows PayPal's Orders v2 and Payouts APIs, but you must run a full sandbox test before accepting real money.
- **One server.** The database is SQLite on one disk. That is fast and reliable for a young marketplace (thousands of users). To run several servers worldwide, move to PostgreSQL. The tables are simple, so this is a contained job.
- **Mastercard** is accepted through PayPal's card option, not directly. Withdrawals go to PayPal only.
- **Email is outgoing only.** Users receive notification emails, but there is no inbox. Replying to a notification email does not post a message. Users reply inside Jj Up.
- **Email sending** was tested against a simulated mail server only. The encrypted connection paths (STARTTLS and port 465) follow the standard but were not run against a real provider. Send yourself a test signup before launch.
- **Phone SMS** verification uses Twilio and is untested. Without it, the phone number is collected but not verified.
- Currency is USD, the site is English only, and there are no file uploads, ratings or reviews yet.
- Rate limits are kept in memory per server and reset on restart.
