'use strict';
// Makes a consistent copy of the database while the site is running.
// Usage: npm run backup -- /path/to/backups/jjup-2026-10-29.db
const path = require('node:path');
const { db } = require('../server/lib/db');
const dest = path.resolve(process.argv[2] || `jjup-backup-${new Date().toISOString().slice(0, 10)}.db`);
db.exec(`VACUUM INTO '${dest.replace(/'/g, "''")}'`);
console.log('Backup written to', dest);
