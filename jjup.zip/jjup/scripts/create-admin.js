'use strict';
// Usage: ADMIN_PASSWORD='long password here' npm run create-admin -- you@example.com "Your Name"
// If the account exists it is promoted to admin. The password is read from ADMIN_PASSWORD
// so it never appears in shell history as an argument.
const { get, run, now, audit } = require('../server/lib/db');
const A = require('../server/lib/auth');

(async () => {
  const email = (process.argv[2] || '').toLowerCase();
  const name = process.argv[3] || 'Admin';
  const pw = process.env.ADMIN_PASSWORD;
  if (!email || !email.includes('@')) { console.error('Give an email: npm run create-admin -- you@example.com "Your Name"'); process.exit(1); }
  const existing = get('SELECT * FROM users WHERE email=?', email);
  if (existing) {
    run("UPDATE users SET role='admin', status='active', email_verified=1 WHERE id=?", existing.id);
    audit(null, 'admin_promote_cli', email, '', '');
    console.log('Promoted existing account to admin:', email);
    return;
  }
  if (!pw) { console.error('Set ADMIN_PASSWORD (at least 10 characters) in the environment.'); process.exit(1); }
  const problem = A.passwordProblem(pw, email);
  if (problem) { console.error('Password rejected:', problem); process.exit(1); }
  run("INSERT INTO users(email,phone,name,pw_hash,role,email_verified,status,created_at) VALUES(?,?,?,?,'admin',1,'active',?)", email, '', name, await A.hashPassword(pw), now());
  audit(null, 'admin_create_cli', email, '', '');
  console.log('Admin created:', email);
})();
