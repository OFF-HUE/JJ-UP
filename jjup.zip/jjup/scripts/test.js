'use strict';
// End-to-end test. Starts a real server on a temporary database in simulated-PayPal mode
// and walks through the whole product as several different people.
const { spawn } = require('node:child_process');
const path = require('node:path');
const fs = require('node:fs');
const os = require('node:os');
const assert = require('node:assert/strict');

const PORT = 3200 + Math.floor(Math.random() * 500);
const BASE = `http://localhost:${PORT}`;
const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'jjup-'));
const ADMIN = { email: 'boss@example.com', password: 'Correct-Horse-9' };

class Client {
  constructor() { this.cookie = ''; }
  async req(method, url, body, extraHeaders = {}) {
    const headers = { 'x-requested-with': 'jjup', ...extraHeaders };
    if (body !== undefined) headers['content-type'] = 'application/json';
    if (this.cookie) headers.cookie = this.cookie;
    const r = await fetch(BASE + url, { method, headers, body: body === undefined ? undefined : JSON.stringify(body) });
    const sc = r.headers.get('set-cookie');
    if (sc) this.cookie = sc.split(';')[0].endsWith('=') ? '' : sc.split(';')[0];
    const text = await r.text();
    let json; try { json = JSON.parse(text); } catch (_) { json = text; }
    return { status: r.status, body: json, headers: r.headers };
  }
  get(u) { return this.req('GET', u); }
  post(u, b = {}) { return this.req('POST', u, b); }
}
async function ok(p, msg) { const r = await p; assert.equal(r.status, 200, `${msg || ''} -> ${r.status} ${JSON.stringify(r.body)}`); return r.body; }
async function fails(p, status, msg) { const r = await p; assert.equal(r.status, status, `${msg || ''} expected ${status} got ${r.status} ${JSON.stringify(r.body)}`); return r.body; }

let passed = 0;
const step = async (name, fn) => { try { await fn(); passed++; console.log('  ok  ' + name); } catch (e) { console.log('FAIL  ' + name + '\n      ' + (e.message || e)); process.exitCode = 1; throw e; } };

async function signup(c, name, email, phone, mode) {
  const s = await ok(c.post('/api/auth/signup', { name, email, phone, password: 'Sturdy-Pass-42', mode }), 'signup');
  assert.ok(s.devCodes && s.devCodes.email, 'dev code present in dev mode');
  const v = await ok(c.post('/api/auth/verify', { email, code: s.devCodes.email }), 'verify');
  return v.user;
}

(async () => {
  const srv = spawn(process.execPath, ['--disable-warning=ExperimentalWarning', path.join(__dirname, '..', 'server', 'index.js')], {
    env: { ...process.env, PORT: String(PORT), DB_PATH: path.join(dir, 't.db'), ADMIN_EMAIL: ADMIN.email, ADMIN_PASSWORD: ADMIN.password, NODE_ENV: 'development', PAYPAL_MODE: 'mock' },
    stdio: ['ignore', 'pipe', 'pipe'],
  });
  let log = '';
  srv.stdout.on('data', (d) => (log += d)); srv.stderr.on('data', (d) => (log += d));
  for (let i = 0; i < 50; i++) { try { await fetch(BASE + '/api/config'); break; } catch (_) { await new Promise((r) => setTimeout(r, 100)); } }

  const anon = new Client(), hodan = new Client(), abdi = new Client(), admin = new Client(), eve = new Client();
  let hodanU, abdiU, postId, orderId, propId;
  try {
    console.log('Security');
    await step('static page and security headers', async () => {
      const r = await fetch(BASE + '/');
      assert.equal(r.status, 200);
      assert.match(r.headers.get('content-security-policy') || '', /frame-ancestors 'none'/);
      assert.equal(r.headers.get('x-content-type-options'), 'nosniff');
    });
    await step('path traversal is blocked', async () => {
      const r = await fetch(BASE + '/..%2f..%2fetc%2fpasswd'); assert.ok(!(await r.text()).includes('root:'), 'no system file leaked');
      const r2 = await fetch(BASE + '/%2e%2e/package.json'); assert.equal(r2.status, 404);
      const r3 = await fetch(BASE + '/..%2fserver%2fconfig.js'); assert.ok(!(await r3.text()).includes('PAYPAL_SECRET'), 'no source leaked');
    });
    await step('writes without the CSRF header are refused', async () => {
      const r = await fetch(BASE + '/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json' }, body: '{}' });
      assert.equal(r.status, 403);
    });
    await step('cross-site Origin is refused', async () => {
      const r = await fetch(BASE + '/api/auth/login', { method: 'POST', headers: { 'content-type': 'application/json', 'x-requested-with': 'jjup', origin: 'https://evil.example' }, body: '{}' });
      assert.equal(r.status, 403);
    });
    await step('weak passwords are rejected', async () => {
      const b = await fails(anon.post('/api/auth/signup', { name: 'Test', email: 'weak@example.com', phone: '+252611111111', password: 'short' }), 400);
      assert.match(b.error, /10 characters/);
      await fails(anon.post('/api/auth/signup', { name: 'Test', email: 'weak@example.com', phone: '+252611111111', password: 'password123' }), 400);
    });
    await step('anonymous users cannot reach private or admin routes', async () => {
      await fails(anon.get('/api/wallet'), 401); await fails(anon.get('/api/admin/stats'), 401); await fails(anon.get('/api/orders'), 401);
    });

    console.log('Accounts');
    await step('signup, verify and log in (client)', async () => {
      hodanU = await signup(hodan, 'Hodan Ali', 'hodan@example.com', '+252 61 555 0123', 'client');
      assert.equal(hodanU.email_verified, true);
      const me = await ok(hodan.get('/api/me')); assert.equal(me.user.id, hodanU.id);
      assert.equal(JSON.stringify(me).includes('pw_hash'), false, 'no password hash in API');
    });
    await step('freelancer account', async () => { abdiU = await signup(abdi, 'Abdi Warsame', 'abdi@example.com', '+252 61 555 0456', 'freelancer'); });
    await step('login needs the right password and locks after repeated failures', async () => {
      const c = new Client();
      await fails(c.post('/api/auth/login', { email: 'hodan@example.com', password: 'wrong-password-1' }), 401);
      for (let i = 0; i < 4; i++) await c.post('/api/auth/login', { email: 'hodan@example.com', password: 'wrong-password-1' });
      await fails(c.post('/api/auth/login', { email: 'hodan@example.com', password: 'Sturdy-Pass-42' }), 429, 'locked');
    });
    await step('unknown email gives the same error as a wrong password', async () => {
      const b = await fails(new Client().post('/api/auth/login', { email: 'nobody@example.com', password: 'whatever-1234' }), 401);
      assert.equal(b.error, 'Email or password is not correct.');
    });
    await step('signup with an existing email does not reveal it', async () => {
      const s = await ok(new Client().post('/api/auth/signup', { name: 'Imposter', email: 'hodan@example.com', phone: '+252611111111', password: 'Sturdy-Pass-42' }));
      assert.equal(s.devCodes, undefined);
    });
    await step('password reset works and logs out other sessions', async () => {
      const f = await ok(new Client().post('/api/auth/forgot', { email: 'abdi@example.com' }));
      const c = new Client();
      await ok(c.post('/api/auth/reset', { email: 'abdi@example.com', code: f.devCodes.email, password: 'Brand-New-Pass-77' }));
      const me = await ok(abdi.get('/api/me')); assert.equal(me.user, null, 'old session ended');
      await ok(abdi.post('/api/auth/login', { email: 'abdi@example.com', password: 'Brand-New-Pass-77' }));
    });
    await step('two-step login with an authenticator code', async () => {
      const A = require('../server/lib/auth');
      const s = await ok(abdi.post('/api/2fa/setup'));
      await ok(abdi.post('/api/2fa/enable', { code: A.totpAt(s.secret, Math.floor(Date.now() / 30000)) }));
      const c = new Client();
      const r1 = await ok(c.post('/api/auth/login', { email: 'abdi@example.com', password: 'Brand-New-Pass-77' }));
      assert.equal(r1.needTotp, true);
      assert.equal((await ok(c.get('/api/me'))).user, null);
      await fails(c.post('/api/auth/login', { email: 'abdi@example.com', password: 'Brand-New-Pass-77', totp: '000000' }), 401);
      await ok(c.post('/api/auth/login', { email: 'abdi@example.com', password: 'Brand-New-Pass-77', totp: A.totpAt(s.secret, Math.floor(Date.now() / 30000)) }));
      await ok(abdi.post('/api/2fa/disable', { password: 'Brand-New-Pass-77', code: A.totpAt(s.secret, Math.floor(Date.now() / 30000)) }));
    });

    console.log('Marketplace');
    await step('client posts a job, everyone (even logged out) can see it', async () => {
      const r = await ok(hodan.post('/api/posts', { kind: 'job', title: 'Landing page for a coffee roastery', category: 'Development', priceType: 'fixed', amount: '350', description: 'One page site with product list and an order button, Somali and English.' }));
      postId = r.id;
      const list = await ok(anon.get('/api/posts?kind=job'));
      assert.ok(list.posts.some((p) => p.id === postId));
    });
    await step('search is safe against SQL injection and wildcards', async () => {
      const r = await ok(anon.get("/api/posts?kind=job&q=" + encodeURIComponent("' OR 1=1 --")));
      assert.equal(r.posts.length, 0);
      const r2 = await ok(anon.get('/api/posts?kind=job&q=coffee')); assert.equal(r2.posts.length, 1);
      const r3 = await ok(anon.get('/api/posts?kind=job&q=%25')); assert.equal(r3.posts.length, 0);
    });
    await step('validation: bad amount and short description are rejected', async () => {
      await fails(hodan.post('/api/posts', { kind: 'job', title: 'Valid title here', category: 'Design', priceType: 'fixed', amount: '-5', description: 'x'.repeat(30) }), 400);
      await fails(hodan.post('/api/posts', { kind: 'job', title: 'Valid title here', category: 'Design', priceType: 'fixed', amount: '10', description: 'short' }), 400);
    });
    await step('private (link only) posts are not listed', async () => {
      const r = await ok(hodan.post('/api/posts', { kind: 'service', title: 'Hidden service offer', category: 'Design', priceType: 'fixed', amount: '20', description: 'Only people with the link can see this one.', visibility: 'unlisted' }));
      const list = await ok(anon.get('/api/posts?kind=service')); assert.ok(!list.posts.some((p) => p.id === r.id));
      await ok(anon.get('/api/posts/' + r.id));
    });
    await step('freelancer sends a proposal; cannot propose twice or on own job', async () => {
      await fails(hodan.post(`/api/posts/${postId}/proposals`, { cover: 'x'.repeat(30), price: '300', days: 5 }), 400);
      const p = await ok(abdi.post(`/api/posts/${postId}/proposals`, { cover: 'I have built many sites like this and can start today.', price: '300', days: 6 }));
      propId = p.id;
      await fails(abdi.post(`/api/posts/${postId}/proposals`, { cover: 'I have built many sites like this and can start today.', price: '300', days: 6 }), 400);
    });
    await step("a stranger cannot accept someone else's proposal", async () => {
      await signup(eve, 'Eve Mallory', 'eve@example.com', '+252 61 555 0999', 'client');
      await fails(eve.post(`/api/proposals/${propId}/accept`), 404);
    });
    await step('client accepts and an order is created', async () => {
      const r = await ok(hodan.post(`/api/proposals/${propId}/accept`)); orderId = r.orderId;
      const o = await ok(hodan.get('/api/orders/' + orderId));
      assert.equal(o.status, 'awaiting_payment'); assert.equal(o.amountCents, 30000);
      await fails(eve.get('/api/orders/' + orderId), 404);
    });

    console.log('Payments');
    await step('only the client can pay; PayPal order is created', async () => {
      await fails(abdi.post(`/api/orders/${orderId}/pay/create`), 403);
      const c = await ok(hodan.post(`/api/orders/${orderId}/pay/create`));
      assert.ok(c.paypalOrderId);
      await fails(hodan.post(`/api/orders/${orderId}/pay/capture`, { paypalOrderId: 'MOCK-doesnotexist' }), 400);
      await ok(hodan.post(`/api/orders/${orderId}/pay/capture`, { paypalOrderId: c.paypalOrderId }));
      await ok(hodan.post(`/api/orders/${orderId}/pay/capture`, { paypalOrderId: c.paypalOrderId }), 'capture twice is harmless');
      const o = await ok(hodan.get('/api/orders/' + orderId)); assert.equal(o.status, 'in_escrow'); assert.equal(o.feeCents, 3000);
    });
    await step('money is held: freelancer balance is still zero', async () => {
      const w = await ok(abdi.get('/api/wallet')); assert.equal(w.balanceCents, 0); assert.equal(w.pendingCents, 27000);
    });
    await step('cannot withdraw before earning or without PayPal email', async () => {
      await fails(abdi.post('/api/wallet/withdraw', { amount: '10' }), 400);
    });
    await step('freelancer delivers; client cannot deliver; client releases', async () => {
      await fails(hodan.post(`/api/orders/${orderId}/deliver`, { note: 'x' }), 403);
      await ok(abdi.post(`/api/orders/${orderId}/deliver`, { note: 'Site is live at example.com' }));
      await fails(abdi.post(`/api/orders/${orderId}/release`), 403);
      await ok(hodan.post(`/api/orders/${orderId}/release`));
      await fails(hodan.post(`/api/orders/${orderId}/release`), 400, 'double release');
      const w = await ok(abdi.get('/api/wallet')); assert.equal(w.balanceCents, 27000);
    });
    await step('withdrawal over balance is refused; valid one waits for admin approval', async () => {
      await ok(abdi.post('/api/me', { paypal_email: 'abdi.paypal@example.com' }));
      await fails(abdi.post('/api/wallet/withdraw', { amount: '999' }), 400);
      const r = await ok(abdi.post('/api/wallet/withdraw', { amount: '100' })); assert.equal(r.status, 'pending');
      const w = await ok(abdi.get('/api/wallet')); assert.equal(w.balanceCents, 17000, 'held immediately');
    });
    await step('admin approves the withdrawal and money is sent', async () => {
      await ok(admin.post('/api/auth/login', ADMIN));
      await fails(abdi.post('/api/admin/withdrawals/1/approve'), 403);
      const l = await ok(admin.get('/api/admin/withdrawals?status=pending')); assert.equal(l.withdrawals.length, 1);
      const r = await ok(admin.post('/api/admin/withdrawals/' + l.withdrawals[0].id + '/approve')); assert.equal(r.status, 'paid');
      const w = await ok(abdi.get('/api/wallet')); assert.equal(w.withdrawals[0].status, 'paid'); assert.equal(w.balanceCents, 17000);
    });
    await step('rejected withdrawal returns the money', async () => {
      await ok(abdi.post('/api/wallet/withdraw', { amount: '50' }));
      const l = await ok(admin.get('/api/admin/withdrawals?status=pending'));
      await ok(admin.post(`/api/admin/withdrawals/${l.withdrawals[0].id}/reject`, { reason: 'Needs ID check' }));
      const w = await ok(abdi.get('/api/wallet')); assert.equal(w.balanceCents, 17000);
    });
    await step('books balance: user balances + withdrawn + fees = money released', async () => {
      const s = await ok(admin.get('/api/admin/stats'));
      assert.equal(s.money.volumeCents, 30000); assert.equal(s.money.feesCents, 3000); assert.equal(s.money.owedCents, 17000);
    });
    await step('dispute freezes money; admin refunds the client', async () => {
      const r = await ok(hodan.post('/api/posts', { kind: 'job', title: 'Translate app strings to Somali', category: 'Writing & translation', priceType: 'fixed', amount: '100', description: 'About 1200 interface strings for a mobile money app.' }));
      const p = await ok(abdi.post(`/api/posts/${r.id}/proposals`, { cover: 'I translate daily and can deliver in a week.', price: '100', days: 7 }));
      const o = await ok(hodan.post(`/api/proposals/${p.id}/accept`));
      const c = await ok(hodan.post(`/api/orders/${o.orderId}/pay/create`));
      await ok(hodan.post(`/api/orders/${o.orderId}/pay/capture`, { paypalOrderId: c.paypalOrderId }));
      const d = await ok(hodan.post(`/api/orders/${o.orderId}/dispute`, { reason: 'Nothing was delivered after a week.' }));
      assert.ok(d.ticketId);
      await fails(hodan.post(`/api/orders/${o.orderId}/release`), 400);
      await ok(admin.post(`/api/admin/orders/${o.orderId}/resolve`, { action: 'refund' }));
      assert.equal((await ok(hodan.get('/api/orders/' + o.orderId))).status, 'refunded');
      assert.equal((await ok(abdi.get('/api/wallet'))).balanceCents, 17000, 'freelancer got nothing from refunded order');
    });
    await step('hire from a service, cancel an unpaid order', async () => {
      const s = await ok(abdi.post('/api/posts', { kind: 'service', title: 'I will build your React website', category: 'Development', priceType: 'fixed', amount: '200', description: 'Responsive site, up to five pages, delivered in a week.' }));
      const h = await ok(hodan.post(`/api/posts/${s.id}/hire`, {}));
      await ok(hodan.post(`/api/orders/${h.orderId}/cancel`));
    });

    console.log('Messages and privacy');
    await step('direct messages with unread counts', async () => {
      await ok(hodan.post('/api/messages', { to: abdiU.id, body: 'Hi Abdi, are you free this week?' }));
      assert.equal((await ok(abdi.get('/api/summary'))).unread, 1);
      const t = await ok(abdi.get('/api/messages/threads')); assert.equal(t.threads[0].unread, 1);
      const m = await ok(abdi.get('/api/messages/with/' + hodanU.id)); assert.equal(m.messages.length, 1);
      assert.equal((await ok(abdi.get('/api/summary'))).unread, 0);
      await ok(abdi.post('/api/messages', { to: hodanU.id, body: 'Yes, send the details.' }));
      const m2 = await ok(hodan.get(`/api/messages/with/${abdiU.id}?after=${m.messages[0].id}`)); assert.equal(m2.messages.length, 1);
    });
    await step('message HTML is stored as text (the page escapes it)', async () => {
      await ok(hodan.post('/api/messages', { to: abdiU.id, body: '<img src=x onerror=alert(1)>' }));
      const m = await ok(abdi.get('/api/messages/with/' + hodanU.id));
      assert.equal(m.messages[m.messages.length - 1].body, '<img src=x onerror=alert(1)>');
    });
    await step('"connections only" blocks strangers, allows people you worked with', async () => {
      await ok(abdi.post('/api/me', { allow_messages: 'connections' }));
      await fails(eve.post('/api/messages', { to: abdiU.id, body: 'Hello there' }), 403);
      await ok(hodan.post('/api/messages', { to: abdiU.id, body: 'Still fine, we worked together' }));
    });
    await step('blocking stops messages in both directions', async () => {
      await ok(abdi.post('/api/me', { allow_messages: 'anyone' }));
      const eveUid = (await ok(eve.get('/api/me'))).user.id;
      await ok(abdi.post('/api/blocks', { userId: eveUid, block: true }));
      await fails(eve.post('/api/messages', { to: abdiU.id, body: 'Hello again' }), 403);
    });
    await step('private profile hides details from other people', async () => {
      await ok(abdi.post('/api/me', { headline: 'Full-stack developer', bio: 'Secret bio', profile_public: false }));
      const p = await ok(anon.get('/api/users/' + abdiU.id));
      assert.equal(p.bio, undefined); assert.equal(p.name, 'Abdi W.');
      const list = await ok(anon.get('/api/posts?kind=service'));
      assert.ok(list.posts.every((x) => x.author.name !== 'Abdi Warsame'));
      await ok(abdi.post('/api/me', { profile_public: true }));
      assert.equal((await ok(anon.get('/api/users/' + abdiU.id))).bio, 'Secret bio');
    });

    console.log('Support and admin');
    await step('user opens a ticket; staff replies; user sees it', async () => {
      const t = await ok(eve.post('/api/tickets', { subject: 'Cannot withdraw money', category: 'Withdrawal', body: 'My withdrawal is stuck for two days.' }));
      await fails(hodan.get('/api/tickets/' + t.id), 404);
      await ok(admin.post(`/api/tickets/${t.id}/reply`, { body: 'We are looking into it now.' }));
      const v = await ok(eve.get('/api/tickets/' + t.id)); assert.equal(v.messages.length, 2); assert.equal(v.messages[1].staff, true); assert.equal(v.ticket.status, 'pending');
      await ok(admin.post(`/api/admin/tickets/${t.id}/status`, { status: 'resolved' }));
    });
    await step('reporting a post creates a report for staff', async () => {
      await ok(eve.post('/api/reports', { type: 'post', id: postId, reason: 'This looks like a scam to me.' }));
      assert.equal((await ok(admin.get('/api/admin/reports'))).reports.length, 1);
    });
    await step('regular users cannot use admin tools', async () => {
      for (const u of ['/api/admin/stats', '/api/admin/users', '/api/admin/audit', '/api/admin/settings', '/api/admin/emails']) await fails(hodan.get(u), 403, u);
      await fails(hodan.post('/api/admin/settings', { fee_pct: 0 }), 403);
      await fails(hodan.post('/api/admin/users/' + abdiU.id, { role: 'admin' }), 403);
    });
    await step('admin suspends a user: sessions end and login is refused', async () => {
      const eveId = (await ok(eve.get('/api/me'))).user.id;
      await ok(admin.post('/api/admin/users/' + eveId, { status: 'suspended' }));
      assert.equal((await ok(eve.get('/api/me'))).user, null);
      await fails(new Client().post('/api/auth/login', { email: 'eve@example.com', password: 'Sturdy-Pass-42' }), 403);
    });
    await step('admin removes a post and changes the fee; audit log records it', async () => {
      await ok(admin.post('/api/admin/posts/' + postId, { status: 'removed' }));
      await fails(anon.get('/api/posts/' + postId), 404);
      await ok(admin.post('/api/admin/settings', { fee_pct: 12 }));
      assert.equal((await ok(anon.get('/api/config'))).feePct, 12);
      const a = await ok(admin.get('/api/admin/audit'));
      assert.ok(a.entries.some((e) => e.action === 'settings') && a.entries.some((e) => e.action === 'post_removed'));
    });
    await step('maintenance mode blocks users but not admins', async () => {
      await ok(admin.post('/api/admin/settings', { maintenance: true }));
      await fails(hodan.post('/api/messages', { to: abdiU.id, body: 'hello' }), 503);
      await ok(admin.post('/api/admin/settings', { maintenance: false }));
    });
    await step('emails were queued for the events above', async () => {
      const e = await ok(admin.get('/api/admin/emails'));
      assert.ok(e.emails.length >= 10);
      assert.ok(e.emails.some((m) => /funded|Payment received/.test(m.subject)));
    });
    await step('account deletion is blocked while money is owed, allowed after', async () => {
      await fails(abdi.post('/api/me/delete', { password: 'Brand-New-Pass-77' }), 400);
    });
    await step('rate limiting kicks in on repeated signups', async () => {
      const c = new Client(); let last;
      for (let i = 0; i < 12; i++) last = await c.post('/api/auth/signup', { name: 'Spam', email: `spam${i}@example.com`, phone: '+252611000000', password: 'Sturdy-Pass-42' });
      assert.equal(last.status, 429);
    });
    console.log(`\n${passed} checks passed`);
  } catch (e) {
    console.log('\nStopped at first failure. Server log tail:\n' + log.split('\n').slice(-12).join('\n'));
  } finally {
    srv.kill();
    fs.rmSync(dir, { recursive: true, force: true });
  }
})();
