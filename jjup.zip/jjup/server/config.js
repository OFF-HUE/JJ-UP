'use strict';
const path = require('node:path');
const env = process.env;

const port = Number(env.PORT) || 3000;
const cfg = {
  prod: env.NODE_ENV === 'production',
  port,
  appUrl: (env.APP_URL || `http://localhost:${port}`).replace(/\/$/, ''),
  dbPath: env.DB_PATH || path.join(__dirname, '..', 'data', 'jjup.db'),
  trustProxy: env.TRUST_PROXY === '1',
  smtp: {
    host: env.SMTP_HOST || '',
    port: Number(env.SMTP_PORT) || 587,
    user: env.SMTP_USER || '',
    pass: env.SMTP_PASS || '',
    from: env.MAIL_FROM || 'Jj Up <no-reply@localhost>',
  },
  sms: { sid: env.TWILIO_SID || '', token: env.TWILIO_TOKEN || '', from: env.TWILIO_FROM || '' },
  requirePhone: env.REQUIRE_PHONE_VERIFY === '1',
  paypal: {
    mode: env.PAYPAL_MODE || 'mock', // mock | sandbox | live
    clientId: env.PAYPAL_CLIENT_ID || '',
    secret: env.PAYPAL_SECRET || '',
    webhookId: env.PAYPAL_WEBHOOK_ID || '',
  },
  // Defaults for values the admin can change later in the dashboard.
  defaults: {
    fee_pct: '10',
    min_withdraw: '10',
    manual_withdrawals: '1',
    signups_open: '1',
    maintenance: '0',
    auto_release_days: '7',
  },
  categories: ['Development', 'Design', 'Writing & translation', 'Marketing', 'Video & audio', 'Business', 'Other'],
};

cfg.smtpOn = !!(cfg.smtp.host && cfg.smtp.user);
cfg.smsOn = !!(cfg.sms.sid && cfg.sms.token && cfg.sms.from);

function check() {
  const errs = [];
  if (!['mock', 'sandbox', 'live'].includes(cfg.paypal.mode)) errs.push('PAYPAL_MODE must be mock, sandbox or live');
  if (cfg.paypal.mode !== 'mock' && !(cfg.paypal.clientId && cfg.paypal.secret)) errs.push('PAYPAL_CLIENT_ID and PAYPAL_SECRET are required unless PAYPAL_MODE=mock');
  if (cfg.prod && cfg.paypal.mode === 'mock' && env.ALLOW_MOCK !== '1') errs.push('PAYPAL_MODE=mock is not allowed in production (set ALLOW_MOCK=1 only for a staging demo)');
  if (cfg.prod && !cfg.appUrl.startsWith('https://')) errs.push('APP_URL must start with https:// in production');
  if (cfg.requirePhone && !cfg.smsOn) errs.push('REQUIRE_PHONE_VERIFY=1 needs TWILIO_SID, TWILIO_TOKEN and TWILIO_FROM');
  if (errs.length) throw new Error('Configuration problems:\n - ' + errs.join('\n - '));
}
cfg.check = check;
module.exports = cfg;
