'use strict';
const http = require('node:http');
const cfg = require('./config');
cfg.check();

const { handle } = require('./lib/http');
const { db, get, run, tx, now, audit } = require('./lib/db');
const A = require('./lib/auth');
const { flush } = require('./lib/mail');
const { autoRelease } = require('./lib/orders');
const { reconcile } = require('./lib/wallet');

require('./routes/auth');
require('./routes/market');
require('./routes/support');
require('./routes/admin');

// First admin from environment variables (only when no admin exists yet).
async function bootstrapAdmin() {
  const email = process.env.ADMIN_EMAIL, pw = process.env.ADMIN_PASSWORD;
  if (!email || !pw || get("SELECT 1 x FROM users WHERE role='admin'")) return;
  const problem = A.passwordProblem(pw, email);
  if (problem) { console.error('[admin] ADMIN_PASSWORD rejected:', problem); return; }
  const h = await A.hashPassword(pw);
  run("INSERT INTO users(email,phone,name,pw_hash,role,email_verified,status,created_at) VALUES(?,?,?,?,'admin',1,'active',?)", email.toLowerCase(), '', process.env.ADMIN_NAME || 'Admin', h, now());
  audit(null, 'admin_bootstrap', email, '', '');
  console.log('[admin] created first admin', email);
}

const server = http.createServer(handle);
server.requestTimeout = 30000;
server.headersTimeout = 15000;
server.keepAliveTimeout = 65000;

function sweep() {
  run('DELETE FROM sessions WHERE expires_at<?', now());
  run('DELETE FROM codes WHERE expires_at<?', now());
  run('DELETE FROM webhook_events WHERE created_at<?', now() - 30 * 86400000);
}

bootstrapAdmin().then(() => {
  server.listen(cfg.port, () => {
    console.log(`Jj Up listening on ${cfg.appUrl} (port ${cfg.port})`);
    console.log(`PayPal: ${cfg.paypal.mode}${cfg.paypal.mode === 'mock' ? ' (simulated, no real money)' : ''} | email: ${cfg.smtpOn ? 'SMTP' : 'NOT CONFIGURED (emails are logged only)'} | SMS: ${cfg.smsOn ? 'on' : 'off'}`);
    if (!get("SELECT 1 x FROM users WHERE role='admin'")) console.log('No admin yet. Run: npm run create-admin -- you@example.com "Your Name"');
  });
});

setInterval(() => reconcile().catch((e) => console.error('[reconcile]', e.message)), 5 * 60000).unref();
setInterval(() => { try { autoRelease(); sweep(); } catch (e) { console.error('[jobs]', e.message); } }, 60 * 60000).unref();
setTimeout(() => { try { sweep(); autoRelease(); } catch (_) {} flush(); reconcile().catch(() => {}); }, 3000).unref();

function stop() {
  console.log('Shutting down');
  server.close(() => { try { db.close(); } catch (_) {} process.exit(0); });
  setTimeout(() => process.exit(0), 8000).unref();
}
process.on('SIGTERM', stop);
process.on('SIGINT', stop);
process.on('unhandledRejection', (e) => console.error('[unhandled]', e));
