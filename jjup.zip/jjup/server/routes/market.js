'use strict';
const cfg = require('../config');
const { route } = require('../lib/http');
const { get, all, run, tx, now, audit } = require('../lib/db');
const U = require('../lib/util');
const { notify } = require('../lib/mail');
const { feeFor, balanceOf, pendingOf } = require('../lib/money');
const { releaseOrder, money } = require('../lib/orders');
const paypal = require('../lib/paypal');

const { HttpError, bad, notFound, forbidden } = U;
const isStaff = (u) => u && u.role !== 'user';

function shown(name, isPublic) {
  if (isPublic) return name;
  const p = String(name).split(/\s+/);
  return p.length > 1 ? `${p[0]} ${p[p.length - 1][0]}.` : p[0];
}
function authorOf(r) {
  return { id: r.author_id, name: shown(r.a_name, r.a_public), headline: r.a_public ? r.a_headline : '', country: r.a_public ? r.a_country : '', isPublic: !!r.a_public };
}
function postOut(r) {
  return {
    id: r.id, kind: r.kind, title: r.title, category: r.category, priceType: r.price_type, amountCents: r.amount_cents,
    description: r.description, visibility: r.visibility, status: r.status, createdAt: r.created_at, author: authorOf(r),
  };
}
const POST_SELECT = 'SELECT p.*, u.name a_name, u.profile_public a_public, u.headline a_headline, u.country a_country, u.status a_status FROM posts p JOIN users u ON u.id=p.author_id';

function postFor(id, viewer) {
  const r = get(POST_SELECT + ' WHERE p.id=?', id);
  if (!r) throw notFound('That post does not exist.');
  if (r.status === 'removed' && !(isStaff(viewer) || (viewer && viewer.id === r.author_id))) throw notFound('That post does not exist.');
  return r;
}

/* ---------- posts ---------- */
route('GET', '/api/posts', (ctx) => {
  const q = ctx.query;
  const kind = q.kind === 'service' ? 'service' : 'job';
  const page = Math.max(1, Math.min(500, parseInt(q.page, 10) || 1));
  const size = 12;
  let where = "p.status='open' AND p.visibility='public' AND u.status='active' AND p.kind=?";
  const args = [kind];
  if (q.category && cfg.categories.includes(q.category)) { where += ' AND p.category=?'; args.push(q.category); }
  const term = String(q.q || '').trim().slice(0, 80);
  if (term) {
    const like = '%' + term.replace(/[\\%_]/g, (c) => '\\' + c) + '%';
    where += " AND (p.title LIKE ? ESCAPE '\\' OR p.description LIKE ? ESCAPE '\\')";
    args.push(like, like);
  }
  const total = get(`SELECT COUNT(*) n FROM posts p JOIN users u ON u.id=p.author_id WHERE ${where}`, ...args).n;
  const rows = all(`${POST_SELECT} WHERE ${where} ORDER BY p.created_at DESC LIMIT ? OFFSET ?`, ...args, size, (page - 1) * size);
  return { posts: rows.map(postOut), total, page, pages: Math.max(1, Math.ceil(total / size)) };
});

route('GET', '/api/posts/:id', (ctx) => {
  const r = postFor(ctx.params.id, ctx.user);
  const out = postOut(r);
  const me = ctx.user;
  out.mine = !!me && me.id === r.author_id;
  if (me && !out.mine) {
    const mp = get('SELECT id,status,price_cents,days FROM proposals WHERE post_id=? AND freelancer_id=?', r.id, me.id);
    if (mp) out.myProposal = mp;
  }
  if (out.mine && r.kind === 'job') {
    out.proposals = all('SELECT p.*, u.name, u.headline, u.profile_public FROM proposals p JOIN users u ON u.id=p.freelancer_id WHERE p.post_id=? ORDER BY p.created_at DESC', r.id).map((p) => ({
      id: p.id, freelancerId: p.freelancer_id, name: shown(p.name, p.profile_public), headline: p.profile_public ? p.headline : '', cover: p.cover, priceCents: p.price_cents, days: p.days, status: p.status, createdAt: p.created_at,
    }));
  }
  return out;
});

route('POST', '/api/posts', { auth: 'user', limit: [20, 3600000] }, (ctx) => {
  const b = ctx.body;
  const kind = U.oneOf(b.kind, ['job', 'service'], 'Post type');
  const title = U.str(b.title, 'Title', 5, 120);
  const category = U.oneOf(b.category, cfg.categories, 'Category');
  const priceType = U.oneOf(b.priceType, ['fixed', 'hourly'], 'Pricing');
  const amount = U.cents(b.amount, 'Amount', 100, 5000000);
  const description = U.str(b.description, 'Description', 20, 3000);
  const visibility = U.oneOf(b.visibility || 'public', ['public', 'unlisted'], 'Visibility');
  const id = run('INSERT INTO posts(author_id,kind,title,category,price_type,amount_cents,description,visibility,created_at) VALUES(?,?,?,?,?,?,?,?,?)', ctx.user.id, kind, title, category, priceType, amount, description, visibility, now()).id;
  return { id };
});

route('POST', '/api/posts/:id/update', { auth: 'user', limit: [60, 3600000] }, (ctx) => {
  const p = postFor(ctx.params.id, ctx.user);
  if (p.author_id !== ctx.user.id) throw forbidden();
  if (p.status === 'removed') throw bad('This post was removed.');
  const set = {};
  if ('status' in ctx.body) set.status = U.oneOf(ctx.body.status, ['open', 'closed'], 'Status');
  if ('visibility' in ctx.body) set.visibility = U.oneOf(ctx.body.visibility, ['public', 'unlisted'], 'Visibility');
  const keys = Object.keys(set);
  if (keys.length) run(`UPDATE posts SET ${keys.map((k) => k + '=?').join(',')} WHERE id=?`, ...keys.map((k) => set[k]), p.id);
  return { ok: true };
});
route('POST', '/api/posts/:id/delete', { auth: 'user' }, (ctx) => {
  const p = postFor(ctx.params.id, ctx.user);
  if (p.author_id !== ctx.user.id) throw forbidden();
  run("UPDATE posts SET status='removed' WHERE id=?", p.id);
  run("UPDATE proposals SET status='closed' WHERE post_id=? AND status='pending'", p.id);
  return { ok: true };
});
route('GET', '/api/my/posts', { auth: 'user' }, (ctx) => ({
  posts: all(POST_SELECT + " WHERE p.author_id=? AND p.status<>'removed' ORDER BY p.created_at DESC", ctx.user.id).map((r) => ({
    ...postOut(r), proposalCount: get('SELECT COUNT(*) n FROM proposals WHERE post_id=?', r.id).n,
  })),
}));

/* ---------- proposals ---------- */
route('POST', '/api/posts/:id/proposals', { auth: 'user', limit: [30, 3600000] }, (ctx) => {
  const p = postFor(ctx.params.id, ctx.user);
  const b = ctx.body;
  if (p.kind !== 'job') throw bad('You can only send proposals on jobs.');
  if (p.status !== 'open' || p.a_status !== 'active') throw bad('This job is no longer taking proposals.');
  if (p.author_id === ctx.user.id) throw bad('You cannot send a proposal on your own job.');
  if (get('SELECT 1 x FROM blocks WHERE (user_id=? AND blocked_id=?) OR (user_id=? AND blocked_id=?)', p.author_id, ctx.user.id, ctx.user.id, p.author_id)) throw forbidden('You cannot send a proposal to this user.');
  const cover = U.str(b.cover, 'Cover letter', 20, 2000);
  const price = U.cents(b.price, 'Price', 100, 5000000);
  const days = U.int(b.days, 'Delivery time', 1, 365);
  if (get('SELECT 1 x FROM proposals WHERE post_id=? AND freelancer_id=?', p.id, ctx.user.id)) throw bad('You already sent a proposal on this job.');
  const id = run('INSERT INTO proposals(post_id,freelancer_id,cover,price_cents,days,created_at) VALUES(?,?,?,?,?,?)', p.id, ctx.user.id, cover, price, days, now()).id;
  notify(p.author_id, 'New proposal on your job', `${ctx.user.name} sent a proposal of ${money(price)} on "${p.title}".`);
  return { id };
});

route('GET', '/api/proposals', { auth: 'user' }, (ctx) => {
  const box = ctx.query.box === 'received' ? 'received' : 'sent';
  const rows = box === 'sent'
    ? all('SELECT pr.*, p.title, p.author_id other_id, u.name other_name, u.profile_public other_public FROM proposals pr JOIN posts p ON p.id=pr.post_id JOIN users u ON u.id=p.author_id WHERE pr.freelancer_id=? ORDER BY pr.created_at DESC LIMIT 200', ctx.user.id)
    : all('SELECT pr.*, p.title, pr.freelancer_id other_id, u.name other_name, u.profile_public other_public FROM proposals pr JOIN posts p ON p.id=pr.post_id JOIN users u ON u.id=pr.freelancer_id WHERE p.author_id=? ORDER BY pr.created_at DESC LIMIT 200', ctx.user.id);
  return {
    proposals: rows.map((r) => ({
      id: r.id, postId: r.post_id, title: r.title, cover: r.cover, priceCents: r.price_cents, days: r.days, status: r.status, createdAt: r.created_at,
      other: { id: r.other_id, name: shown(r.other_name, r.other_public) },
    })),
  };
});

route('POST', '/api/proposals/:id/accept', { auth: 'user', limit: [60, 3600000] }, (ctx) => {
  const res = tx(() => {
    const pr = get('SELECT pr.*, p.author_id, p.title, p.status post_status FROM proposals pr JOIN posts p ON p.id=pr.post_id WHERE pr.id=?', ctx.params.id);
    if (!pr || pr.author_id !== ctx.user.id) throw notFound('Proposal not found.');
    if (pr.status !== 'pending') throw bad('This proposal is no longer pending.');
    if (pr.post_status !== 'open') throw bad('This job is closed.');
    const f = get('SELECT status FROM users WHERE id=?', pr.freelancer_id);
    if (!f || f.status !== 'active') throw bad('This freelancer is not available.');
    run("UPDATE proposals SET status='accepted' WHERE id=?", pr.id);
    run("UPDATE proposals SET status='closed' WHERE post_id=? AND id<>? AND status='pending'", pr.post_id, pr.id);
    run("UPDATE posts SET status='closed' WHERE id=?", pr.post_id);
    const orderId = run('INSERT INTO orders(post_id,title,client_id,freelancer_id,amount_cents,days,created_at) VALUES(?,?,?,?,?,?,?)', pr.post_id, pr.title, ctx.user.id, pr.freelancer_id, pr.price_cents, pr.days, now()).id;
    return { orderId, pr };
  });
  notify(res.pr.freelancer_id, 'Your proposal was accepted', `${ctx.user.name} accepted your proposal for "${res.pr.title}". They will fund the order next. You start work when the money is held in escrow.`, true);
  return { orderId: res.orderId };
});
route('POST', '/api/proposals/:id/decline', { auth: 'user' }, (ctx) => {
  const pr = get('SELECT pr.*, p.author_id, p.title FROM proposals pr JOIN posts p ON p.id=pr.post_id WHERE pr.id=?', ctx.params.id);
  if (!pr || pr.author_id !== ctx.user.id) throw notFound('Proposal not found.');
  if (pr.status !== 'pending') throw bad('This proposal is no longer pending.');
  run("UPDATE proposals SET status='declined' WHERE id=?", pr.id);
  notify(pr.freelancer_id, 'Proposal declined', `Your proposal for "${pr.title}" was declined.`);
  return { ok: true };
});
route('POST', '/api/proposals/:id/withdraw', { auth: 'user' }, (ctx) => {
  const r = run("UPDATE proposals SET status='withdrawn' WHERE id=? AND freelancer_id=? AND status='pending'", ctx.params.id, ctx.user.id);
  if (!r.changes) throw bad('This proposal cannot be withdrawn.');
  return { ok: true };
});

route('POST', '/api/posts/:id/hire', { auth: 'user', limit: [20, 3600000] }, (ctx) => {
  const p = postFor(ctx.params.id, ctx.user);
  if (p.kind !== 'service') throw bad('You can only hire from a service.');
  if (p.status !== 'open' || p.a_status !== 'active') throw bad('This service is not available.');
  if (p.author_id === ctx.user.id) throw bad('You cannot hire yourself.');
  if (get('SELECT 1 x FROM blocks WHERE (user_id=? AND blocked_id=?) OR (user_id=? AND blocked_id=?)', p.author_id, ctx.user.id, ctx.user.id, p.author_id)) throw forbidden('You cannot hire this user.');
  const hours = p.price_type === 'hourly' ? U.int(ctx.body.hours, 'Hours', 1, 500) : 1;
  const amount = p.amount_cents * hours;
  if (amount > 5000000) throw bad('That order is larger than the $50,000 limit.');
  const id = run('INSERT INTO orders(post_id,title,client_id,freelancer_id,amount_cents,days,created_at) VALUES(?,?,?,?,?,?,?)', p.id, p.title, ctx.user.id, p.author_id, amount, 7, now()).id;
  notify(p.author_id, 'Someone wants to hire you', `${ctx.user.name} started an order for "${p.title}" (${money(amount)}). You start work when they pay and the money is held in escrow.`);
  return { orderId: id };
});

/* ---------- orders ---------- */
function orderOut(o, viewer) {
  const clientSide = o.client_id === viewer.id;
  const other = get('SELECT id,name,profile_public FROM users WHERE id=?', clientSide ? o.freelancer_id : o.client_id);
  return {
    id: o.id, postId: o.post_id, title: o.title, amountCents: o.amount_cents, feeCents: o.fee_cents, days: o.days, status: o.status,
    deliveryNote: o.delivery_note, createdAt: o.created_at, fundedAt: o.funded_at, deliveredAt: o.delivered_at,
    role: clientSide ? 'client' : 'freelancer', other: { id: other.id, name: shown(other.name, other.profile_public) },
    youGetCents: o.amount_cents - (o.fee_cents || feeFor(o.amount_cents)),
  };
}
function orderFor(id, user, side) {
  const o = get('SELECT * FROM orders WHERE id=?', id);
  if (!o || (o.client_id !== user.id && o.freelancer_id !== user.id && !isStaff(user))) throw notFound('Order not found.');
  if (side === 'client' && o.client_id !== user.id) throw forbidden('Only the client can do this.');
  if (side === 'freelancer' && o.freelancer_id !== user.id) throw forbidden('Only the freelancer can do this.');
  return o;
}
route('GET', '/api/orders', { auth: 'user' }, (ctx) => ({
  orders: all('SELECT * FROM orders WHERE client_id=? OR freelancer_id=? ORDER BY id DESC LIMIT 200', ctx.user.id, ctx.user.id).map((o) => orderOut(o, ctx.user)),
}));
route('GET', '/api/orders/:id', { auth: 'user' }, (ctx) => orderOut(orderFor(ctx.params.id, ctx.user), ctx.user));

route('POST', '/api/orders/:id/pay/create', { auth: 'user', limit: [30, 3600000] }, async (ctx) => {
  const o = orderFor(ctx.params.id, ctx.user, 'client');
  if (o.status !== 'awaiting_payment') throw bad('This order is not waiting for payment.');
  const fr = get('SELECT status FROM users WHERE id=?', o.freelancer_id);
  if (!fr || fr.status !== 'active') throw bad('The freelancer is not available. Contact support.');
  const r = await paypal.createOrder({ orderId: o.id, title: o.title, amountCents: o.amount_cents }).catch((e) => { console.error('[paypal create]', e.message); throw new HttpError(502, 'PayPal is not available right now. Please try again.'); });
  run('INSERT INTO payments(order_id,provider_order_id,amount_cents,created_at) VALUES(?,?,?,?)', o.id, r.id, o.amount_cents, now());
  return { paypalOrderId: r.id, mock: paypal.mode === 'mock' };
});

route('POST', '/api/orders/:id/pay/capture', { auth: 'user', limit: [30, 3600000] }, async (ctx) => {
  const o = orderFor(ctx.params.id, ctx.user, 'client');
  const ppId = U.str(ctx.body.paypalOrderId, 'PayPal order', 5, 80);
  const pay = get('SELECT * FROM payments WHERE provider_order_id=? AND order_id=?', ppId, o.id);
  if (!pay) throw bad('That payment does not belong to this order.');
  if (pay.status === 'captured') return { ok: true, already: true };
  if (o.status !== 'awaiting_payment') throw bad('This order is not waiting for payment.');
  let cap;
  try { cap = await paypal.captureOrder(ppId); }
  catch (e) {
    console.error('[paypal capture]', e.message);
    run("UPDATE payments SET status='failed' WHERE id=? AND status='created'", pay.id);
    throw new HttpError(502, 'PayPal could not take this payment. No money was moved. Try again or use another PayPal funding option.');
  }
  const okShape = cap.status === 'COMPLETED' && cap.currency === 'USD' && cap.amountCents === o.amount_cents && String(cap.customId) === String(o.id);
  if (!okShape) {
    audit(ctx.user.id, 'payment_mismatch', String(o.id), JSON.stringify({ status: cap.status, cur: cap.currency, amt: cap.amountCents, custom: cap.customId, id: cap.captureId }), ctx.ip);
    run("UPDATE payments SET status='failed', capture_id=? WHERE id=?", cap.captureId || '', pay.id);
    throw new HttpError(402, 'We could not confirm this payment. If PayPal charged you, contact support with order #' + o.id + '.');
  }
  const moved = tx(() => {
    const cur = get('SELECT status FROM orders WHERE id=?', o.id);
    run("UPDATE payments SET status='captured', capture_id=?, payer_email=? WHERE id=?", cap.captureId, cap.payerEmail, pay.id);
    if (cur.status !== 'awaiting_payment') { audit(null, 'payment_orphan', String(o.id), 'captured while order was ' + cur.status, ctx.ip); return false; }
    run("UPDATE orders SET status='in_escrow', fee_cents=?, funded_at=? WHERE id=?", feeFor(o.amount_cents), now(), o.id);
    return true;
  });
  if (!moved) throw new HttpError(409, 'This order changed while paying. Contact support with order #' + o.id + '.');
  notify(o.freelancer_id, `Order #${o.id} is funded`, `${money(o.amount_cents)} is held in escrow for "${o.title}". You can start work now.`, true);
  notify(o.client_id, `Payment received for order #${o.id}`, `We are holding ${money(o.amount_cents)} for "${o.title}" until you release it.`, true);
  return { ok: true };
});

route('POST', '/api/orders/:id/deliver', { auth: 'user', limit: [60, 3600000] }, (ctx) => {
  const o = orderFor(ctx.params.id, ctx.user, 'freelancer');
  const note = U.optStr(ctx.body.note, 'Delivery note', 2000);
  const r = run("UPDATE orders SET status='delivered', delivered_at=?, delivery_note=? WHERE id=? AND status='in_escrow'", now(), note, o.id);
  if (!r.changes) throw bad('This order is not in progress.');
  notify(o.client_id, `Order #${o.id} was delivered`, `${ctx.user.name} delivered "${o.title}". Review it and release the payment, or open a dispute if something is wrong. If you do nothing, payment is released automatically after a few days.`, true);
  return { ok: true };
});
route('POST', '/api/orders/:id/release', { auth: 'user', limit: [60, 3600000] }, (ctx) => {
  const o = orderFor(ctx.params.id, ctx.user, 'client');
  if (!['in_escrow', 'delivered'].includes(o.status)) throw bad('This order cannot be released right now.');
  releaseOrder(o.id, ctx.user.id, ctx.ip, 'client_release');
  return { ok: true };
});
route('POST', '/api/orders/:id/cancel', { auth: 'user' }, (ctx) => {
  const o = orderFor(ctx.params.id, ctx.user);
  if (isStaff(ctx.user) && o.client_id !== ctx.user.id && o.freelancer_id !== ctx.user.id) throw forbidden();
  const r = run("UPDATE orders SET status='cancelled', closed_at=? WHERE id=? AND status='awaiting_payment'", now(), o.id);
  if (!r.changes) throw bad('Only unpaid orders can be cancelled. Open a dispute for paid orders.');
  return { ok: true };
});
route('POST', '/api/orders/:id/dispute', { auth: 'user', limit: [10, 3600000] }, (ctx) => {
  const o = orderFor(ctx.params.id, ctx.user);
  if (o.client_id !== ctx.user.id && o.freelancer_id !== ctx.user.id) throw forbidden();
  const reason = U.str(ctx.body.reason, 'Reason', 10, 2000);
  const tid = tx(() => {
    const r = run("UPDATE orders SET status='disputed' WHERE id=? AND status IN ('in_escrow','delivered')", o.id);
    if (!r.changes) throw bad('Only paid orders can be disputed.');
    const id = run("INSERT INTO tickets(user_id,subject,category,order_id,created_at,updated_at) VALUES(?,?,?,?,?,?)", ctx.user.id, `Dispute on order #${o.id}: ${o.title}`.slice(0, 150), 'Dispute', o.id, now(), now()).id;
    run('INSERT INTO ticket_messages(ticket_id,author_id,body,created_at) VALUES(?,?,?,?)', id, ctx.user.id, reason, now());
    audit(ctx.user.id, 'dispute_open', String(o.id), '', ctx.ip);
    return id;
  });
  const otherId = o.client_id === ctx.user.id ? o.freelancer_id : o.client_id;
  notify(otherId, `Order #${o.id} is in dispute`, `The other side opened a dispute on "${o.title}". Our support team will review it and may contact you. The money stays in escrow until it is resolved.`, true);
  return { ticketId: tid };
});

/* ---------- messages ---------- */
function canMessage(from, to) {
  if (!to || to.status !== 'active' || from.status !== 'active') return 'This person is not available.';
  if (to.id === from.id) return 'You cannot message yourself.';
  if (get('SELECT 1 x FROM blocks WHERE (user_id=? AND blocked_id=?) OR (user_id=? AND blocked_id=?)', to.id, from.id, from.id, to.id)) return 'You cannot message this person.';
  if (to.allow_messages === 'anyone' || from.role !== 'user' || to.role !== 'user') return '';
  const linked = get(`SELECT 1 x FROM orders WHERE (client_id=? AND freelancer_id=?) OR (client_id=? AND freelancer_id=?)
    UNION SELECT 1 FROM proposals pr JOIN posts p ON p.id=pr.post_id WHERE (pr.freelancer_id=? AND p.author_id=?) OR (pr.freelancer_id=? AND p.author_id=?)
    UNION SELECT 1 FROM messages WHERE from_id=? AND to_id=?`, from.id, to.id, to.id, from.id, from.id, to.id, to.id, from.id, to.id, from.id);
  return linked ? '' : 'This person only accepts messages from people they have worked with or who have a proposal with them.';
}

route('POST', '/api/messages', { auth: 'user', limit: [40, 60000] }, (ctx) => {
  const to = get('SELECT * FROM users WHERE id=?', U.int(ctx.body.to, 'Recipient', 1, 1e12));
  const body = U.str(ctx.body.body, 'Message', 1, 2000);
  const why = canMessage(ctx.user, to);
  if (why) throw forbidden(why);
  const id = run('INSERT INTO messages(from_id,to_id,body,created_at) VALUES(?,?,?,?)', ctx.user.id, to.id, body, now()).id;
  notify(to.id, `New message from ${ctx.user.name}`, `${ctx.user.name} sent you a message on Jj Up:\n\n"${body.slice(0, 300)}"`, false, 'msg' + ctx.user.id);
  return { id };
});

route('GET', '/api/messages/threads', { auth: 'user' }, (ctx) => {
  const me = ctx.user.id;
  const rows = all(`SELECT m.* FROM messages m WHERE m.id IN (SELECT MAX(id) FROM messages WHERE from_id=? OR to_id=? GROUP BY CASE WHEN from_id=? THEN to_id ELSE from_id END) ORDER BY m.id DESC LIMIT 100`, me, me, me);
  const unread = Object.fromEntries(all('SELECT from_id, COUNT(*) n FROM messages WHERE to_id=? AND read_at=0 GROUP BY from_id', me).map((r) => [r.from_id, r.n]));
  return {
    threads: rows.map((m) => {
      const oid = m.from_id === me ? m.to_id : m.from_id;
      const o = get('SELECT id,name,profile_public FROM users WHERE id=?', oid);
      return { userId: oid, name: shown(o.name, o.profile_public), last: m.body.slice(0, 120), lastAt: m.created_at, mine: m.from_id === me, unread: unread[oid] || 0 };
    }),
  };
});
route('GET', '/api/messages/with/:id', { auth: 'user' }, (ctx) => {
  const me = ctx.user.id, other = get('SELECT * FROM users WHERE id=?', ctx.params.id);
  if (!other) throw notFound('User not found.');
  const after = parseInt(ctx.query.after, 10) || 0;
  const rows = after
    ? all('SELECT * FROM messages WHERE id>? AND ((from_id=? AND to_id=?) OR (from_id=? AND to_id=?)) ORDER BY id LIMIT 200', after, me, other.id, other.id, me)
    : all('SELECT * FROM (SELECT * FROM messages WHERE (from_id=? AND to_id=?) OR (from_id=? AND to_id=?) ORDER BY id DESC LIMIT 100) ORDER BY id', me, other.id, other.id, me);
  run('UPDATE messages SET read_at=? WHERE to_id=? AND from_id=? AND read_at=0', now(), me, other.id);
  const why = canMessage(ctx.user, other);
  const blocked = !!get('SELECT 1 x FROM blocks WHERE user_id=? AND blocked_id=?', me, other.id);
  return {
    messages: rows.map((m) => ({ id: m.id, mine: m.from_id === me, body: m.body, at: m.created_at })),
    other: { id: other.id, name: other.status === 'active' ? shown(other.name, other.profile_public) : 'Unavailable user', headline: other.profile_public && other.status === 'active' ? other.headline : '' },
    canSend: !why, reason: why, blocked,
  };
});
route('POST', '/api/blocks', { auth: 'user', limit: [60, 3600000] }, (ctx) => {
  const id = U.int(ctx.body.userId, 'User', 1, 1e12);
  if (id === ctx.user.id) throw bad('You cannot block yourself.');
  if (ctx.body.block) run('INSERT OR IGNORE INTO blocks(user_id,blocked_id) VALUES(?,?)', ctx.user.id, id);
  else run('DELETE FROM blocks WHERE user_id=? AND blocked_id=?', ctx.user.id, id);
  return { ok: true };
});
route('GET', '/api/blocks', { auth: 'user' }, (ctx) => ({
  blocked: all('SELECT u.id,u.name FROM blocks b JOIN users u ON u.id=b.blocked_id WHERE b.user_id=?', ctx.user.id),
}));

// Small counters for the badges in the top bar.
route('GET', '/api/summary', { auth: 'user' }, (ctx) => {
  const me = ctx.user.id;
  return {
    unread: get('SELECT COUNT(*) n FROM messages WHERE to_id=? AND read_at=0', me).n,
    proposals: get("SELECT COUNT(*) n FROM proposals pr JOIN posts p ON p.id=pr.post_id WHERE p.author_id=? AND pr.status='pending'", me).n,
    orders: get("SELECT COUNT(*) n FROM orders WHERE (client_id=? AND status IN ('awaiting_payment','delivered')) OR (freelancer_id=? AND status='in_escrow')", me, me).n,
    tickets: get("SELECT COUNT(*) n FROM tickets WHERE user_id=? AND status='pending'", me).n,
  };
});

/* ---------- profiles and reports ---------- */
route('GET', '/api/users/:id', (ctx) => {
  const u = get("SELECT * FROM users WHERE id=? AND status='active'", ctx.params.id);
  if (!u) throw notFound('Profile not found.');
  const me = ctx.user;
  const full = u.profile_public || (me && (me.id === u.id || isStaff(me)));
  const out = { id: u.id, name: full ? u.name : shown(u.name, 0), isPublic: !!u.profile_public, memberSince: u.created_at };
  if (full) {
    Object.assign(out, { headline: u.headline, skills: u.skills, bio: u.bio, country: u.country });
    out.completedAsFreelancer = get("SELECT COUNT(*) n FROM orders WHERE freelancer_id=? AND status='released'", u.id).n;
    out.completedAsClient = get("SELECT COUNT(*) n FROM orders WHERE client_id=? AND status='released'", u.id).n;
    out.posts = all(POST_SELECT + " WHERE p.author_id=? AND p.status='open' AND p.visibility='public' ORDER BY p.created_at DESC LIMIT 20", u.id).map(postOut);
  }
  if (me && me.id !== u.id) out.canMessage = !canMessage(me, u);
  return out;
});

route('POST', '/api/reports', { auth: 'user', limit: [10, 3600000] }, (ctx) => {
  const type = U.oneOf(ctx.body.type, ['post', 'user'], 'Report type');
  const id = U.int(ctx.body.id, 'Target', 1, 1e12);
  const reason = U.str(ctx.body.reason, 'Reason', 10, 1000);
  const exists = type === 'post' ? get('SELECT 1 x FROM posts WHERE id=?', id) : get('SELECT 1 x FROM users WHERE id=?', id);
  if (!exists) throw notFound('That item does not exist.');
  run('INSERT INTO reports(reporter_id,target_type,target_id,reason,created_at) VALUES(?,?,?,?,?)', ctx.user.id, type, id, reason, now());
  return { ok: true };
});

/* ---------- wallet ---------- */
const { processWithdrawal } = require('../lib/wallet');
const { queue } = require('../lib/mail');
const { setting } = require('../lib/db');

route('GET', '/api/wallet', { auth: 'user' }, (ctx) => ({
  balanceCents: balanceOf(ctx.user.id),
  pendingCents: pendingOf(ctx.user.id),
  minWithdraw: parseFloat(setting('min_withdraw')),
  paypalEmail: ctx.user.paypal_email,
  withdrawals: all('SELECT id,amount_cents,paypal_email,status,note,created_at,processed_at FROM withdrawals WHERE user_id=? ORDER BY id DESC LIMIT 50', ctx.user.id),
  ledger: all('SELECT l.id,l.kind,l.amount_cents,l.order_id,l.created_at,o.title FROM ledger l LEFT JOIN orders o ON o.id=l.order_id WHERE l.user_id=? ORDER BY l.id DESC LIMIT 50', ctx.user.id),
  payments: all("SELECT p.id,p.order_id,p.amount_cents,p.status,p.created_at,o.title FROM payments p JOIN orders o ON o.id=p.order_id WHERE o.client_id=? AND p.status IN ('captured','refunded') ORDER BY p.id DESC LIMIT 50", ctx.user.id),
}));

route('POST', '/api/wallet/withdraw', { auth: 'user', limit: [10, 3600000] }, async (ctx) => {
  const u = ctx.user;
  if (!u.paypal_email) throw bad('Add your PayPal email in Settings first.');
  const min = Math.round((parseFloat(setting('min_withdraw')) || 0) * 100);
  const amount = U.cents(ctx.body.amount, 'Amount', Math.max(100, min), 5000000);
  const id = tx(() => {
    if (balanceOf(u.id) < amount) throw bad('That is more than your available balance.');
    const wid = run('INSERT INTO withdrawals(user_id,amount_cents,paypal_email,created_at) VALUES(?,?,?,?)', u.id, amount, u.paypal_email, now()).id;
    run("INSERT INTO ledger(user_id,kind,amount_cents,ref,created_at) VALUES(?,'withdrawal',?,?,?)", u.id, -amount, 'wd:' + wid, now());
    return wid;
  });
  const auto = setting('manual_withdrawals') !== '1';
  if (auto) await processWithdrawal(id, null, ctx.ip);
  else for (const a of all("SELECT email FROM users WHERE role='admin' AND status='active'")) queue(a.email, 'Withdrawal waiting for approval', `${u.name} asked to withdraw ${money(amount)} to ${u.paypal_email}. Review it in the admin dashboard: ${cfg.appUrl}/#/admin`);
  notify(u.id, 'We received your withdrawal request', `Your withdrawal of ${money(amount)} to ${u.paypal_email} is ${auto ? 'being sent' : 'waiting for review'}.`, true);
  return { id, status: get('SELECT status FROM withdrawals WHERE id=?', id).status };
});

module.exports = { shown, isStaff };
