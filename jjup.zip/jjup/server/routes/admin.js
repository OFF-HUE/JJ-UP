'use strict';
const cfg = require('../config');
const { route } = require('../lib/http');
const { get, all, run, tx, setting, setSetting, now, audit } = require('../lib/db');
const U = require('../lib/util');
const { notify, queue, flush } = require('../lib/mail');
const { balanceOf } = require('../lib/money');
const { releaseOrder, refundOrder } = require('../lib/orders');
const { processWithdrawal, rejectWithdrawal } = require('../lib/wallet');
const paypal = require('../lib/paypal');

const { bad, notFound, forbidden } = U;
const S = 'staff', A = 'admin';

route('GET', '/api/admin/stats', { auth: S }, () => {
  const week = now() - 7 * 86400000;
  const n = (sql, ...p) => get(sql, ...p).n;
  const orders = Object.fromEntries(all('SELECT status, COUNT(*) n FROM orders GROUP BY status').map((r) => [r.status, r.n]));
  return {
    users: { total: n("SELECT COUNT(*) n FROM users WHERE status<>'deleted'"), active: n("SELECT COUNT(*) n FROM users WHERE status='active'"), pending: n("SELECT COUNT(*) n FROM users WHERE status='pending'"), suspended: n("SELECT COUNT(*) n FROM users WHERE status='suspended'"), newWeek: n('SELECT COUNT(*) n FROM users WHERE created_at>?', week) },
    posts: { open: n("SELECT COUNT(*) n FROM posts WHERE status='open'"), jobs: n("SELECT COUNT(*) n FROM posts WHERE status='open' AND kind='job'"), services: n("SELECT COUNT(*) n FROM posts WHERE status='open' AND kind='service'") },
    orders,
    money: {
      volumeCents: n("SELECT COALESCE(SUM(amount_cents),0) n FROM orders WHERE status='released'"),
      feesCents: n("SELECT COALESCE(SUM(amount_cents),0) n FROM ledger WHERE kind='platform_fee'"),
      escrowCents: n("SELECT COALESCE(SUM(amount_cents),0) n FROM orders WHERE status IN ('in_escrow','delivered','disputed')"),
      owedCents: n('SELECT COALESCE(SUM(amount_cents),0) n FROM ledger WHERE user_id IS NOT NULL'),
      pendingWithdrawals: n("SELECT COUNT(*) n FROM withdrawals WHERE status='pending'"),
      pendingWithdrawalCents: n("SELECT COALESCE(SUM(amount_cents),0) n FROM withdrawals WHERE status='pending'"),
    },
    support: { openTickets: n("SELECT COUNT(*) n FROM tickets WHERE status IN ('open')"), openReports: n("SELECT COUNT(*) n FROM reports WHERE status='open'"), disputes: n("SELECT COUNT(*) n FROM orders WHERE status='disputed'") },
    email: { queued: n("SELECT COUNT(*) n FROM emails WHERE status='queued'"), failed: n("SELECT COUNT(*) n FROM emails WHERE status='failed'"), smtp: cfg.smtpOn },
    system: { paypalMode: paypal.mode, smtp: cfg.smtpOn, sms: cfg.smsOn },
  };
});

/* ---------- users ---------- */
route('GET', '/api/admin/users', { auth: S }, (ctx) => {
  const page = Math.max(1, parseInt(ctx.query.page, 10) || 1);
  const term = String(ctx.query.q || '').trim().slice(0, 80);
  const like = '%' + term.replace(/[\\%_]/g, (c) => '\\' + c) + '%';
  const where = term ? " WHERE (email LIKE ? ESCAPE '\\' OR name LIKE ? ESCAPE '\\' OR CAST(id AS TEXT)=?)" : '';
  const args = term ? [like, like, term] : [];
  const total = get(`SELECT COUNT(*) n FROM users${where}`, ...args).n;
  const rows = all(`SELECT id,email,phone,name,role,mode,status,email_verified,phone_verified,totp_on,country,created_at,last_login FROM users${where} ORDER BY id DESC LIMIT 25 OFFSET ?`, ...args, (page - 1) * 25);
  return { total, pages: Math.max(1, Math.ceil(total / 25)), users: rows.map((u) => ({ ...u, balanceCents: balanceOf(u.id) })) };
});

route('POST', '/api/admin/users/:id', { auth: A, limit: [100, 3600000] }, (ctx) => {
  const u = get('SELECT * FROM users WHERE id=?', ctx.params.id);
  if (!u) throw notFound('User not found.');
  if (u.id === ctx.user.id) throw bad('You cannot change your own role or status. Ask another admin.');
  const b = ctx.body, notes = [];
  if ('status' in b) {
    const st = U.oneOf(b.status, ['active', 'suspended'], 'Status');
    if (u.status === 'pending' || u.status === 'deleted') throw bad('Only active or suspended accounts can be changed.');
    run('UPDATE users SET status=? WHERE id=?', st, u.id);
    if (st === 'suspended') run('DELETE FROM sessions WHERE user_id=?', u.id);
    notes.push('status=' + st);
    notify(u.id, st === 'suspended' ? 'Your Jj Up account was suspended' : 'Your Jj Up account is active again', st === 'suspended' ? 'Your account was suspended. Contact support if you think this is a mistake.' : 'Your account was reactivated.', true);
  }
  if ('role' in b) {
    const role = U.oneOf(b.role, ['user', 'support', 'admin'], 'Role');
    if (role !== 'user' && (!u.email_verified || u.status !== 'active')) throw bad('Only verified, active users can be made staff.');
    run('UPDATE users SET role=? WHERE id=?', role, u.id);
    run('DELETE FROM sessions WHERE user_id=?', u.id);
    notes.push('role=' + role);
  }
  if (!notes.length) throw bad('Nothing to change.');
  audit(ctx.user.id, 'user_update', String(u.id), notes.join(' '), ctx.ip);
  return { ok: true };
});
route('POST', '/api/admin/users/:id/logout', { auth: A }, (ctx) => {
  run('DELETE FROM sessions WHERE user_id=?', ctx.params.id);
  audit(ctx.user.id, 'user_logout', ctx.params.id, '', ctx.ip);
  return { ok: true };
});

/* ---------- posts ---------- */
route('GET', '/api/admin/posts', { auth: S }, (ctx) => {
  const term = String(ctx.query.q || '').trim().slice(0, 80);
  const like = '%' + term.replace(/[\\%_]/g, (c) => '\\' + c) + '%';
  const rows = all(`SELECT p.id,p.kind,p.title,p.category,p.status,p.visibility,p.amount_cents,p.created_at,u.name author,u.id author_id FROM posts p JOIN users u ON u.id=p.author_id ${term ? "WHERE p.title LIKE ? ESCAPE '\\'" : ''} ORDER BY p.id DESC LIMIT 100`, ...(term ? [like] : []));
  return { posts: rows };
});
route('POST', '/api/admin/posts/:id', { auth: S, limit: [200, 3600000] }, (ctx) => {
  const st = U.oneOf(ctx.body.status, ['open', 'closed', 'removed'], 'Status');
  const p = get('SELECT * FROM posts WHERE id=?', ctx.params.id);
  if (!p) throw notFound('Post not found.');
  run('UPDATE posts SET status=? WHERE id=?', st, p.id);
  if (st === 'removed') {
    run("UPDATE proposals SET status='closed' WHERE post_id=? AND status='pending'", p.id);
    notify(p.author_id, 'A post of yours was removed', `Your post "${p.title}" was removed by the Jj Up team because it broke our rules. Contact support if you have questions.`, true);
  }
  audit(ctx.user.id, 'post_' + st, String(p.id), p.title, ctx.ip);
  return { ok: true };
});

/* ---------- orders and payments ---------- */
route('GET', '/api/admin/orders', { auth: S }, (ctx) => {
  const st = ctx.query.status;
  const rows = all(`SELECT o.*, c.name client_name, f.name free_name FROM orders o JOIN users c ON c.id=o.client_id JOIN users f ON f.id=o.freelancer_id ${st ? 'WHERE o.status=?' : ''} ORDER BY o.id DESC LIMIT 100`, ...(st ? [st] : []));
  return { orders: rows.map((o) => ({ id: o.id, title: o.title, status: o.status, amountCents: o.amount_cents, feeCents: o.fee_cents, client: o.client_name, clientId: o.client_id, freelancer: o.free_name, freelancerId: o.freelancer_id, createdAt: o.created_at, deliveredAt: o.delivered_at })) };
});
route('POST', '/api/admin/orders/:id/resolve', { auth: A, limit: [60, 3600000] }, async (ctx) => {
  const action = U.oneOf(ctx.body.action, ['release', 'refund'], 'Action');
  const o = get('SELECT * FROM orders WHERE id=?', ctx.params.id);
  if (!o) throw notFound('Order not found.');
  if (action === 'release') releaseOrder(o.id, ctx.user.id, ctx.ip, 'admin_release');
  else await refundOrder(o.id, ctx.user.id, ctx.ip).catch((e) => { if (e.status) throw e; throw bad('PayPal refund failed: ' + e.message); });
  run("UPDATE tickets SET status='resolved', updated_at=? WHERE order_id=? AND category='Dispute' AND status IN ('open','pending')", now(), o.id);
  return { ok: true };
});
route('GET', '/api/admin/payments', { auth: S }, () => ({
  payments: all('SELECT p.*, o.title, o.status order_status FROM payments p JOIN orders o ON o.id=p.order_id ORDER BY p.id DESC LIMIT 100'),
}));

/* ---------- withdrawals ---------- */
route('GET', '/api/admin/withdrawals', { auth: S }, (ctx) => {
  const st = ctx.query.status;
  return { withdrawals: all(`SELECT w.*, u.name, u.email FROM withdrawals w JOIN users u ON u.id=w.user_id ${st ? 'WHERE w.status=?' : ''} ORDER BY w.id DESC LIMIT 100`, ...(st ? [st] : [])) };
});
route('POST', '/api/admin/withdrawals/:id/approve', { auth: A, limit: [100, 3600000] }, async (ctx) => {
  const w = get('SELECT * FROM withdrawals WHERE id=?', ctx.params.id);
  if (!w || w.status !== 'pending') throw bad('This withdrawal is not waiting for approval.');
  await processWithdrawal(w.id, ctx.user.id, ctx.ip);
  return { status: get('SELECT status FROM withdrawals WHERE id=?', w.id).status };
});
route('POST', '/api/admin/withdrawals/:id/reject', { auth: A, limit: [100, 3600000] }, (ctx) => {
  const reason = U.str(ctx.body.reason, 'Reason', 3, 300);
  if (!rejectWithdrawal(Number(ctx.params.id), ctx.user.id, reason, ctx.ip)) throw bad('This withdrawal is not waiting for approval.');
  return { ok: true };
});

/* ---------- support ---------- */
route('GET', '/api/admin/tickets', { auth: S }, (ctx) => {
  const st = ctx.query.status;
  return { tickets: all(`SELECT t.id,t.subject,t.category,t.order_id,t.status,t.created_at,t.updated_at,u.name,u.email FROM tickets t JOIN users u ON u.id=t.user_id ${st ? 'WHERE t.status=?' : ''} ORDER BY CASE t.status WHEN 'open' THEN 0 WHEN 'pending' THEN 1 ELSE 2 END, t.updated_at DESC LIMIT 100`, ...(st ? [st] : [])) };
});
route('POST', '/api/admin/tickets/:id/status', { auth: S }, (ctx) => {
  const st = U.oneOf(ctx.body.status, ['open', 'pending', 'resolved', 'closed'], 'Status');
  const r = run('UPDATE tickets SET status=?, updated_at=? WHERE id=?', st, now(), ctx.params.id);
  if (!r.changes) throw notFound('Ticket not found.');
  audit(ctx.user.id, 'ticket_status', ctx.params.id, st, ctx.ip);
  return { ok: true };
});
route('GET', '/api/admin/reports', { auth: S }, () => ({
  reports: all(`SELECT r.*, u.name reporter,
    CASE r.target_type WHEN 'post' THEN (SELECT title FROM posts WHERE id=r.target_id) ELSE (SELECT name FROM users WHERE id=r.target_id) END target_label
    FROM reports r JOIN users u ON u.id=r.reporter_id ORDER BY CASE r.status WHEN 'open' THEN 0 ELSE 1 END, r.id DESC LIMIT 100`),
}));
route('POST', '/api/admin/reports/:id', { auth: S }, (ctx) => {
  const st = U.oneOf(ctx.body.status, ['actioned', 'dismissed', 'open'], 'Status');
  if (!run('UPDATE reports SET status=? WHERE id=?', st, ctx.params.id).changes) throw notFound('Report not found.');
  audit(ctx.user.id, 'report_' + st, ctx.params.id, '', ctx.ip);
  return { ok: true };
});

/* ---------- email, settings, audit ---------- */
route('GET', '/api/admin/emails', { auth: A }, (ctx) => {
  const st = ctx.query.status;
  return { emails: all(`SELECT id,to_addr,subject,status,attempts,error,created_at,sent_at FROM emails ${st ? 'WHERE status=?' : ''} ORDER BY id DESC LIMIT 100`, ...(st ? [st] : [])) };
});
route('POST', '/api/admin/emails/:id/retry', { auth: A }, async (ctx) => {
  run("UPDATE emails SET status='queued', attempts=0 WHERE id=? AND status IN ('failed','logged')", ctx.params.id);
  await flush();
  return { ok: true };
});
route('POST', '/api/admin/announce', { auth: A, limit: [5, 3600000] }, (ctx) => {
  const subject = U.str(ctx.body.subject, 'Subject', 5, 150);
  const body = U.str(ctx.body.body, 'Message', 10, 4000);
  const users = all("SELECT email FROM users WHERE status='active' AND email_verified=1");
  for (const u of users) queue(u.email, subject, body + '\n\n-- The Jj Up team');
  audit(ctx.user.id, 'announce', String(users.length), subject, ctx.ip);
  return { sent: users.length };
});

const SETTINGS = {
  fee_pct: (v) => { const n = parseFloat(v); if (!(n >= 0 && n <= 50)) throw bad('Fee must be between 0 and 50 percent.'); return String(n); },
  min_withdraw: (v) => { const n = parseFloat(v); if (!(n >= 1 && n <= 10000)) throw bad('Minimum withdrawal must be between $1 and $10,000.'); return String(n); },
  auto_release_days: (v) => { const n = parseInt(v, 10); if (!(n >= 1 && n <= 60)) throw bad('Auto-release must be 1 to 60 days.'); return String(n); },
  manual_withdrawals: (v) => (v ? '1' : '0'),
  signups_open: (v) => (v ? '1' : '0'),
  maintenance: (v) => (v ? '1' : '0'),
};
route('GET', '/api/admin/settings', { auth: A }, () => ({ settings: Object.fromEntries(Object.keys(SETTINGS).map((k) => [k, setting(k)])) }));
route('POST', '/api/admin/settings', { auth: A, maintenanceOk: true, limit: [60, 3600000] }, (ctx) => {
  const changed = [];
  for (const k of Object.keys(SETTINGS)) {
    if (k in ctx.body) { const v = SETTINGS[k](ctx.body[k]); if (v !== setting(k)) { setSetting(k, v); changed.push(`${k}=${v}`); } }
  }
  if (changed.length) audit(ctx.user.id, 'settings', '', changed.join(' '), ctx.ip);
  return { ok: true };
});
route('GET', '/api/admin/audit', { auth: A }, (ctx) => {
  const page = Math.max(1, parseInt(ctx.query.page, 10) || 1);
  return { entries: all('SELECT a.*, u.email actor FROM audit a LEFT JOIN users u ON u.id=a.actor_id ORDER BY a.id DESC LIMIT 50 OFFSET ?', (page - 1) * 50) };
});

/* ---------- PayPal webhook (verified with PayPal before anything is trusted) ---------- */
route('POST', '/api/paypal/webhook', { noCsrf: true, raw: true, bodyLimit: 200 * 1024, limit: [120, 60000] }, async (ctx) => {
  const ok = await paypal.verifyWebhook(ctx.req.headers, ctx.body).catch(() => false);
  if (!ok) throw new U.HttpError(400, 'Bad signature');
  const ev = JSON.parse(ctx.body.toString('utf8'));
  if (get('SELECT 1 x FROM webhook_events WHERE id=?', ev.id)) return { ok: true };
  run('INSERT INTO webhook_events(id,created_at) VALUES(?,?)', ev.id, now());
  const type = String(ev.event_type || '');
  if (/^PAYMENT\.CAPTURE\.(REVERSED|DENIED|REFUNDED)$|^CUSTOMER\.DISPUTE\./.test(type)) {
    const r = ev.resource || {};
    const up = ((r.links || []).find((l) => l.rel === 'up') || {}).href || '';
    const capId = type.startsWith('PAYMENT.CAPTURE.REFUNDED') ? up.split('/').pop() : r.id;
    const pay = capId && get('SELECT * FROM payments WHERE capture_id=?', capId);
    if (pay) {
      run("UPDATE orders SET status='disputed' WHERE id=? AND status IN ('in_escrow','delivered')", pay.order_id);
      audit(null, 'paypal_' + type, String(pay.order_id), `capture ${capId}`, ctx.ip);
    } else audit(null, 'paypal_' + type, '', 'no matching payment', ctx.ip);
    for (const a of all("SELECT email FROM users WHERE role='admin' AND status='active'")) queue(a.email, `PayPal event: ${type}`, `PayPal sent ${type}${pay ? ` for order #${pay.order_id}` : ''}. Check the admin dashboard: ${cfg.appUrl}/#/admin`);
  }
  return { ok: true };
});
