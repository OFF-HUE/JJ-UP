'use strict';
const cfg = require('../config');
const { route, cookie, sha } = require('../lib/http');
const { get, all, run, tx, setting, now, audit } = require('../lib/db');
const U = require('../lib/util');
const A = require('../lib/auth');
const mail = require('../lib/mail');
const { balanceOf } = require('../lib/money');
const paypal = require('../lib/paypal');

const { HttpError, bad } = U;

function publicMe(u) {
  return {
    id: u.id, email: u.email, phone: u.phone, name: u.name, role: u.role, mode: u.mode,
    email_verified: !!u.email_verified, phone_verified: !!u.phone_verified,
    headline: u.headline, skills: u.skills, bio: u.bio, country: u.country, paypal_email: u.paypal_email,
    profile_public: !!u.profile_public, allow_messages: u.allow_messages, notify_email: !!u.notify_email,
    totp_on: !!u.totp_on, created_at: u.created_at,
  };
}

route('GET', '/api/config', () => ({
  appName: 'Jj Up',
  categories: cfg.categories,
  feePct: parseFloat(setting('fee_pct')),
  minWithdraw: parseFloat(setting('min_withdraw')),
  signupsOpen: setting('signups_open') === '1',
  maintenance: setting('maintenance') === '1',
  requirePhone: cfg.requirePhone,
  paypal: { mode: paypal.mode, clientId: paypal.mode === 'mock' ? '' : cfg.paypal.clientId },
}));

route('GET', '/api/me', (ctx) => ({ user: ctx.user ? publicMe(ctx.user) : null }));

function sendCodes(user, devOut) {
  const ec = A.issueCode(user.id, 'email', 15 * 60000);
  mail.queue(user.email, 'Your Jj Up verification code', `Hi ${user.name.split(' ')[0]},\n\nYour Jj Up code is ${ec}. It expires in 15 minutes.\n\nIf you did not sign up, ignore this email.`);
  devOut.email = ec;
  if (cfg.requirePhone && user.phone) {
    const pc = A.issueCode(user.id, 'phone', 15 * 60000);
    mail.smsSend(user.phone, `Your Jj Up code is ${pc}`).catch((e) => console.error('[sms]', e.message));
    devOut.phone = pc;
  }
}
const devVisible = () => !cfg.prod && !cfg.smtpOn;

route('POST', '/api/auth/signup', { limit: [10, 3600000] }, async (ctx) => {
  if (setting('signups_open') !== '1') throw new HttpError(403, 'New sign-ups are paused. Please try again later.');
  const b = ctx.body;
  const name = U.str(b.name, 'Name', 2, 80);
  const email = U.email(b.email);
  const phone = U.phone(b.phone);
  if (!phone) throw bad('Phone number is required.');
  const mode = b.mode === 'freelancer' ? 'freelancer' : 'client';
  const problem = A.passwordProblem(b.password, email);
  if (problem) throw bad(problem);
  const pw_hash = await A.hashPassword(b.password);

  const dev = {};
  const existing = get('SELECT * FROM users WHERE email=?', email);
  if (!existing) {
    const id = run('INSERT INTO users(email,phone,name,pw_hash,mode,status,created_at) VALUES(?,?,?,?,?,?,?)', email, phone, name, pw_hash, mode, 'pending', now()).id;
    sendCodes(get('SELECT * FROM users WHERE id=?', id), dev);
  } else if (existing.status === 'pending') {
    run('UPDATE users SET name=?, phone=?, pw_hash=?, mode=? WHERE id=?', name, phone, pw_hash, mode, existing.id);
    sendCodes(get('SELECT * FROM users WHERE id=?', existing.id), dev);
  } else {
    // Same response either way, so signup cannot be used to discover who has an account.
    mail.queue(email, 'You already have a Jj Up account', `Someone tried to sign up with this email. You already have an account, so just log in at ${cfg.appUrl}. If you forgot your password, use "Forgot password" on the login page.`);
  }
  return { ok: true, needPhone: cfg.requirePhone, ...(devVisible() && dev.email ? { devCodes: dev } : {}) };
});

route('POST', '/api/auth/resend', { limit: [6, 3600000] }, (ctx) => {
  const email = U.email(ctx.body.email);
  const u = get("SELECT * FROM users WHERE email=? AND status='pending'", email);
  const dev = {};
  if (u) {
    const last = get("SELECT created_at FROM codes WHERE user_id=? AND kind='email'", u.id);
    if (last && last.created_at > now() - 30000) throw new HttpError(429, 'Wait 30 seconds before asking for another code.');
    sendCodes(u, dev);
  }
  return { ok: true, ...(devVisible() && dev.email ? { devCodes: dev } : {}) };
});

function startSession(ctx, user) {
  const age = A.sessionAge(user.role);
  const sid = A.newSession(user.id, ctx.ip, ctx.req.headers['user-agent'], age);
  ctx.setCookie(cookie('jj_sid', sid, Math.floor(age / 1000)));
}

route('POST', '/api/auth/verify', { limit: [15, 3600000] }, (ctx) => {
  const email = U.email(ctx.body.email);
  const u = get("SELECT * FROM users WHERE email=? AND status='pending'", email);
  const fail = () => { throw bad('That code is not correct or has expired. Request a new one.'); };
  if (!u) fail();
  const needPhone = cfg.requirePhone;
  const okEmail = A.checkCode(u.id, 'email', ctx.body.code, false);
  const okPhone = needPhone ? A.checkCode(u.id, 'phone', ctx.body.phoneCode, false) : true;
  if (!okEmail || !okPhone) fail();
  A.consumeCode(u.id, 'email');
  if (needPhone) A.consumeCode(u.id, 'phone');
  run("UPDATE users SET status='active', email_verified=1, phone_verified=?, last_login=? WHERE id=?", needPhone ? 1 : 0, now(), u.id);
  const fresh = get('SELECT * FROM users WHERE id=?', u.id);
  startSession(ctx, fresh);
  return { user: publicMe(fresh) };
});

route('POST', '/api/auth/login', { limit: [20, 900000] }, async (ctx) => {
  const email = U.email(ctx.body.email);
  const password = U.str(ctx.body.password, 'Password', 1, 200);
  const u = get('SELECT * FROM users WHERE email=?', email);
  const generic = () => new HttpError(401, 'Email or password is not correct.');
  if (!u || u.status === 'deleted') { await A.dummyVerify(password); throw generic(); }
  if (u.locked_until > now()) throw new HttpError(429, 'Too many failed attempts. Try again in 15 minutes or reset your password.');
  const ok = await A.verifyPassword(password, u.pw_hash);
  const failIt = () => {
    const n = u.failed_logins + 1;
    if (n >= 5) run('UPDATE users SET failed_logins=0, locked_until=? WHERE id=?', now() + 900000, u.id);
    else run('UPDATE users SET failed_logins=? WHERE id=?', n, u.id);
    audit(u.id, 'login_failed', u.email, '', ctx.ip);
    return generic();
  };
  if (!ok) throw failIt();
  if (u.status === 'pending') throw new HttpError(403, 'Please verify your email first.', { needVerify: true });
  if (u.status === 'suspended') throw new HttpError(403, 'This account is suspended. Contact support to find out why.');
  if (u.totp_on) {
    if (!ctx.body.totp) return { needTotp: true };
    if (!A.totpValid(u.totp_secret, ctx.body.totp)) throw failIt();
  }
  run('UPDATE users SET failed_logins=0, locked_until=0, last_login=? WHERE id=?', now(), u.id);
  startSession(ctx, u);
  if (u.role !== 'user') audit(u.id, 'staff_login', u.email, '', ctx.ip);
  return { user: publicMe(u) };
});

route('POST', '/api/auth/logout', (ctx) => {
  if (ctx.session) run('DELETE FROM sessions WHERE id=?', ctx.session.id);
  ctx.setCookie(cookie('jj_sid', '', 0));
  return { ok: true };
});

route('POST', '/api/auth/forgot', { limit: [6, 3600000] }, (ctx) => {
  const email = U.email(ctx.body.email);
  const u = get("SELECT * FROM users WHERE email=? AND status IN ('active','suspended')", email);
  const dev = {};
  if (u && u.status === 'active') {
    const code = A.issueCode(u.id, 'reset', 15 * 60000);
    mail.queue(u.email, 'Reset your Jj Up password', `Your password reset code is ${code}. It expires in 15 minutes.\n\nIf you did not ask for this, you can ignore this email. Your password will not change.`);
    dev.email = code;
  }
  return { ok: true, ...(devVisible() && dev.email ? { devCodes: dev } : {}) };
});

route('POST', '/api/auth/reset', { limit: [10, 3600000] }, async (ctx) => {
  const email = U.email(ctx.body.email);
  const u = get("SELECT * FROM users WHERE email=? AND status='active'", email);
  const problem = A.passwordProblem(ctx.body.password, email);
  if (problem) throw bad(problem);
  if (!u || !A.checkCode(u.id, 'reset', ctx.body.code)) throw bad('That code is not correct or has expired.');
  const h = await A.hashPassword(ctx.body.password);
  run('UPDATE users SET pw_hash=?, failed_logins=0, locked_until=0 WHERE id=?', h, u.id);
  run('DELETE FROM sessions WHERE user_id=?', u.id);
  audit(u.id, 'password_reset', u.email, '', ctx.ip);
  mail.notify(u.id, 'Your Jj Up password was changed', 'Your password was just reset. If this was not you, contact support right away.', true);
  return { ok: true };
});

route('POST', '/api/auth/password', { auth: 'user', limit: [10, 3600000] }, async (ctx) => {
  const u = ctx.user;
  if (!(await A.verifyPassword(String(ctx.body.current || ''), u.pw_hash))) throw bad('Your current password is not correct.');
  const problem = A.passwordProblem(ctx.body.password, u.email);
  if (problem) throw bad(problem);
  const h = await A.hashPassword(ctx.body.password);
  run('UPDATE users SET pw_hash=? WHERE id=?', h, u.id);
  run('DELETE FROM sessions WHERE user_id=? AND id<>?', u.id, ctx.session.id);
  audit(u.id, 'password_change', u.email, '', ctx.ip);
  mail.notify(u.id, 'Your Jj Up password was changed', 'Your password was just changed and other devices were logged out. If this was not you, contact support right away.', true);
  return { ok: true };
});

/* ---------- two-step login (authenticator app) ---------- */
route('POST', '/api/2fa/setup', { auth: 'user', limit: [10, 3600000] }, (ctx) => {
  if (ctx.user.totp_on) throw bad('Two-step login is already on.');
  const secret = A.newTotpSecret();
  run('UPDATE users SET totp_secret=? WHERE id=?', secret, ctx.user.id);
  return { secret, uri: `otpauth://totp/Jj%20Up:${encodeURIComponent(ctx.user.email)}?secret=${secret}&issuer=Jj%20Up` };
});
route('POST', '/api/2fa/enable', { auth: 'user', limit: [10, 3600000] }, (ctx) => {
  if (!ctx.user.totp_secret || !A.totpValid(ctx.user.totp_secret, ctx.body.code)) throw bad('That code is not correct. Check the code in your authenticator app.');
  run('UPDATE users SET totp_on=1 WHERE id=?', ctx.user.id);
  audit(ctx.user.id, '2fa_on', ctx.user.email, '', ctx.ip);
  return { ok: true };
});
route('POST', '/api/2fa/disable', { auth: 'user', limit: [10, 3600000] }, async (ctx) => {
  if (!ctx.user.totp_on) return { ok: true };
  if (!(await A.verifyPassword(String(ctx.body.password || ''), ctx.user.pw_hash))) throw bad('Your password is not correct.');
  if (!A.totpValid(ctx.user.totp_secret, ctx.body.code)) throw bad('That code is not correct.');
  run("UPDATE users SET totp_on=0, totp_secret='' WHERE id=?", ctx.user.id);
  audit(ctx.user.id, '2fa_off', ctx.user.email, '', ctx.ip);
  return { ok: true };
});

/* ---------- profile and privacy ---------- */
route('POST', '/api/me', { auth: 'user', limit: [60, 3600000] }, (ctx) => {
  const b = ctx.body, u = ctx.user, set = {};
  if ('name' in b) set.name = U.str(b.name, 'Name', 2, 80);
  if ('headline' in b) set.headline = U.optStr(b.headline, 'Headline', 120);
  if ('skills' in b) set.skills = U.optStr(b.skills, 'Skills', 300);
  if ('bio' in b) set.bio = U.optStr(b.bio, 'About', 1500);
  if ('country' in b) set.country = U.optStr(b.country, 'Country', 60);
  if ('mode' in b) set.mode = U.oneOf(b.mode, ['client', 'freelancer'], 'Role');
  if ('profile_public' in b) set.profile_public = b.profile_public ? 1 : 0;
  if ('allow_messages' in b) set.allow_messages = U.oneOf(b.allow_messages, ['anyone', 'connections'], 'Message setting');
  if ('notify_email' in b) set.notify_email = b.notify_email ? 1 : 0;
  if ('paypal_email' in b) set.paypal_email = b.paypal_email ? U.email(b.paypal_email, 'PayPal email') : '';
  if ('phone' in b) {
    const p = U.phone(b.phone);
    if (!p) throw bad('Phone number is required.');
    if (p !== u.phone) { set.phone = p; set.phone_verified = 0; }
  }
  const keys = Object.keys(set);
  if (keys.length) {
    if (set.paypal_email !== undefined && set.paypal_email !== u.paypal_email) audit(u.id, 'paypal_email_change', u.email, `${u.paypal_email} -> ${set.paypal_email}`, ctx.ip);
    run(`UPDATE users SET ${keys.map((k) => k + '=?').join(',')} WHERE id=?`, ...keys.map((k) => set[k]), u.id);
    if (set.paypal_email !== undefined && set.paypal_email !== u.paypal_email) mail.notify(u.id, 'Your PayPal payout email changed', `Your payout PayPal email was changed to ${set.paypal_email || '(none)'}. If this was not you, change your password and contact support.`, true);
  }
  return { user: publicMe(get('SELECT * FROM users WHERE id=?', u.id)) };
});

route('GET', '/api/sessions', { auth: 'user' }, (ctx) => ({
  sessions: all('SELECT id,created_at,ip,ua FROM sessions WHERE user_id=? ORDER BY created_at DESC', ctx.user.id).map((s) => ({ ...s, id: sha(s.id).slice(0, 12), current: s.id === ctx.session.id })),
}));
route('POST', '/api/sessions/logout-others', { auth: 'user' }, (ctx) => {
  run('DELETE FROM sessions WHERE user_id=? AND id<>?', ctx.user.id, ctx.session.id);
  return { ok: true };
});

route('POST', '/api/me/delete', { auth: 'user', limit: [5, 3600000] }, async (ctx) => {
  const u = ctx.user;
  if (u.role !== 'user') throw bad('Staff accounts must be demoted by an admin before they can be deleted.');
  if (!(await A.verifyPassword(String(ctx.body.password || ''), u.pw_hash))) throw bad('Your password is not correct.');
  tx(() => {
    const open = get("SELECT COUNT(*) n FROM orders WHERE (client_id=? OR freelancer_id=?) AND status IN ('awaiting_payment','in_escrow','delivered','disputed')", u.id, u.id).n;
    if (open) throw bad('Finish or cancel your open orders before deleting your account.');
    if (balanceOf(u.id) > 0) throw bad('Withdraw your balance before deleting your account.');
    if (get("SELECT COUNT(*) n FROM withdrawals WHERE user_id=? AND status IN ('pending','processing')", u.id).n) throw bad('Wait for your pending withdrawal to finish first.');
    run("UPDATE posts SET status='closed' WHERE author_id=? AND status='open'", u.id);
    run("UPDATE proposals SET status='withdrawn' WHERE freelancer_id=? AND status='pending'", u.id);
    run("UPDATE users SET status='deleted', email=?, name='Deleted user', phone='', headline='', skills='', bio='', country='', paypal_email='', totp_secret='', totp_on=0, pw_hash='x' WHERE id=?", `deleted-${u.id}@deleted.invalid`, u.id);
    run('DELETE FROM sessions WHERE user_id=?', u.id);
    audit(u.id, 'account_deleted', String(u.id), '', ctx.ip);
  });
  ctx.setCookie(cookie('jj_sid', '', 0));
  return { ok: true };
});

module.exports = { publicMe };
