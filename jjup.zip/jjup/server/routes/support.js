'use strict';
const cfg = require('../config');
const { route } = require('../lib/http');
const { get, all, run, tx, now, audit } = require('../lib/db');
const U = require('../lib/util');
const { notify, queue } = require('../lib/mail');

const { bad, notFound, forbidden } = U;
const CATS = ['Payment', 'Withdrawal', 'Dispute', 'Account', 'Report a bug', 'Other'];

route('GET', '/api/tickets/categories', () => ({ categories: CATS }));

route('GET', '/api/tickets', { auth: 'user' }, (ctx) => ({
  tickets: all('SELECT id,subject,category,order_id,status,created_at,updated_at FROM tickets WHERE user_id=? ORDER BY updated_at DESC LIMIT 100', ctx.user.id),
}));

route('POST', '/api/tickets', { auth: 'user', limit: [10, 3600000] }, (ctx) => {
  const b = ctx.body;
  const subject = U.str(b.subject, 'Subject', 5, 150);
  const category = U.oneOf(b.category, CATS, 'Category');
  const body = U.str(b.body, 'Message', 10, 4000);
  let orderId = null;
  if (b.orderId) {
    orderId = U.int(b.orderId, 'Order', 1, 1e12);
    const o = get('SELECT client_id,freelancer_id FROM orders WHERE id=?', orderId);
    if (!o || (o.client_id !== ctx.user.id && o.freelancer_id !== ctx.user.id)) throw bad('That order is not yours.');
  }
  const id = tx(() => {
    const tid = run('INSERT INTO tickets(user_id,subject,category,order_id,created_at,updated_at) VALUES(?,?,?,?,?,?)', ctx.user.id, subject, category, orderId, now(), now()).id;
    run('INSERT INTO ticket_messages(ticket_id,author_id,body,created_at) VALUES(?,?,?,?)', tid, ctx.user.id, body, now());
    return tid;
  });
  for (const a of all("SELECT email FROM users WHERE role IN ('admin','support') AND status='active'")) queue(a.email, `New support ticket #${id}: ${subject}`, `${ctx.user.name} (${ctx.user.email}) opened a ${category} ticket:\n\n${body.slice(0, 500)}\n\n${cfg.appUrl}/#/admin`);
  notify(ctx.user.id, `We got your support request #${id}`, `Thanks for writing to Jj Up support. We will reply here and by email. Your ticket: "${subject}".`, true);
  return { id };
});

function ticketFor(id, user) {
  const t = get('SELECT t.*, u.name user_name, u.email user_email FROM tickets t JOIN users u ON u.id=t.user_id WHERE t.id=?', id);
  if (!t || (t.user_id !== user.id && user.role === 'user')) throw notFound('Ticket not found.');
  return t;
}
route('GET', '/api/tickets/:id', { auth: 'user' }, (ctx) => {
  const t = ticketFor(ctx.params.id, ctx.user);
  const staff = ctx.user.role !== 'user';
  const msgs = all('SELECT m.id,m.body,m.staff,m.created_at,m.author_id,u.name FROM ticket_messages m JOIN users u ON u.id=m.author_id WHERE m.ticket_id=? ORDER BY m.id', t.id);
  return {
    ticket: { id: t.id, subject: t.subject, category: t.category, orderId: t.order_id, status: t.status, createdAt: t.created_at, updatedAt: t.updated_at, ...(staff ? { userId: t.user_id, userName: t.user_name, userEmail: t.user_email } : {}) },
    messages: msgs.map((m) => ({ id: m.id, staff: !!m.staff, name: m.staff ? 'Jj Up Support' : m.name, body: m.body, at: m.created_at, mine: m.author_id === ctx.user.id })),
  };
});

route('POST', '/api/tickets/:id/reply', { auth: 'user', limit: [60, 3600000] }, (ctx) => {
  const t = ticketFor(ctx.params.id, ctx.user);
  const staff = ctx.user.role !== 'user' && t.user_id !== ctx.user.id;
  const body = U.str(ctx.body.body, 'Message', 1, 4000);
  if (t.status === 'closed' && !staff) throw bad('This ticket is closed. Open a new one if you still need help.');
  tx(() => {
    run('INSERT INTO ticket_messages(ticket_id,author_id,staff,body,created_at) VALUES(?,?,?,?,?)', t.id, ctx.user.id, staff ? 1 : 0, body, now());
    run('UPDATE tickets SET status=?, updated_at=? WHERE id=?', staff ? 'pending' : 'open', now(), t.id);
    if (staff) audit(ctx.user.id, 'ticket_reply', String(t.id), '', ctx.ip);
  });
  if (staff) notify(t.user_id, `Support replied to ticket #${t.id}`, `Our team replied to "${t.subject}":\n\n${body.slice(0, 800)}`, true);
  return { ok: true };
});
