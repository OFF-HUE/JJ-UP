(function () {
'use strict';
var JJ = window.JJ, esc = JJ.esc, money = JJ.money;

/* ---------- browse ---------- */
function priceOf(p) { return (p.kind === 'service' ? 'From ' : '') + money(p.amountCents) + (p.priceType === 'hourly' ? '/hr' : ''); }
JJ.postCard = function (p) {
  return '<article class="card post"><div class="row"><span class="chip">' + esc(p.category) + '</span>' + (p.visibility === 'unlisted' ? '<span class="pill muted">Link only</span>' : '') + (p.status !== 'open' ? JJ.pill(p.status) : '') + '</div>' +
    '<h3><a href="#/post/' + p.id + '">' + esc(p.title) + '</a></h3><p class="desc">' + esc(p.description) + '</p><div class="price num">' + priceOf(p) + '</div>' +
    '<div class="who">' + JJ.avatar(p.author.name) + '<div><a href="#/user/' + p.author.id + '"><b>' + esc(p.author.name) + '</b></a><div class="small muted">' + JJ.ago(p.createdAt) + '</div></div></div></article>';
};

JJ.route('/', async function (_, q) {
  var kind = q.kind === 'service' ? 'service' : 'job', page = parseInt(q.page, 10) || 1;
  var qs = new URLSearchParams({ kind: kind, page: page });
  if (q.q) qs.set('q', q.q); if (q.cat) qs.set('category', q.cat);
  var r = await JJ.get('/api/posts?' + qs), u = JJ.S.user, cfg = JJ.S.config;
  var hero = u ? '' :
    '<section class="hero"><h1>Hire talent. Get hired. Move up.</h1><p class="lede">Post a job or offer a service. Chat directly, agree a price, and pay safely: your money is held until the work is delivered.</p>' +
    '<ol class="steps"><li>Clients post a job, or freelancers list a service</li><li>Freelancers send proposals and chat with the client</li><li>The client pays with PayPal or a card. Jj Up holds the money</li><li>The client releases payment when the work is delivered</li></ol>' +
    '<div class="row"><a class="btn" href="#/signup">Create a free account</a><a class="btn ghost" href="#/login">Log in</a></div></section>';
  var cats = [['', 'All categories']].concat(cfg.categories.map(function (c) { return [c, c]; }));
  var html = hero +
    '<div class="row between"><div class="tabs" role="group" aria-label="Post type"><button data-act="browse-kind" data-kind="job" aria-pressed="' + (kind === 'job') + '">Jobs</button><button data-act="browse-kind" data-kind="service" aria-pressed="' + (kind === 'service') + '">Services</button></div>' +
    (u ? '<a class="btn" href="#/my?new=' + (kind === 'job' ? 'job' : 'service') + '">' + (kind === 'job' ? 'Post a job' : 'Offer a service') + '</a>' : '') + '</div>' +
    '<form class="row" data-form="browse" style="align-items:end"><div class="field" style="flex:2;min-width:180px"><label for="f-q">Search</label><input id="f-q" name="q" type="search" value="' + esc(q.q || '') + '" placeholder="Search ' + (kind === 'job' ? 'jobs' : 'services') + '"></div>' +
    '<div class="field" style="flex:1;min-width:160px"><label for="f-cat">Category</label><select id="f-cat" name="cat">' + cats.map(function (c) { return '<option value="' + esc(c[0]) + '"' + (c[0] === (q.cat || '') ? ' selected' : '') + '>' + esc(c[1]) + '</option>'; }).join('') + '</select></div><input type="hidden" name="kind" value="' + kind + '"><button class="btn" type="submit">Search</button></form>' +
    (r.posts.length ? '<div class="grid">' + r.posts.map(JJ.postCard).join('') + '</div>' + JJ.pager(r.page, r.pages, 'browse-page') :
      JJ.empty('<p>No ' + (kind === 'job' ? 'jobs' : 'services') + ' match yet.</p>' + (u ? '<p><a href="#/my?new=' + kind + '">Be the first to post</a></p>' : '<p><a href="#/signup">Create an account</a> to post.</p>')));
  return html;
});
function browseUrl(over) {
  var q = Object.assign({}, JJ.query(), over), p = new URLSearchParams();
  Object.keys(q).forEach(function (k) { if (q[k] && !(k === 'page' && q[k] == 1)) p.set(k, q[k]); });
  return '/?' + p;
}
JJ.acts['browse-kind'] = function (el) { JJ.go(browseUrl({ kind: el.dataset.kind, page: 1, q: '', cat: '' })); };
JJ.acts['browse-page'] = function (el) { JJ.go(browseUrl({ page: el.dataset.page })); };
JJ.forms.browse = function (_, d) { JJ.go(browseUrl({ q: d.q, cat: d.cat, kind: d.kind, page: 1 })); };

/* ---------- post detail ---------- */
JJ.route('/post/:id', async function (p) {
  var post = await JJ.get('/api/posts/' + p.id), u = JJ.S.user, isJob = post.kind === 'job';
  var login = '<a class="btn" href="#/login?next=' + encodeURIComponent('/post/' + post.id) + '">Log in to ' + (isJob ? 'send a proposal' : 'hire') + '</a>';
  var side = '';
  if (post.mine) {
    side = '<div class="card stack"><h3>Manage this post</h3><div class="row">' +
      (post.status === 'open' ? '<button class="btn ghost sm" data-act="post-status" data-id="' + post.id + '" data-v="closed">Close</button>' : post.status === 'closed' ? '<button class="btn ghost sm" data-act="post-status" data-id="' + post.id + '" data-v="open">Reopen</button>' : '') +
      '<button class="btn ghost sm" data-act="post-vis" data-id="' + post.id + '" data-v="' + (post.visibility === 'public' ? 'unlisted' : 'public') + '">' + (post.visibility === 'public' ? 'Make private (link only)' : 'Make public') + '</button>' +
      '<button class="btn danger sm" data-act="post-delete" data-id="' + post.id + '">Delete</button></div>' +
      '<p class="small muted">' + (post.visibility === 'public' ? 'Public: listed in search.' : 'Private: not listed. Anyone with the link can open it.') + '</p></div>';
  } else if (!u) side = '<div class="card stack"><h3>' + (isJob ? 'Interested in this job?' : 'Want to hire this person?') + '</h3>' + login + '</div>';
  else if (post.status !== 'open') side = '<div class="card"><p class="muted">This ' + post.kind + ' is not taking new ' + (isJob ? 'proposals' : 'orders') + '.</p></div>';
  else if (isJob) {
    side = post.myProposal
      ? '<div class="card stack"><h3>Your proposal</h3><div class="row">' + JJ.pill(post.myProposal.status) + '<span class="price num">' + money(post.myProposal.price_cents) + '</span><span class="muted small">in ' + post.myProposal.days + ' days</span></div><p class="small muted">The client will review it. You will get an email when they respond.</p></div>'
      : '<form class="card form" data-form="proposal" data-id="' + post.id + '"><h3>Send a proposal</h3>' + JJ.area('cover', 'Cover letter', { ph: 'Why you are the right person for this job', max: 2000 }) +
        '<div class="two">' + JJ.field('price', 'Your price (USD)', 'text', { attrs: 'inputmode="decimal"', ph: String(post.amountCents / 100) }) + JJ.field('days', 'Delivery (days)', 'number', { attrs: 'min="1" max="365"', value: 7 }) + '</div><div class="formerr"></div><button class="btn" type="submit">Send proposal</button></form>';
  } else {
    side = '<form class="card form" data-form="hire" data-id="' + post.id + '"><h3>Hire for ' + priceOf(post) + '</h3>' +
      (post.priceType === 'hourly' ? JJ.field('hours', 'Hours', 'number', { attrs: 'min="1" max="500"', value: 5 }) : '') +
      '<p class="small muted">You pay through PayPal on the next screen. Jj Up holds the money until you release it.</p><div class="formerr"></div><button class="btn" type="submit">Hire and continue to payment</button></form>';
  }
  var props = '';
  if (post.mine && isJob) {
    props = '<section class="stack"><h2>Proposals (' + post.proposals.length + ')</h2>' + (post.proposals.length ? post.proposals.map(function (x) {
      return '<article class="card stack"><div class="row between"><div class="who">' + JJ.avatar(x.name) + '<div><a href="#/user/' + x.freelancerId + '"><b>' + esc(x.name) + '</b></a><div class="small muted">' + esc(x.headline) + '</div></div></div>' + JJ.pill(x.status) + '</div><p class="pre">' + esc(x.cover) + '</p><div class="row between"><span class="price num">' + money(x.priceCents) + ' <span class="small muted" style="font-weight:400">in ' + x.days + ' days</span></span><div class="row">' +
        (x.status === 'pending' ? '<button class="btn sm" data-act="prop-accept" data-id="' + x.id + '">Accept</button><button class="btn ghost sm" data-act="prop-decline" data-id="' + x.id + '">Decline</button>' : '') + '<a class="btn ghost sm" href="#/messages/' + x.freelancerId + '">Message</a></div></div></article>';
    }).join('') : JJ.empty('No proposals yet. You will get an email when someone sends one.')) + '</section>';
  }
  var report = u && !post.mine ? '<details class="card"><summary class="small">Report this post</summary><form class="form" data-form="report" data-id="' + post.id + '" data-type="post" style="margin-top:12px">' + JJ.area('reason', 'What is wrong with it?', { max: 1000 }) + '<div class="formerr"></div><button class="btn ghost sm" type="submit">Send report</button></form></details>' : '';
  return '<div class="row"><a href="#/" class="small">Back to browse</a></div><div class="detail"><div class="stack"><article class="card stack"><div class="row"><span class="chip">' + esc(post.category) + '</span>' + JJ.pill(post.status) + '<span class="pill info">' + (isJob ? 'Job' : 'Service') + '</span></div><h1 style="font-size:1.7rem">' + esc(post.title) + '</h1><div class="price num">' + priceOf(post) + '</div><p class="pre">' + esc(post.description) + '</p>' +
    '<div class="row between"><div class="who">' + JJ.avatar(post.author.name) + '<div><a href="#/user/' + post.author.id + '"><b>' + esc(post.author.name) + '</b></a><div class="small muted">' + esc(post.author.headline) + ' ' + (post.author.country ? '· ' + esc(post.author.country) : '') + '</div></div></div>' + (!post.mine ? '<a class="btn ghost sm" href="#' + (u ? '/messages/' + post.author.id : '/login?next=' + encodeURIComponent('/post/' + post.id)) + '">Message</a>' : '') + '</div><div class="small muted">Posted ' + JJ.ago(post.createdAt) + '</div></article>' + props + '</div><div class="stack">' + side + report + '</div></div>';
});
JJ.acts['post-status'] = async function (el) { await JJ.post('/api/posts/' + el.dataset.id + '/update', { status: el.dataset.v }); JJ.toast('Saved'); JJ.nav(); };
JJ.acts['post-vis'] = async function (el) { await JJ.post('/api/posts/' + el.dataset.id + '/update', { visibility: el.dataset.v }); JJ.toast('Saved'); JJ.nav(); };
JJ.acts['post-delete'] = async function (el) {
  if (!JJ.sure(el, 'Click again to delete')) return;
  await JJ.post('/api/posts/' + el.dataset.id + '/delete'); JJ.toast('Post deleted'); JJ.go('/my');
};
JJ.acts['prop-accept'] = async function (el) { var r = await JJ.post('/api/proposals/' + el.dataset.id + '/accept'); JJ.toast('Proposal accepted. Now pay to start the work.'); JJ.go('/orders?focus=' + r.orderId); };
JJ.acts['prop-decline'] = async function (el) { await JJ.post('/api/proposals/' + el.dataset.id + '/decline'); JJ.toast('Declined'); JJ.nav(); };
JJ.forms.proposal = async function (f, d) {
  await JJ.post('/api/posts/' + f.dataset.id + '/proposals', { cover: d.cover, price: d.price, days: d.days });
  JJ.toast('Proposal sent'); JJ.nav(); JJ.refreshSummary();
};
JJ.forms.hire = async function (f, d) {
  var r = await JJ.post('/api/posts/' + f.dataset.id + '/hire', { hours: d.hours });
  JJ.go('/orders?focus=' + r.orderId);
};
JJ.forms.report = async function (f, d) {
  await JJ.post('/api/reports', { type: f.dataset.type, id: Number(f.dataset.id), reason: d.reason });
  f.reset(); JJ.toast('Thanks. Our team will review your report.');
};

/* ---------- profile ---------- */
JJ.route('/user/:id', async function (p) {
  var x = await JJ.get('/api/users/' + p.id), u = JJ.S.user, me = u && u.id === x.id;
  var body = x.headline === undefined
    ? '<div class="card"><p class="muted">This person keeps their profile private.</p></div>'
    : '<div class="card stack">' + (x.headline ? '<p><b>' + esc(x.headline) + '</b></p>' : '') + (x.country ? '<p class="muted">' + esc(x.country) + '</p>' : '') +
      (x.skills ? '<p><span class="lbl">Skills</span><br>' + esc(x.skills) + '</p>' : '') + (x.bio ? '<p class="pre">' + esc(x.bio) + '</p>' : '') +
      '<div class="row"><span class="pill good">' + x.completedAsFreelancer + ' jobs completed as freelancer</span><span class="pill info">' + x.completedAsClient + ' as client</span></div></div>' +
      (x.posts.length ? '<h2>Open posts</h2><div class="grid">' + x.posts.map(JJ.postCard).join('') + '</div>' : '');
  return '<div class="row between"><div class="who">' + JJ.avatar(x.name) + '<div><h1 style="font-size:1.6rem">' + esc(x.name) + '</h1><div class="small muted">Member since ' + JJ.date(x.memberSince) + '</div></div></div>' +
    (me ? '<a class="btn ghost" href="#/settings">Edit profile</a>' : '<a class="btn" href="#' + (u ? '/messages/' + x.id : '/login?next=' + encodeURIComponent('/user/' + x.id)) + '">Message</a>') + '</div>' + body +
    (u && !me ? '<details class="card"><summary class="small">Report this user</summary><form class="form" data-form="report" data-id="' + x.id + '" data-type="user" style="margin-top:12px">' + JJ.area('reason', 'What happened?', { max: 1000 }) + '<div class="formerr"></div><button class="btn ghost sm" type="submit">Send report</button></form></details>' : '');
});

/* ---------- accounts ---------- */
JJ.pending = null;
function afterLogin(user, next) {
  JJ.S.user = user; JJ.refreshSummary(); JJ.header();
  JJ.go(JJ.safeNext(next) === '/' && user.role !== 'user' ? '/' : JJ.safeNext(next));
}
function box(title, inner) { return '<div class="authbox"><div class="card stack"><h2>' + title + '</h2>' + inner + '</div></div>'; }

JJ.route('/login', function (_, q) {
  var needTotp = !!(JJ.pending && JJ.pending.totp);
  return box('Log in', '<form class="form" data-form="login" data-next="' + esc(q.next || '/') + '">' + JJ.field('email', 'Gmail or email', 'email', { auto: 'username', value: JJ.pending && JJ.pending.email || '', required: true }) + JJ.field('password', 'Password', 'password', { auto: 'current-password', required: true }) +
    (needTotp ? JJ.field('totp', 'Authenticator code', 'text', { auto: 'one-time-code', attrs: 'inputmode="numeric" maxlength="6"', hint: 'Open your authenticator app and enter the 6-digit code.' }) : '') +
    '<div class="formerr"></div><button class="btn" type="submit">Log in</button></form><p class="small"><a href="#/forgot">Forgot password?</a></p><p class="small muted">New to Jj Up? <a href="#/signup">Create an account</a></p>');
});
JJ.forms.login = async function (f, d) {
  try {
    var r = await JJ.post('/api/auth/login', { email: d.email, password: d.password, totp: d.totp });
    if (r.needTotp) { JJ.pending = { email: d.email, totp: true }; JJ.nav(); setTimeout(function () { var t = document.getElementById('f-totp'); if (t) { var pw = document.getElementById('f-password'); if (pw) pw.value = d.password; t.focus(); } }, 50); return; }
    JJ.pending = null; afterLogin(r.user, f.dataset.next);
  } catch (e) {
    if (e.data && e.data.needVerify) { JJ.pending = { email: d.email }; JJ.go('/verify'); return; }
    throw e;
  }
};

JJ.route('/signup', function () {
  var cfg = JJ.S.config;
  if (!cfg.signupsOpen) return box('Sign-ups are paused', '<p class="muted">New accounts are not being accepted right now. Please check back soon.</p>');
  return box('Create your account', '<form class="form" data-form="signup">' + JJ.field('name', 'Full name', 'text', { auto: 'name', required: true }) + JJ.field('email', 'Gmail', 'email', { auto: 'email', ph: 'you@gmail.com', required: true }) +
    JJ.field('phone', 'Phone number', 'tel', { auto: 'tel', ph: '+252 61 555 0123', hint: 'Include your country code.', required: true }) +
    JJ.field('password', 'Password', 'password', { auto: 'new-password', hint: 'At least 10 characters. A few random words works well.', required: true }) +
    '<div class="field"><span class="lbl">I mainly want to</span><div class="row"><label class="check"><input type="radio" name="mode" value="client" checked> Hire people</label><label class="check"><input type="radio" name="mode" value="freelancer"> Find work</label></div><span class="hint">You can do both later.</span></div>' +
    '<label class="check"><input type="checkbox" name="agree"><span class="small">I agree to the <a href="#/terms">Terms</a> and <a href="#/privacy">Privacy policy</a>.</span></label>' +
    '<div class="formerr"></div><button class="btn" type="submit">Continue</button></form><p class="small muted">Already have an account? <a href="#/login">Log in</a></p>');
});
JJ.forms.signup = async function (f, d) {
  if (!d.agree) throw new Error('Please agree to the Terms and Privacy policy to continue.');
  var r = await JJ.post('/api/auth/signup', { name: d.name, email: d.email, phone: d.phone, password: d.password, mode: d.mode });
  JJ.pending = { email: d.email.trim().toLowerCase(), devCodes: r.devCodes, needPhone: r.needPhone };
  JJ.go('/verify');
};

JJ.route('/verify', function () {
  var p = JJ.pending;
  return box('Check your email', '<p class="muted">We sent a 6-digit code to <b>' + esc(p && p.email || 'your email') + '</b>. It expires in 15 minutes.</p>' +
    (p && p.devCodes ? '<div class="alert info">Test mode: this server has no email set up, so your code is <b>' + esc(p.devCodes.email) + '</b>' + (p.devCodes.phone ? ' and phone code <b>' + esc(p.devCodes.phone) + '</b>' : '') + '.</div>' : '') +
    '<form class="form" data-form="verify">' + (p ? '' : JJ.field('email', 'Email', 'email', { required: true })) + JJ.field('code', 'Email code', 'text', { auto: 'one-time-code', attrs: 'inputmode="numeric" maxlength="6"', required: true }) +
    (JJ.S.config.requirePhone ? JJ.field('phoneCode', 'Phone code (sent by SMS)', 'text', { attrs: 'inputmode="numeric" maxlength="6"', required: true }) : '') +
    '<div class="formerr"></div><button class="btn" type="submit">Verify and continue</button></form><p class="small muted">No code? <button class="linkbtn" data-act="resend">Send a new one</button></p>');
});
JJ.forms.verify = async function (f, d) {
  var email = JJ.pending ? JJ.pending.email : d.email;
  var r = await JJ.post('/api/auth/verify', { email: email, code: d.code, phoneCode: d.phoneCode });
  JJ.pending = null; JJ.toast('Welcome to Jj Up!'); afterLogin(r.user, '/settings?tab=profile&welcome=1');
};
JJ.acts.resend = async function () {
  if (!JJ.pending) throw new Error('Sign up again to get a code.');
  var r = await JJ.post('/api/auth/resend', { email: JJ.pending.email });
  JJ.pending.devCodes = r.devCodes; JJ.toast('A new code is on its way.'); JJ.nav();
};

JJ.route('/forgot', function () {
  return box('Reset your password', '<form class="form" data-form="forgot">' + JJ.field('email', 'Email', 'email', { auto: 'email', required: true }) + '<div class="formerr"></div><button class="btn" type="submit">Send reset code</button></form><p class="small"><a href="#/login">Back to log in</a></p>');
});
JJ.forms.forgot = async function (f, d) {
  var r = await JJ.post('/api/auth/forgot', { email: d.email });
  JJ.pending = { email: d.email.trim().toLowerCase(), devCodes: r.devCodes }; JJ.go('/reset');
};
JJ.route('/reset', function () {
  var p = JJ.pending;
  return box('Choose a new password', '<p class="muted">If that email has an account, we sent a code to it.</p>' + (p && p.devCodes ? '<div class="alert info">Test mode: your code is <b>' + esc(p.devCodes.email) + '</b>.</div>' : '') +
    '<form class="form" data-form="reset">' + JJ.field('email', 'Email', 'email', { value: p && p.email || '', required: true }) + JJ.field('code', 'Code', 'text', { attrs: 'inputmode="numeric" maxlength="6"', required: true }) + JJ.field('password', 'New password', 'password', { auto: 'new-password', hint: 'At least 10 characters.', required: true }) + '<div class="formerr"></div><button class="btn" type="submit">Change password</button></form>');
});
JJ.forms.reset = async function (f, d) {
  await JJ.post('/api/auth/reset', { email: d.email, code: d.code, password: d.password });
  JJ.pending = { email: d.email }; JJ.toast('Password changed. Log in with your new password.'); JJ.go('/login');
};

/* ---------- legal (templates) ---------- */
JJ.route('/terms', function () {
  return '<article class="card stack"><h1 style="font-size:1.6rem">Terms of use</h1><div class="alert warn">Draft template. Have a lawyer review and complete these terms before you launch.</div>' +
    '<h3>Using Jj Up</h3><p>Jj Up connects clients and freelancers. We are a marketplace, not a party to the work agreement between them. You must be at least 18, give accurate information, and keep your password safe.</p>' +
    '<h3>Payments and escrow</h3><p>Clients pay through PayPal. Jj Up holds the payment until the client releases it, it is released automatically after the review period, or support resolves a dispute. A service fee is taken from the freelancer\'s earnings when payment is released.</p>' +
    '<h3>Withdrawals</h3><p>Freelancers can withdraw their available balance to their PayPal account. We may review withdrawals to prevent fraud.</p>' +
    '<h3>Rules</h3><p>No illegal work, scams, harassment, or taking payments outside Jj Up to avoid fees. We may remove posts and suspend accounts that break these rules.</p></article>';
});
JJ.route('/privacy', function () {
  return '<article class="card stack"><h1 style="font-size:1.6rem">Privacy policy</h1><div class="alert warn">Draft template. Have a lawyer review and complete this policy before you launch.</div>' +
    '<h3>What we collect</h3><p>Your name, email, phone number, profile details, posts, messages, and payment records. Card details are handled by PayPal and never reach our servers.</p>' +
    '<h3>Your choices</h3><p>In Settings you can make your profile private, limit who can message you, turn off notification emails, and delete your account.</p>' +
    '<h3>Who sees what</h3><p>Private profiles show only your first name and last initial. Support staff can see account and order details to help with problems and disputes.</p></article>';
});
})();
