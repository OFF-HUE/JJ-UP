(function () {
'use strict';
var JJ = window.JJ = { S: { config: null, user: null, summary: {} }, acts: {}, forms: {}, routes: [], timers: [], navTok: 0 };
var $ = function (s, r) { return (r || document).querySelector(s); };
JJ.$ = $;

var ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
JJ.esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return ESC[c]; }); };
var esc = JJ.esc;
JJ.money = function (c) { var n = (c || 0) / 100; return '$' + n.toLocaleString('en-US', { minimumFractionDigits: n % 1 ? 2 : 0, maximumFractionDigits: 2 }); };
JJ.ago = function (ts) {
  var m = Math.round((Date.now() - ts) / 60000);
  if (m < 1) return 'just now'; if (m < 60) return m + ' min ago';
  var h = Math.round(m / 60); if (h < 24) return h + ' h ago';
  var d = Math.round(h / 24); return d < 30 ? d + ' d ago' : JJ.date(ts);
};
JJ.date = function (ts) { return ts ? new Date(ts).toLocaleDateString(undefined, { year: 'numeric', month: 'short', day: 'numeric' }) : ''; };
JJ.dt = function (ts) { return ts ? new Date(ts).toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }) : ''; };
JJ.initials = function (n) { return String(n || '?').split(/\s+/).slice(0, 2).map(function (w) { return w[0] || ''; }).join('').toUpperCase(); };
JJ.avatar = function (n) { return '<span class="avatar" aria-hidden="true">' + esc(JJ.initials(n)) + '</span>'; };

var tt;
JJ.toast = function (m) {
  var t = $('#toast'); t.textContent = m; t.classList.add('show');
  clearTimeout(tt); tt = setTimeout(function () { t.classList.remove('show'); }, 3200);
};

/* ---------- API ---------- */
JJ.api = async function (method, url, body) {
  var h = { 'x-requested-with': 'jjup' };
  if (body !== undefined) h['content-type'] = 'application/json';
  var r;
  try { r = await fetch(url, { method: method, headers: h, body: body !== undefined ? JSON.stringify(body) : undefined, credentials: 'same-origin' }); }
  catch (e) { throw new Error('You appear to be offline. Check your connection and try again.'); }
  var data = await r.json().catch(function () { return {}; });
  if (!r.ok) {
    var err = new Error(data.error || 'Something went wrong. Please try again.');
    err.status = r.status; err.data = data;
    if (r.status === 401 && JJ.S.user) { JJ.S.user = null; JJ.header(); JJ.go('/login'); }
    throw err;
  }
  return data;
};
JJ.get = function (u) { return JJ.api('GET', u); };
JJ.post = function (u, b) { return JJ.api('POST', u, b || {}); };

/* ---------- router ---------- */
JJ.route = function (pattern, fn, opts) {
  var keys = [];
  var rx = new RegExp('^' + pattern.replace(/:([a-z]+)/g, function (_, k) { keys.push(k); return '([^/]+)'; }) + '/?$');
  JJ.routes.push({ rx: rx, keys: keys, fn: fn, opts: opts || {} });
};
JJ.go = function (path) { if (location.hash === '#' + path) JJ.nav(); else location.hash = '#' + path; };
JJ.view = function (html, mount) { $('#view').innerHTML = html; if (mount) mount(); };
JJ.every = function (ms, fn) { JJ.timers.push(setInterval(fn, ms)); };
JJ.clearTimers = function () { JJ.timers.forEach(clearInterval); JJ.timers = []; };
JJ.safeNext = function (n) { return n && n[0] === '/' && n[1] !== '/' ? n : '/'; };
JJ.here = function () { var h = location.hash.slice(1) || '/'; var i = h.indexOf('?'); return i > -1 ? h.slice(0, i) : h; };
JJ.query = function () { var h = location.hash.slice(1); var i = h.indexOf('?'); return Object.fromEntries(new URLSearchParams(i > -1 ? h.slice(i + 1) : '')); };

JJ.nav = async function () {
  JJ.clearTimers();
  var tok = ++JJ.navTok, path = JJ.here(), q = JJ.query(), u = JJ.S.user;
  var hit = null, params = {};
  for (var i = 0; i < JJ.routes.length; i++) {
    var m = JJ.routes[i].rx.exec(path);
    if (m) { hit = JJ.routes[i]; hit.keys.forEach(function (k, j) { params[k] = decodeURIComponent(m[j + 1]); }); break; }
  }
  if (!hit) { JJ.header(); JJ.view('<div class="empty"><h2>Page not found</h2><p><a href="#/">Go to the home page</a></p></div>'); return; }
  if (hit.opts.auth && !u) { JJ.go('/login?next=' + encodeURIComponent(path)); return; }
  if (hit.opts.staff && (!u || u.role === 'user')) { JJ.go('/'); return; }
  JJ.header();
  try {
    var out = await hit.fn(params, q);
    if (tok !== JJ.navTok) return;
    if (Array.isArray(out)) JJ.view(out[0], out[1]); else if (typeof out === 'string') JJ.view(out);
  } catch (e) {
    if (tok !== JJ.navTok) return;
    JJ.view('<div class="card stack"><h2>We could not load this page</h2><p class="muted">' + esc(e.message) + '</p><div><button class="btn" data-act="reload">Try again</button></div></div>');
  }
  if (tok === JJ.navTok) { window.scrollTo(0, 0); }
};
// Two-step confirm for risky buttons: first click arms it, second click within 4s runs it.
JJ.sure = function (el, label) {
  if (el.dataset.armed === '1') { clearTimeout(Number(el.dataset.tm)); el.dataset.armed = ''; el.innerHTML = el.dataset.orig; return true; }
  el.dataset.armed = '1'; el.innerHTML = JJ.esc(label || 'Click again to confirm');
  el.dataset.tm = String(setTimeout(function () { el.dataset.armed = ''; if (el.isConnected) el.innerHTML = el.dataset.orig; }, 4000));
  return false;
};
JJ.acts.reload = function () { return JJ.nav(); };

/* ---------- header ---------- */
JJ.refreshSummary = async function () {
  if (!JJ.S.user) return;
  try { JJ.S.summary = await JJ.get('/api/summary'); JJ.header(); } catch (_) {}
};
JJ.header = function () {
  var u = JJ.S.user, s = JJ.S.summary || {}, p = JJ.here();
  function link(href, label, badge) {
    var on = href === '/' ? p === '/' : p === href || p.indexOf(href + '/') === 0;
    return '<a href="#' + href + '"' + (on ? ' aria-current="page"' : '') + '>' + label + (badge ? '<span class="badge">' + badge + '</span>' : '') + '</a>';
  }
  var nav = link('/', 'Browse');
  if (u) {
    nav += link('/my', 'My posts') + link('/proposals', 'Proposals', s.proposals) + link('/orders', 'Orders', s.orders) + link('/messages', 'Messages', s.unread) + link('/wallet', 'Wallet') + link('/support', 'Support', s.tickets) + link('/settings', 'Settings');
    if (u.role !== 'user') nav += link('/admin', 'Admin');
  } else nav += link('/support/new', 'Help');
  var right = u
    ? '<span class="small muted">' + esc(u.name.split(' ')[0]) + '</span><button class="btn ghost sm" data-act="logout">Log out</button>'
    : '<a class="btn ghost sm" href="#/login">Log in</a><a class="btn sm" href="#/signup">Sign up</a>';
  $('#header').innerHTML = '<div class="bar"><a class="brand" href="#/"><span class="mark"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M12 20V5"/><path d="M5 11l7-7 7 7"/></svg></span>Jj up</a><nav class="nav" aria-label="Main">' + nav + '</nav><div class="row right">' + right + '</div></div>';
};

/* ---------- events ---------- */
JJ.showErr = function (scope, msg) {
  var box = scope && scope.querySelector && scope.querySelector('.formerr');
  if (box) { box.innerHTML = msg ? '<div class="alert bad" role="alert">' + esc(msg) + '</div>' : ''; if (msg) box.scrollIntoView({ block: 'nearest' }); }
  else if (msg) JJ.toast(msg);
};
JJ.run = async function (btn, fn, scope) {
  if (btn && btn.disabled) return;
  var old = btn && btn.innerHTML;
  if (btn && btn.dataset.armed !== '1') btn.dataset.orig = old;
  if (btn) { btn.disabled = true; if (btn.classList.contains('btn')) btn.innerHTML = '<span class="spin"></span> ' + old; }
  JJ.showErr(scope, '');
  try { await fn(); }
  catch (e) { JJ.showErr(scope, e.message); if (!scope) JJ.toast(e.message); else if (!scope.querySelector('.formerr')) JJ.toast(e.message); }
  finally { if (btn && btn.isConnected) { btn.disabled = false; if (btn.dataset.armed !== '1') btn.innerHTML = btn.dataset.orig || old; } }
};
JJ.fd = function (form) {
  var o = Object.fromEntries(new FormData(form));
  form.querySelectorAll('input[type=checkbox]').forEach(function (c) { o[c.name] = c.checked; });
  return o;
};
document.addEventListener('click', function (e) {
  var el = e.target.closest('[data-act]');
  if (!el) return;
  var f = JJ.acts[el.dataset.act];
  if (!f) return;
  e.preventDefault();
  JJ.run(el, function () { return f(el, e); }, el.closest('form') || null);
});
document.addEventListener('submit', function (e) {
  var form = e.target.closest('form[data-form]');
  if (!form) return;
  e.preventDefault();
  var f = JJ.forms[form.dataset.form];
  if (!f) return;
  JJ.run(form.querySelector('[type=submit]'), function () { return f(form, JJ.fd(form)); }, form);
});

/* ---------- shared view helpers ---------- */
var PILL = {
  awaiting_payment: ['Awaiting payment', 'warn'], in_escrow: ['In escrow', 'good'], delivered: ['Delivered', 'info'], released: ['Paid', 'good'], refunded: ['Refunded', 'muted'], disputed: ['Disputed', 'bad'], cancelled: ['Cancelled', 'muted'],
  pending: ['Pending', 'warn'], accepted: ['Accepted', 'good'], declined: ['Declined', 'bad'], withdrawn: ['Withdrawn', 'muted'], closed: ['Closed', 'muted'],
  open: ['Open', 'warn'], resolved: ['Resolved', 'good'], processing: ['Sending', 'info'], paid: ['Sent', 'good'], rejected: ['Rejected', 'bad'], failed: ['Failed', 'bad'],
  active: ['Active', 'good'], suspended: ['Suspended', 'bad'], removed: ['Removed', 'bad'], captured: ['Captured', 'good'], created: ['Created', 'muted'], queued: ['Queued', 'warn'], sent: ['Sent', 'good'], logged: ['Logged only', 'muted'], actioned: ['Actioned', 'good'], dismissed: ['Dismissed', 'muted']
};
JJ.pill = function (s) { var p = PILL[s] || [s, 'muted']; return '<span class="pill ' + p[1] + '">' + esc(p[0]) + '</span>'; };
JJ.field = function (name, label, type, o) {
  o = o || {};
  return '<div class="field"><label for="f-' + name + '">' + esc(label) + '</label><input id="f-' + name + '" name="' + name + '" type="' + (type || 'text') + '"' + (o.ph ? ' placeholder="' + esc(o.ph) + '"' : '') + (o.value != null ? ' value="' + esc(o.value) + '"' : '') + (o.auto ? ' autocomplete="' + o.auto + '"' : '') + (o.attrs ? ' ' + o.attrs : '') + (o.required ? ' required' : '') + '>' + (o.hint ? '<span class="hint">' + esc(o.hint) + '</span>' : '') + '</div>';
};
JJ.area = function (name, label, o) {
  o = o || {};
  return '<div class="field"><label for="f-' + name + '">' + esc(label) + '</label><textarea id="f-' + name + '" name="' + name + '"' + (o.ph ? ' placeholder="' + esc(o.ph) + '"' : '') + (o.max ? ' maxlength="' + o.max + '"' : '') + '>' + esc(o.value || '') + '</textarea>' + (o.hint ? '<span class="hint">' + esc(o.hint) + '</span>' : '') + '</div>';
};
JJ.select = function (name, label, opts, cur) {
  return '<div class="field"><label for="f-' + name + '">' + esc(label) + '</label><select id="f-' + name + '" name="' + name + '">' + opts.map(function (o) { var v = Array.isArray(o) ? o[0] : o, l = Array.isArray(o) ? o[1] : o; return '<option value="' + esc(v) + '"' + (String(v) === String(cur) ? ' selected' : '') + '>' + esc(l) + '</option>'; }).join('') + '</select></div>';
};
JJ.pager = function (page, pages, act) {
  if (pages <= 1) return '';
  return '<div class="pager"><button class="btn ghost sm" data-act="' + act + '" data-page="' + (page - 1) + '"' + (page <= 1 ? ' disabled' : '') + '>Previous</button><span class="small muted">Page ' + page + ' of ' + pages + '</span><button class="btn ghost sm" data-act="' + act + '" data-page="' + (page + 1) + '"' + (page >= pages ? ' disabled' : '') + '>Next</button></div>';
};
JJ.empty = function (t) { return '<div class="empty">' + t + '</div>'; };

JJ.acts.logout = async function () {
  await JJ.post('/api/auth/logout');
  JJ.S.user = null; JJ.S.summary = {};
  JJ.go('/');
  JJ.toast('You are logged out.');
};
})();
