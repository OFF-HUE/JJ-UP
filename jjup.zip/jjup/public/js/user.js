(function () {
'use strict';
var JJ = window.JJ, esc = JJ.esc, money = JJ.money, A = { auth: true };
var STEP = { awaiting_payment: 0, in_escrow: 1, delivered: 2, released: 3 };

/* ---------- my posts ---------- */
JJ.route('/my', async function (_, q) {
  var r = await JJ.get('/api/my/posts'), cfg = JJ.S.config, isNew = q.new === 'job' || q.new === 'service';
  var form = '<details class="card"' + (isNew ? ' open' : '') + '><summary><b>New post</b></summary><form class="form" data-form="newpost" style="margin-top:14px">' +
    '<div class="two">' + JJ.select('kind', 'Type', [['job', 'Job: I need someone'], ['service', 'Service: I offer my skills']], q.new === 'service' ? 'service' : 'job') + JJ.select('category', 'Category', cfg.categories) + '</div>' +
    JJ.field('title', 'Title', 'text', { ph: 'Landing page for my coffee shop', attrs: 'maxlength="120"' }) +
    '<div class="two">' + JJ.select('priceType', 'Pricing', [['fixed', 'Fixed price'], ['hourly', 'Per hour']], 'fixed') + JJ.field('amount', 'Amount (USD)', 'text', { attrs: 'inputmode="decimal"', ph: '200' }) + '</div>' +
    JJ.area('description', 'Description', { ph: 'What the work involves, what you will deliver, timing.', max: 3000 }) +
    JJ.select('visibility', 'Who can find it', [['public', 'Public: shown in search'], ['unlisted', 'Private: only people with the link']], 'public') +
    '<div class="formerr"></div><button class="btn" type="submit">Publish</button></form></details>';
  var list = r.posts.length ? '<div class="stack">' + r.posts.map(function (p) {
    return '<article class="card row between"><div style="min-width:0;flex:1"><div class="row"><span class="chip">' + (p.kind === 'job' ? 'Job' : 'Service') + '</span>' + JJ.pill(p.status) + (p.visibility === 'unlisted' ? '<span class="pill muted">Private</span>' : '') + '</div><h3><a href="#/post/' + p.id + '">' + esc(p.title) + '</a></h3><div class="small muted">' + money(p.amountCents) + (p.priceType === 'hourly' ? '/hr' : '') + ' · ' + JJ.ago(p.createdAt) + (p.kind === 'job' ? ' · ' + p.proposalCount + ' proposal' + (p.proposalCount === 1 ? '' : 's') : '') + '</div></div><a class="btn ghost sm" href="#/post/' + p.id + '">Manage</a></article>';
  }).join('') + '</div>' : JJ.empty('You have not posted anything yet. Use New post above.');
  return '<div class="row between"><h1 style="font-size:1.8rem">My posts</h1></div>' + form + list;
}, A);
JJ.forms.newpost = async function (f, d) {
  var r = await JJ.post('/api/posts', { kind: d.kind, title: d.title, category: d.category, priceType: d.priceType, amount: d.amount, description: d.description, visibility: d.visibility });
  JJ.toast('Published'); JJ.go('/post/' + r.id);
};

/* ---------- proposals ---------- */
JJ.route('/proposals', async function (_, q) {
  var box = q.box === 'received' ? 'received' : 'sent';
  var r = await JJ.get('/api/proposals?box=' + box);
  return '<h1 style="font-size:1.8rem">Proposals</h1><div class="tabs"><a href="#/proposals?box=sent"' + (box === 'sent' ? ' aria-current="page"' : '') + '>Sent by me</a><a href="#/proposals?box=received"' + (box === 'received' ? ' aria-current="page"' : '') + '>Received on my jobs</a></div>' +
    (r.proposals.length ? '<div class="stack">' + r.proposals.map(function (p) {
      return '<article class="card stack"><div class="row between"><div><a href="#/post/' + p.postId + '"><b>' + esc(p.title) + '</b></a><div class="small muted">' + (box === 'sent' ? 'to ' : 'from ') + '<a href="#/user/' + p.other.id + '">' + esc(p.other.name) + '</a> · ' + JJ.ago(p.createdAt) + '</div></div>' + JJ.pill(p.status) + '</div><p class="pre">' + esc(p.cover) + '</p><div class="row between"><span class="price num">' + money(p.priceCents) + ' <span class="small muted" style="font-weight:400">in ' + p.days + ' days</span></span><div class="row">' +
        (box === 'received' && p.status === 'pending' ? '<button class="btn sm" data-act="prop-accept" data-id="' + p.id + '">Accept</button><button class="btn ghost sm" data-act="prop-decline" data-id="' + p.id + '">Decline</button>' : '') +
        (box === 'sent' && p.status === 'pending' ? '<button class="btn ghost sm" data-act="prop-withdraw" data-id="' + p.id + '">Withdraw</button>' : '') +
        '<a class="btn ghost sm" href="#/messages/' + p.other.id + '">Message</a></div></div></article>';
    }).join('') + '</div>' : JJ.empty(box === 'sent' ? '<p>You have not sent any proposals.</p><p><a href="#/">Browse jobs</a></p>' : '<p>No proposals on your jobs yet.</p>'));
}, A);
JJ.acts['prop-withdraw'] = async function (el) { await JJ.post('/api/proposals/' + el.dataset.id + '/withdraw'); JJ.toast('Proposal withdrawn'); JJ.nav(); };

/* ---------- orders and payment ---------- */
function loadPayPal() {
  return new Promise(function (res, rej) {
    if (window.paypal) return res();
    var s = document.createElement('script');
    s.src = 'https://www.paypal.com/sdk/js?client-id=' + encodeURIComponent(JJ.S.config.paypal.clientId) + '&currency=USD&intent=capture&components=buttons';
    s.onload = res; s.onerror = function () { rej(new Error('Could not load PayPal. Check your connection and try again.')); };
    document.head.appendChild(s);
  });
}
JJ.acts['pay-open'] = async function (el) {
  var id = el.dataset.id, box = document.getElementById('pay-' + id);
  box.hidden = !box.hidden;
  if (box.hidden) return;
  if (JJ.S.config.paypal.mode === 'mock') {
    box.innerHTML = '<div class="alert info">Test mode: no real money moves. Live PayPal turns on when you add your PayPal keys.</div><button class="btn sun" data-act="pay-mock" data-id="' + id + '">Pay with PayPal (test)</button>';
    return;
  }
  box.innerHTML = '<p class="small muted">Pay with PayPal or a debit or credit card (including Mastercard). Your card details go to PayPal, never to Jj Up.</p><div id="pp-' + id + '" class="pp"></div>';
  await loadPayPal();
  window.paypal.Buttons({
    createOrder: async function () { return (await JJ.post('/api/orders/' + id + '/pay/create')).paypalOrderId; },
    onApprove: async function (data) {
      try { await JJ.post('/api/orders/' + id + '/pay/capture', { paypalOrderId: data.orderID }); JJ.toast('Payment received. Your money is held safely.'); JJ.nav(); JJ.refreshSummary(); }
      catch (e) { JJ.toast(e.message); }
    },
    onError: function () { JJ.toast('PayPal had a problem. Nothing was charged unless PayPal confirmed it.'); },
  }).render('#pp-' + id);
};
JJ.acts['pay-mock'] = async function (el) {
  var id = el.dataset.id, c = await JJ.post('/api/orders/' + id + '/pay/create');
  await JJ.post('/api/orders/' + id + '/pay/capture', { paypalOrderId: c.paypalOrderId });
  JJ.toast('Payment received (test). Money is held in escrow.'); JJ.nav(); JJ.refreshSummary();
};
JJ.acts['order-release'] = async function (el) { await JJ.post('/api/orders/' + el.dataset.id + '/release'); JJ.toast('Payment released to the freelancer.'); JJ.nav(); JJ.refreshSummary(); };
JJ.acts['order-cancel'] = async function (el) { await JJ.post('/api/orders/' + el.dataset.id + '/cancel'); JJ.toast('Order cancelled'); JJ.nav(); };
JJ.forms.deliver = async function (f, d) { await JJ.post('/api/orders/' + f.dataset.id + '/deliver', { note: d.note }); JJ.toast('Marked as delivered. The client was emailed.'); JJ.nav(); JJ.refreshSummary(); };
JJ.forms.dispute = async function (f, d) { var r = await JJ.post('/api/orders/' + f.dataset.id + '/dispute', { reason: d.reason }); JJ.toast('Dispute opened. Support will help.'); JJ.go('/support/' + r.ticketId); };

function orderCard(o, focus) {
  var client = o.role === 'client', st = STEP[o.status];
  var info = {
    awaiting_payment: client ? 'Pay to start the work. Your money is held by Jj Up until you release it.' : 'Waiting for the client to pay. Start work once the money is held in escrow.',
    in_escrow: client ? 'Money is held in escrow. The freelancer is working.' : 'The money is held in escrow. You can start work. Mark it delivered when done.',
    delivered: client ? 'Work was delivered. Check it, then release the payment. If you do nothing, it is released automatically after a few days.' : 'Delivered. Waiting for the client to release payment.',
    released: client ? 'Completed. Payment was released.' : 'Completed. ' + money(o.youGetCents) + ' was added to your wallet.',
    refunded: 'This order was refunded to the client.', disputed: 'In dispute. Support is reviewing. The money stays in escrow.', cancelled: 'This order was cancelled.',
  }[o.status];
  var actions = '';
  if (client && o.status === 'awaiting_payment') actions += '<button class="btn sun" data-act="pay-open" data-id="' + o.id + '">Pay ' + money(o.amountCents) + '</button><button class="btn ghost" data-act="order-cancel" data-id="' + o.id + '">Cancel</button>';
  if (client && ['in_escrow', 'delivered'].indexOf(o.status) > -1) actions += '<button class="btn sun" data-act="order-release" data-id="' + o.id + '">Release payment</button>';
  var extra = '';
  if (!client && o.status === 'in_escrow') extra += '<details><summary class="btn sm" style="display:inline-flex">Mark as delivered</summary><form class="form" data-form="deliver" data-id="' + o.id + '" style="margin-top:12px">' + JJ.area('note', 'Delivery note', { ph: 'Link to the files or a short summary of what you delivered', max: 2000 }) + '<div class="formerr"></div><button class="btn" type="submit">Deliver</button></form></details>';
  if (['in_escrow', 'delivered'].indexOf(o.status) > -1) extra += '<details><summary class="small muted">Something wrong? Open a dispute</summary><form class="form" data-form="dispute" data-id="' + o.id + '" style="margin-top:12px">' + JJ.area('reason', 'What went wrong?', { max: 2000, hint: 'The money stays in escrow while support reviews.' }) + '<div class="formerr"></div><button class="btn danger" type="submit">Open dispute</button></form></details>';
  return '<article class="card stack" id="order-' + o.id + '"><div class="row between"><div><h3>' + esc(o.title) + '</h3><div class="small muted">Order #' + o.id + ' · ' + (client ? 'freelancer ' : 'client ') + '<a href="#/user/' + o.other.id + '">' + esc(o.other.name) + '</a> · ' + o.days + ' days</div></div><div style="text-align:right"><div class="price num">' + money(o.amountCents) + '</div>' + JJ.pill(o.status) + '</div></div>' +
    (st !== undefined ? '<div><div class="prog" aria-hidden="true"><i class="' + (st >= 1 ? 'on' : '') + '"></i><i class="' + (st >= 2 ? 'on' : '') + '"></i><i class="' + (st >= 3 ? 'on' : '') + '"></i></div><div class="proglabels"><span>Paid into escrow</span><span>Delivered</span><span>Released</span></div></div>' : '') +
    '<p class="small muted">' + info + '</p>' + (o.deliveryNote ? '<div class="alert info pre"><b>Delivery note:</b> ' + esc(o.deliveryNote) + '</div>' : '') +
    (!client && o.status !== 'cancelled' && o.status !== 'refunded' ? '<p class="small">You get <b>' + money(o.youGetCents) + '</b> after the Jj Up fee.</p>' : '') +
    '<div class="row">' + actions + '<a class="btn ghost" href="#/messages/' + o.other.id + '">Message</a></div><div class="paybox" id="pay-' + o.id + '" hidden></div>' + extra + '</article>';
}
JJ.route('/orders', async function (_, q) {
  var r = await JJ.get('/api/orders');
  var html = '<h1 style="font-size:1.8rem">Orders</h1>' + (r.orders.length ? '<div class="stack">' + r.orders.map(orderCard).join('') + '</div>' : JJ.empty('<p>No orders yet.</p><p>Accept a proposal on your job, or hire someone from a service.</p>'));
  return [html, function () {
    if (q.focus) { var b = document.querySelector('#order-' + q.focus + ' [data-act="pay-open"]'); if (b) { b.scrollIntoView({ block: 'center' }); b.click(); } }
  }];
}, A);

/* ---------- messages ---------- */
var MS = { id: null, last: 0 };
async function messagesPage(id) {
  var th = (await JJ.get('/api/messages/threads')).threads, cur = id ? String(id) : '';
  var c = null;
  if (id) c = await JJ.get('/api/messages/with/' + id);
  if (c && !th.some(function (t) { return String(t.userId) === cur; })) th.unshift({ userId: Number(id), name: c.other.name, last: '', unread: 0 });
  var convs = th.length ? th.map(function (t) {
    return '<a class="conv" href="#/messages/' + t.userId + '"' + (String(t.userId) === cur ? ' aria-current="true"' : '') + '>' + JJ.avatar(t.name) + '<span class="txt"><b>' + esc(t.name) + '</b><div class="last">' + (t.mine ? 'You: ' : '') + esc(t.last) + '</div></span>' + (t.unread ? '<span class="badge">' + t.unread + '</span>' : '') + '</a>';
  }).join('') : '<div style="padding:16px" class="muted small">No conversations yet. Use Message on a post or profile to start one.</div>';
  var pane;
  if (!c) pane = '<div class="thread"><div class="empty" style="margin:14px">Select a conversation.</div></div>';
  else pane = '<div class="thread"><div class="thead"><a class="btn ghost sm back" href="#/messages">Back</a>' + JJ.avatar(c.other.name) + '<div style="flex:1;min-width:0"><a href="#/user/' + c.other.id + '"><b>' + esc(c.other.name) + '</b></a><div class="small muted">' + esc(c.other.headline) + '</div></div><button class="btn ghost sm" data-act="block-user" data-id="' + c.other.id + '" data-block="' + (c.blocked ? '0' : '1') + '">' + (c.blocked ? 'Unblock' : 'Block') + '</button></div>' +
    '<div class="log" id="log" aria-live="polite">' + (c.messages.length ? '' : '<div class="muted small" id="nomsg">Say hello to ' + esc(c.other.name.split(' ')[0]) + '.</div>') + '</div>' +
    (c.canSend ? '<form class="composer" data-form="message" data-id="' + c.other.id + '"><input name="body" placeholder="Write a message" autocomplete="off" maxlength="2000" aria-label="Message" required><button class="btn" type="submit">Send</button></form>' : '<div style="padding:12px"><div class="alert warn">' + esc(c.reason) + '</div></div>') + '</div>';
  var html = '<h1 style="font-size:1.8rem">Messages</h1><div class="msgs' + (id ? ' has' : '') + '"><div class="convs">' + convs + '</div>' + pane + '</div>';
  return [html, function () {
    if (!c) return;
    MS = { id: c.other.id, last: 0 };
    var log = document.getElementById('log');
    c.messages.forEach(function (m) { addBubble(log, m); });
    log.scrollTop = log.scrollHeight;
    JJ.every(4000, pull); JJ.refreshSummary();
  }];
}
function addBubble(log, m) {
  var d = document.createElement('div'); d.className = 'bubble' + (m.mine ? ' me' : ''); d.textContent = m.body; d.title = JJ.dt(m.at);
  log.appendChild(d); MS.last = Math.max(MS.last, m.id);
  var n = document.getElementById('nomsg'); if (n) n.remove();
}
async function pull() {
  if (!MS.id) return;
  var id = MS.id, c = await JJ.get('/api/messages/with/' + id + '?after=' + MS.last);
  if (id !== MS.id) return;
  var log = document.getElementById('log');
  if (!log || !c.messages.length) return;
  var atEnd = log.scrollHeight - log.scrollTop - log.clientHeight < 60;
  c.messages.forEach(function (m) { addBubble(log, m); });
  if (atEnd) log.scrollTop = log.scrollHeight;
  JJ.refreshSummary();
}
JJ.route('/messages', function () { return messagesPage(null); }, A);
JJ.route('/messages/:id', function (p) { return messagesPage(p.id); }, A);
JJ.forms.message = async function (f, d) {
  var body = (d.body || '').trim(); if (!body) return;
  await JJ.post('/api/messages', { to: Number(f.dataset.id), body: body });
  f.reset(); await pull();
};
JJ.acts['block-user'] = async function (el) { await JJ.post('/api/blocks', { userId: Number(el.dataset.id), block: el.dataset.block === '1' }); JJ.toast(el.dataset.block === '1' ? 'Blocked' : 'Unblocked'); JJ.nav(); };

/* ---------- wallet ---------- */
JJ.route('/wallet', async function () {
  var w = await JJ.get('/api/wallet'), cfg = JJ.S.config;
  var wd = '<form class="card form" data-form="withdraw"><h3>Withdraw to PayPal</h3>' +
    (w.paypalEmail ? '<p class="small muted">Sent to <b>' + esc(w.paypalEmail) + '</b>. <a href="#/settings?tab=payout">Change</a></p>' : '<div class="alert warn">Add your PayPal email first. <a href="#/settings?tab=payout">Go to payout settings</a></div>') +
    '<div class="row" style="align-items:end"><div class="field" style="flex:1;min-width:140px"><label for="f-amount">Amount (USD)</label><input id="f-amount" name="amount" inputmode="decimal" placeholder="' + w.minWithdraw + '"></div><button class="btn sun" type="submit"' + (w.paypalEmail && w.balanceCents > 0 ? '' : ' disabled') + '>Withdraw</button><button class="btn ghost" type="button" data-act="withdraw-all"' + (w.balanceCents > 0 ? '' : ' disabled') + '>Withdraw all</button></div><span class="hint">Minimum ' + money(w.minWithdraw * 100) + '. Withdrawals may be reviewed before they are sent.</span><div class="formerr"></div></form>';
  var wdt = w.withdrawals.length ? '<div class="card tw"><table><thead><tr><th>Date</th><th>To</th><th>Status</th><th style="text-align:right">Amount</th></tr></thead><tbody>' + w.withdrawals.map(function (x) { return '<tr><td>' + JJ.date(x.created_at) + '</td><td>' + esc(x.paypal_email) + '</td><td>' + JJ.pill(x.status) + (x.note ? ' <span class="small muted">' + esc(x.note) + '</span>' : '') + '</td><td class="num" style="text-align:right">' + money(x.amount_cents) + '</td></tr>'; }).join('') + '</tbody></table></div>' : '';
  var led = w.ledger.length ? '<div class="card tw"><table><thead><tr><th>Date</th><th>What</th><th style="text-align:right">Amount</th></tr></thead><tbody>' + w.ledger.map(function (x) {
    var lab = { order_release: 'Earned: ' + (x.title || 'order #' + x.order_id), withdrawal: 'Withdrawal', withdrawal_reversal: 'Withdrawal returned' }[x.kind] || x.kind;
    return '<tr><td>' + JJ.date(x.created_at) + '</td><td class="wrapcell">' + esc(lab) + '</td><td class="num" style="text-align:right;color:var(--' + (x.amount_cents < 0 ? 'bad' : 'good') + ')">' + (x.amount_cents < 0 ? '−' : '+') + money(Math.abs(x.amount_cents)) + '</td></tr>';
  }).join('') + '</tbody></table></div>' : '';
  var pays = w.payments.length ? '<div class="card tw"><table><thead><tr><th>Date</th><th>Order</th><th>Status</th><th style="text-align:right">Amount</th></tr></thead><tbody>' + w.payments.map(function (x) { return '<tr><td>' + JJ.date(x.created_at) + '</td><td class="wrapcell">#' + x.order_id + ' ' + esc(x.title) + '</td><td>' + JJ.pill(x.status) + '</td><td class="num" style="text-align:right">' + money(x.amount_cents) + '</td></tr>'; }).join('') + '</tbody></table></div>' : '';
  JJ.walletBalance = w.balanceCents;
  return '<h1 style="font-size:1.8rem">Wallet</h1><div class="stats"><div class="stat hl"><span class="muted small">Available to withdraw</span><span class="v">' + money(w.balanceCents) + '</span></div><div class="stat"><span class="muted small">Coming (held in escrow)</span><span class="v">' + money(w.pendingCents) + '</span></div></div>' + wd +
    (wdt ? '<h2>Withdrawals</h2>' + wdt : '') + (led ? '<h2>Earnings</h2>' + led : '') + (pays ? '<h2>Payments you made</h2>' + pays : '') +
    (!wdt && !led && !pays ? JJ.empty('Nothing here yet. Earnings and payments appear as you work on Jj Up.') : '');
}, A);
JJ.forms.withdraw = async function (f, d) {
  var r = await JJ.post('/api/wallet/withdraw', { amount: d.amount });
  JJ.toast(r.status === 'paid' ? 'Sent to your PayPal.' : 'Withdrawal requested. We will email you when it is sent.'); JJ.nav();
};
JJ.acts['withdraw-all'] = async function () {
  var r = await JJ.post('/api/wallet/withdraw', { amount: (JJ.walletBalance / 100).toFixed(2) });
  JJ.toast(r.status === 'paid' ? 'Sent to your PayPal.' : 'Withdrawal requested. We will email you when it is sent.'); JJ.nav();
};

/* ---------- support ---------- */
var FAQ = [
  ['How does escrow work?', 'When a client pays, Jj Up holds the money. The freelancer works, delivers, and the client releases the payment. If the client does nothing after delivery, it is released automatically after a few days.'],
  ['When can I withdraw?', 'As soon as a client releases payment it appears in your Wallet. Add your PayPal email in Settings and request a withdrawal. Some withdrawals are reviewed first.'],
  ['What if the work is not delivered?', 'Open a dispute on the order. The money stays in escrow while our team reviews and either refunds the client or pays the freelancer.'],
  ['Is my card safe?', 'Card and PayPal details are handled by PayPal. Jj Up never sees or stores them.'],
];
JJ.route('/support', async function () {
  var r = await JJ.get('/api/tickets');
  return '<div class="row between"><h1 style="font-size:1.8rem">Support</h1><a class="btn" href="#/support/new">Report a problem</a></div>' +
    (r.tickets.length ? '<div class="stack">' + r.tickets.map(function (t) { return '<a class="card row between" href="#/support/' + t.id + '" style="text-decoration:none;color:inherit"><div><b>' + esc(t.subject) + '</b><div class="small muted">#' + t.id + ' · ' + esc(t.category) + ' · updated ' + JJ.ago(t.updated_at) + '</div></div>' + (t.status === 'pending' ? '<span class="pill info">Reply from support</span>' : JJ.pill(t.status)) + '</a>'; }).join('') + '</div>' : JJ.empty('You have no support tickets.')) +
    '<h2>Common questions</h2><div class="stack">' + FAQ.map(function (f) { return '<details class="card"><summary><b>' + esc(f[0]) + '</b></summary><p class="muted" style="margin-top:8px">' + esc(f[1]) + '</p></details>'; }).join('') + '</div>';
}, A);
JJ.route('/support/new', async function (_, q) {
  if (!JJ.S.user) return '<div class="authbox"><div class="card stack"><h2>Help and support</h2><p class="muted">Log in to contact our support team. Your account details help us fix problems faster.</p><a class="btn" href="#/login?next=%2Fsupport%2Fnew">Log in</a></div></div>';
  var cats = (await JJ.get('/api/tickets/categories')).categories, orders = (await JJ.get('/api/orders')).orders;
  return '<div class="authbox" style="max-width:620px"><form class="card form" data-form="ticket"><h2>Report a problem</h2><p class="muted small">Tell us what went wrong. We reply here and by email.</p>' +
    JJ.select('category', 'What is it about?', cats, q.cat || 'Other') + JJ.select('orderId', 'Related order (optional)', [['', 'None']].concat(orders.map(function (o) { return [o.id, '#' + o.id + ' ' + o.title]; })), q.order || '') +
    JJ.field('subject', 'Subject', 'text', { attrs: 'maxlength="150"' }) + JJ.area('body', 'Details', { max: 4000, hint: 'Include dates, amounts, and what you expected to happen.' }) + '<div class="formerr"></div><button class="btn" type="submit">Send to support</button></form></div>';
});
JJ.forms.ticket = async function (f, d) {
  var r = await JJ.post('/api/tickets', { category: d.category, orderId: d.orderId || undefined, subject: d.subject, body: d.body });
  JJ.toast('Sent. We will reply soon.'); JJ.go('/support/' + r.id);
};
JJ.route('/support/:id', async function (p) {
  var r = await JJ.get('/api/tickets/' + p.id), t = r.ticket, staff = JJ.S.user.role !== 'user' && t.userId !== JJ.S.user.id;
  return '<div class="row"><a class="small" href="#' + (JJ.S.user.role !== 'user' && t.userId !== JJ.S.user.id ? '/admin/tickets' : '/support') + '">Back</a></div><div class="card stack"><div class="row between"><div><h2>' + esc(t.subject) + '</h2><div class="small muted">#' + t.id + ' · ' + esc(t.category) + (t.orderId ? ' · order #' + t.orderId : '') + (t.userName ? ' · ' + esc(t.userName) + ' (' + esc(t.userEmail) + ')' : '') + '</div></div>' + JJ.pill(t.status) + '</div>' +
    '<div class="stack">' + r.messages.map(function (m) { return '<div class="card" style="' + (m.staff ? 'background:var(--soft)' : '') + '"><div class="row between small muted"><b>' + esc(m.name) + '</b><span>' + JJ.dt(m.at) + '</span></div><p class="pre" style="margin-top:6px">' + esc(m.body) + '</p></div>'; }).join('') + '</div>' +
    (t.status === 'closed' && !staff ? '<div class="alert info">This ticket is closed. <a href="#/support/new">Open a new one</a> if you still need help.</div>' :
      '<form class="form" data-form="reply" data-id="' + t.id + '">' + JJ.area('body', staff ? 'Reply to the user' : 'Add a message', { max: 4000 }) + '<div class="formerr"></div><div class="row"><button class="btn" type="submit">Send reply</button></div></form>') +
    (staff ? '<form class="row" data-form="ticketstatus" data-id="' + t.id + '" style="align-items:end">' + JJ.select('status', 'Status', ['open', 'pending', 'resolved', 'closed'], t.status) + '<button class="btn ghost" type="submit">Update status</button></form>' + (t.orderId ? '<p class="small"><a href="#/admin/orders">Open orders in admin</a> (order #' + t.orderId + ')</p>' : '') : '') + '</div>';
}, A);
JJ.forms.reply = async function (f, d) { await JJ.post('/api/tickets/' + f.dataset.id + '/reply', { body: d.body }); JJ.toast('Sent'); JJ.nav(); JJ.refreshSummary(); };
JJ.forms.ticketstatus = async function (f, d) { await JJ.post('/api/admin/tickets/' + f.dataset.id + '/status', { status: d.status }); JJ.toast('Status updated'); JJ.nav(); };

/* ---------- settings ---------- */
JJ.route('/settings', async function (_, q) {
  var u = JJ.S.user, tab = ['profile', 'payout', 'privacy', 'security', 'account'].indexOf(q.tab) > -1 ? q.tab : 'profile';
  var tabs = [['profile', 'Profile'], ['payout', 'Payout'], ['privacy', 'Privacy'], ['security', 'Security'], ['account', 'Account']];
  var body = '', mount = null;
  if (tab === 'profile') {
    body = '<form class="card form" data-form="profile">' + (q.welcome ? '<div class="alert good">You are in. Tell people a little about yourself.</div>' : '') +
      JJ.field('name', 'Full name', 'text', { value: u.name }) + JJ.field('headline', 'Headline', 'text', { value: u.headline, ph: 'Full-stack developer, or Runs a coffee roastery' }) + JJ.field('skills', 'Skills or what you hire for', 'text', { value: u.skills }) +
      JJ.area('bio', 'About you', { value: u.bio, max: 1500 }) + '<div class="two">' + JJ.field('country', 'Country', 'text', { value: u.country }) + JJ.field('phone', 'Phone', 'tel', { value: u.phone, hint: u.phone_verified ? 'Verified' : 'Not verified' }) + '</div>' +
      JJ.select('mode', 'I mainly use Jj Up to', [['client', 'Hire people'], ['freelancer', 'Find work']], u.mode) + '<div class="formerr"></div><button class="btn" type="submit">Save profile</button></form>';
  } else if (tab === 'payout') {
    body = '<form class="card form" data-form="payout"><h3>Where should we send your withdrawals?</h3>' + JJ.field('paypal_email', 'PayPal email', 'email', { value: u.paypal_email, hint: 'Money you earn is sent to this PayPal account. Use an account you control. We email you whenever this changes.' }) + '<div class="formerr"></div><button class="btn" type="submit">Save PayPal email</button></form>';
  } else if (tab === 'privacy') {
    var bl = (await JJ.get('/api/blocks')).blocked;
    body = '<form class="card form" data-form="privacy"><h3>Privacy</h3><label class="check"><input type="checkbox" name="profile_public"' + (u.profile_public ? ' checked' : '') + '><span><b>Public profile</b><br><span class="small muted">Off: others see only your first name and last initial, and no bio, skills, or country.</span></span></label>' +
      JJ.select('allow_messages', 'Who can message you', [['anyone', 'Anyone on Jj Up'], ['connections', 'Only people I work with or who sent me a proposal']], u.allow_messages) +
      '<label class="check"><input type="checkbox" name="notify_email"' + (u.notify_email ? ' checked' : '') + '><span><b>Email me about messages and proposals</b><br><span class="small muted">Payment, security, and support emails are always sent.</span></span></label><div class="formerr"></div><button class="btn" type="submit">Save privacy settings</button></form>' +
      '<div class="card stack"><h3>Blocked people</h3>' + (bl.length ? bl.map(function (b) { return '<div class="row between"><span>' + esc(b.name) + '</span><button class="btn ghost sm" data-act="block-user" data-id="' + b.id + '" data-block="0">Unblock</button></div>'; }).join('') : '<p class="muted small">You have not blocked anyone.</p>') + '</div>';
  } else if (tab === 'security') {
    var ss = (await JJ.get('/api/sessions')).sessions;
    body = '<form class="card form" data-form="password"><h3>Change password</h3>' + JJ.field('current', 'Current password', 'password', { auto: 'current-password' }) + JJ.field('password', 'New password', 'password', { auto: 'new-password', hint: 'At least 10 characters.' }) + '<div class="formerr"></div><button class="btn" type="submit">Change password</button><span class="hint">Other devices will be logged out.</span></form>' +
      '<div class="card stack"><h3>Two-step login</h3>' + (u.totp_on
        ? '<div class="alert good">On. You need a code from your authenticator app to log in.</div><form class="form" data-form="tfa-disable">' + JJ.field('password', 'Password', 'password') + JJ.field('code', 'Authenticator code', 'text', { attrs: 'inputmode="numeric" maxlength="6"' }) + '<div class="formerr"></div><button class="btn danger" type="submit">Turn off</button></form>'
        : '<p class="muted small">Add a second step with an authenticator app (Google Authenticator, Authy, 1Password). Strongly recommended for anyone who earns money here.</p><div id="tfa-box"><button class="btn ghost" data-act="tfa-setup">Set up two-step login</button></div>') + '</div>' +
      '<div class="card stack"><h3>Where you are logged in</h3>' + ss.map(function (s) { return '<div class="row between small"><span>' + esc((s.ua || 'Unknown device').slice(0, 70)) + ' · ' + JJ.ago(s.created_at) + '</span>' + (s.current ? '<span class="pill good">This device</span>' : '') + '</div>'; }).join('') + '<div><button class="btn ghost sm" data-act="logout-others">Log out other devices</button></div></div>';
  } else {
    body = '<form class="card form" data-form="delete"><h3>Delete my account</h3><p class="muted small">This removes your profile and closes your posts. You must have no open orders and no balance. Past orders stay on record for the people you worked with. This cannot be undone.</p>' + JJ.field('password', 'Confirm with your password', 'password') + '<div class="formerr"></div><button class="btn danger" type="submit">Delete my account</button></form>';
  }
  return '<h1 style="font-size:1.8rem">Settings</h1><div class="tabs">' + tabs.map(function (t) { return '<a href="#/settings?tab=' + t[0] + '"' + (t[0] === tab ? ' aria-current="page"' : '') + '>' + t[1] + '</a>'; }).join('') + '</div>' + body;
}, A);
async function saveMe(patch, msg) { var r = await JJ.post('/api/me', patch); JJ.S.user = r.user; JJ.header(); JJ.toast(msg); }
JJ.forms.profile = function (f, d) { return saveMe({ name: d.name, headline: d.headline, skills: d.skills, bio: d.bio, country: d.country, phone: d.phone, mode: d.mode }, 'Profile saved'); };
JJ.forms.payout = function (f, d) { return saveMe({ paypal_email: d.paypal_email }, 'PayPal email saved'); };
JJ.forms.privacy = function (f, d) { return saveMe({ profile_public: d.profile_public, allow_messages: d.allow_messages, notify_email: d.notify_email }, 'Privacy settings saved'); };
JJ.forms.password = async function (f, d) { await JJ.post('/api/auth/password', { current: d.current, password: d.password }); f.reset(); JJ.toast('Password changed'); };
JJ.acts['logout-others'] = async function () { await JJ.post('/api/sessions/logout-others'); JJ.toast('Other devices logged out'); JJ.nav(); };
JJ.acts['tfa-setup'] = async function () {
  var r = await JJ.post('/api/2fa/setup');
  document.getElementById('tfa-box').innerHTML = '<div class="stack"><p class="small">In your authenticator app choose "Enter a setup key" and type this key:</p><p class="card num" style="font-family:monospace;font-size:1.1rem;letter-spacing:.08em;overflow-wrap:anywhere">' + esc(r.secret) + '</p><form class="form" data-form="tfa-enable">' + JJ.field('code', 'Then enter the 6-digit code it shows', 'text', { attrs: 'inputmode="numeric" maxlength="6"' }) + '<div class="formerr"></div><button class="btn" type="submit">Turn on</button></form></div>';
};
JJ.forms['tfa-enable'] = async function (f, d) { await JJ.post('/api/2fa/enable', { code: d.code }); JJ.S.user.totp_on = true; JJ.toast('Two-step login is on'); JJ.nav(); };
JJ.forms['tfa-disable'] = async function (f, d) { await JJ.post('/api/2fa/disable', { password: d.password, code: d.code }); JJ.S.user.totp_on = false; JJ.toast('Two-step login is off'); JJ.nav(); };
JJ.forms.delete = async function (f, d) { await JJ.post('/api/me/delete', { password: d.password }); JJ.S.user = null; JJ.toast('Your account was deleted.'); JJ.go('/'); };
})();
