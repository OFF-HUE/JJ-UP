(function () {
'use strict';
var JJ = window.JJ;
(async function () {
  try {
    var r = await Promise.all([JJ.get('/api/config'), JJ.get('/api/me')]);
    JJ.S.config = r[0]; JJ.S.user = r[1].user;
  } catch (e) {
    document.getElementById('view').innerHTML = '<div class="empty"><h2>Jj Up is not reachable</h2><p>' + JJ.esc(e.message) + '</p><p><button class="btn" data-act="reload">Try again</button></p></div>';
    return;
  }
  if (JJ.S.config.maintenance) {
    var b = document.createElement('div'); b.className = 'alert warn'; b.style.cssText = 'margin:12px auto;max-width:1040px';
    b.textContent = 'Jj Up is in maintenance mode. You can browse, but changes are paused for a short while.';
    document.getElementById('header').after(b);
  }
  window.addEventListener('hashchange', JJ.nav);
  JJ.header();
  JJ.refreshSummary();
  setInterval(JJ.refreshSummary, 30000);
  JJ.nav();
})();
})();
