(function () {
'use strict';
var JJ = window.JJ, esc = JJ.esc, money = JJ.money, O = { auth: true, staff: true };

var TABS = [['overview', 'Overview', 0], ['users', 'Users', 0], ['posts', 'Posts', 0], ['orders', 'Orders', 0], ['withdrawals', 'Withdrawals', 1], ['tickets', 'Support', 0], ['reports', 'Reports', 0], ['emails', 'Email', 1], ['settings', 'Settings', 1], ['audit', 'Audit log', 1]];
function isAdmin() { return JJ.S.user.role === 'admin'; }
function shell(tab, inner) {
  return '<h1 style="font-size:1.8rem">Admin</h1><div class="tabs">' + TABS.filter(function (t) { return !t[2] || isAdmin(); }).map(function (t) { return '<a href="#/admin/' + t[0] + '"' + (t[0] === tab ? ' aria-current="page"' : '') + '>' + t[1] + '</a>'; }).join('') + '</div>' + inner;
}
function table(head, rows, empty) {
  if (!rows.length) return JJ.empty(empty || 'Nothing here.');
  return '<div class="card tw"><table><thead><tr>' + head.map(function (h) { return '<th>' + h + '</th>'; }).join('') + '</tr></thead><tbody>' + rows.join('') + '</tbody></table></div>';
}
var cell = function (v) { return '<td>' + v + '</td>'; };

var PAGES = {
  async overview() {
    var s = await JJ.get('/api/admin/stats');
    var warn = '';
    if (s.system.paypalMode === 'mock') warn += '<div class="alert warn"><b>PayPal is in test mode.</b> No real money moves. Set PAYPAL_MODE, PAYPAL_CLIENT_ID and PAYPAL_SECRET on the server to accept real payments.</div>';
    if (!s.system.smtp) warn += '<div class="alert warn"><b>Email is not set up.</b> Verification codes and notifications are not being delivered. Set the SMTP_* variables on the server.</div>';
    if (s.email.failed) warn += '<div class="alert bad">' + s.email.failed + ' email(s) failed to send. <a href="#/admin/emails">Check the Email tab</a>.</div>';
    var attn = [];
    if (s.money.pendingWithdrawals) attn.push('<a class="card" href="#/admin/withdrawals"><b>' + s.money.pendingWithdrawals + '</b> withdrawal(s) waiting · ' + money(s.money.pendingWithdrawalCents) + '</a>');
    if (s.support.disputes) attn.push('<a class="card" href="#/admin/orders?status=disputed"><b>' + s.support.disputes + '</b> order(s) in dispute</a>');
    if (s.support.openTickets) attn.push('<a class="card" href="#/admin/tickets"><b>' + s.support.openTickets + '</b> open support ticket(s)</a>');
    if (s.support.openReports) attn.push('<a class="card" href="#/admin/reports"><b>' + s.support.openReports + '</b> open report(s)</a>');
    function st(label, v, hl) { return '<div class="stat' + (hl ? ' hl' : '') + '"><span class="muted small">' + label + '</span><span class="v">' + v + '</span></div>'; }
    return shell('overview', warn + '<h2>Needs attention</h2>' + (attn.length ? '<div class="grid">' + attn.join('') + '</div>' : '<div class="alert good">Nothing is waiting for you.</div>') +
      '<h2>Money</h2><div class="stats">' + st('Platform fees earned', money(s.money.feesCents), 1) + st('Work completed', money(s.money.volumeCents)) + st('Held in escrow', money(s.money.escrowCents)) + st('Owed to freelancers', money(s.money.owedCents)) + '</div>' +
      '<h2>People and posts</h2><div class="stats">' + st('Active users', s.users.active) + st('New this week', s.users.newWeek) + st('Waiting to verify', s.users.pending) + st('Suspended', s.users.suspended) + st('Open jobs', s.posts.jobs) + st('Open services', s.posts.services) + '</div>' +
      '<h2>Orders</h2><div class="stats">' + ['awaiting_payment', 'in_escrow', 'delivered', 'released', 'disputed', 'refunded', 'cancelled'].map(function (k) { return st(k.replace('_', ' '), s.orders[k] || 0); }).join('') + '</div>');
  },
  async users(q) {
    var page = parseInt(q.page, 10) || 1, r = await JJ.get('/api/admin/users?page=' + page + '&q=' + encodeURIComponent(q.q || ''));
    var rows = r.users.map(function (u) {
      var me = u.id === JJ.S.user.id;
      var act = !isAdmin() || me ? '' : '<div class="row">' + (u.status === 'active' ? '<button class="btn danger sm" data-act="adm-user" data-id="' + u.id + '" data-set="suspended">Suspend</button>' : u.status === 'suspended' ? '<button class="btn ghost sm" data-act="adm-user" data-id="' + u.id + '" data-set="active">Reactivate</button>' : '') +
        '<select id="role-' + u.id + '" aria-label="Role"><option value="user"' + (u.role === 'user' ? ' selected' : '') + '>user</option><option value="support"' + (u.role === 'support' ? ' selected' : '') + '>support</option><option value="admin"' + (u.role === 'admin' ? ' selected' : '') + '>admin</option></select><button class="btn ghost sm" data-act="adm-role" data-id="' + u.id + '">Set role</button><button class="btn ghost sm" data-act="adm-logout" data-id="' + u.id + '">Log out</button></div>';
      return '<tr>' + cell(u.id) + cell('<a href="#/user/' + u.id + '">' + esc(u.name) + '</a>') + cell(esc(u.email) + (u.phone ? '<div class="small muted">' + esc(u.phone) + '</div>' : '')) + cell(esc(u.role)) + cell(JJ.pill(u.status) + (u.totp_on ? ' <span class="pill info">2FA</span>' : '')) + cell('<span class="num">' + money(u.balanceCents) + '</span>') + cell(JJ.date(u.created_at)) + cell(u.last_login ? JJ.ago(u.last_login) : 'never') + cell(act) + '</tr>';
    });
    return shell('users', '<form class="row" data-form="adm-search" data-tab="users" style="align-items:end"><div class="field" style="flex:1;min-width:200px"><label for="f-q">Search name, email or ID</label><input id="f-q" name="q" value="' + esc(q.q || '') + '"></div><button class="btn" type="submit">Search</button></form><p class="small muted">' + r.total + ' users</p>' +
      table(['ID', 'Name', 'Contact', 'Role', 'Status', 'Balance', 'Joined', 'Last login', ''], rows) + JJ.pager(page, r.pages, 'adm-page'));
  },
  async posts(q) {
    var r = await JJ.get('/api/admin/posts?q=' + encodeURIComponent(q.q || ''));
    return shell('posts', '<form class="row" data-form="adm-search" data-tab="posts" style="align-items:end"><div class="field" style="flex:1;min-width:200px"><label for="f-q">Search title</label><input id="f-q" name="q" value="' + esc(q.q || '') + '"></div><button class="btn" type="submit">Search</button></form>' +
      table(['ID', 'Type', 'Title', 'Author', 'Price', 'Status', ''], r.posts.map(function (p) {
        return '<tr>' + cell(p.id) + cell(p.kind) + cell('<a href="#/post/' + p.id + '">' + esc(p.title) + '</a>') + cell('<a href="#/user/' + p.author_id + '">' + esc(p.author) + '</a>') + cell(money(p.amount_cents)) + cell(JJ.pill(p.status)) +
          cell(p.status === 'removed' ? '<button class="btn ghost sm" data-act="adm-post" data-id="' + p.id + '" data-set="open">Restore</button>' : '<button class="btn danger sm" data-act="adm-post" data-id="' + p.id + '" data-set="removed">Remove</button>') + '</tr>';
      })));
  },
  async orders(q) {
    var r = await JJ.get('/api/admin/orders' + (q.status ? '?status=' + encodeURIComponent(q.status) : ''));
    var f = ['', 'disputed', 'in_escrow', 'delivered', 'awaiting_payment', 'released', 'refunded'];
    return shell('orders', '<div class="tabs">' + f.map(function (x) { return '<a href="#/admin/orders' + (x ? '?status=' + x : '') + '"' + ((q.status || '') === x ? ' aria-current="page"' : '') + '>' + (x ? x.replace('_', ' ') : 'All') + '</a>'; }).join('') + '</div>' +
      table(['#', 'Title', 'Client', 'Freelancer', 'Amount', 'Fee', 'Status', ''], r.orders.map(function (o) {
        var can = isAdmin() && ['in_escrow', 'delivered', 'disputed'].indexOf(o.status) > -1;
        return '<tr>' + cell(o.id) + cell(esc(o.title)) + cell('<a href="#/user/' + o.clientId + '">' + esc(o.client) + '</a>') + cell('<a href="#/user/' + o.freelancerId + '">' + esc(o.freelancer) + '</a>') + cell('<span class="num">' + money(o.amountCents) + '</span>') + cell('<span class="num">' + money(o.feeCents) + '</span>') + cell(JJ.pill(o.status)) +
          cell(can ? '<div class="row"><button class="btn sm" data-act="adm-resolve" data-id="' + o.id + '" data-do="release">Pay freelancer</button><button class="btn danger sm" data-act="adm-resolve" data-id="' + o.id + '" data-do="refund">Refund client</button></div>' : '') + '</tr>';
      })));
  },
  async withdrawals(q) {
    var r = await JJ.get('/api/admin/withdrawals' + (q.status ? '?status=' + encodeURIComponent(q.status) : ''));
    var f = ['', 'pending', 'processing', 'paid', 'rejected', 'failed'];
    return shell('withdrawals', '<div class="tabs">' + f.map(function (x) { return '<a href="#/admin/withdrawals' + (x ? '?status=' + x : '') + '"' + ((q.status || '') === x ? ' aria-current="page"' : '') + '>' + (x || 'All') + '</a>'; }).join('') + '</div>' +
      table(['#', 'User', 'PayPal', 'Amount', 'Requested', 'Status', ''], r.withdrawals.map(function (w) {
        return '<tr>' + cell(w.id) + cell('<a href="#/user/' + w.user_id + '">' + esc(w.name) + '</a>') + cell(esc(w.paypal_email)) + cell('<span class="num">' + money(w.amount_cents) + '</span>') + cell(JJ.dt(w.created_at)) + cell(JJ.pill(w.status) + (w.note ? '<div class="small muted">' + esc(w.note) + '</div>' : '')) +
          cell(w.status === 'pending' ? '<div class="row"><button class="btn sm" data-act="adm-wd-approve" data-id="' + w.id + '">Approve and send</button><form class="row" data-form="adm-wd-reject" data-id="' + w.id + '"><input class="input" name="reason" placeholder="Reason" style="width:140px" aria-label="Reason"><button class="btn danger sm" type="submit">Reject</button></form></div>' : '') + '</tr>';
      }), 'No withdrawals.'));
  },
  async tickets(q) {
    var r = await JJ.get('/api/admin/tickets' + (q.status ? '?status=' + encodeURIComponent(q.status) : ''));
    var f = ['', 'open', 'pending', 'resolved', 'closed'];
    return shell('tickets', '<div class="tabs">' + f.map(function (x) { return '<a href="#/admin/tickets' + (x ? '?status=' + x : '') + '"' + ((q.status || '') === x ? ' aria-current="page"' : '') + '>' + (x || 'All') + '</a>'; }).join('') + '</div>' +
      table(['#', 'Subject', 'From', 'Category', 'Status', 'Updated'], r.tickets.map(function (t) {
        return '<tr>' + cell(t.id) + cell('<a href="#/support/' + t.id + '">' + esc(t.subject) + '</a>') + cell(esc(t.name) + '<div class="small muted">' + esc(t.email) + '</div>') + cell(esc(t.category)) + cell(JJ.pill(t.status)) + cell(JJ.ago(t.updated_at)) + '</tr>';
      }), 'No tickets.'));
  },
  async reports() {
    var r = await JJ.get('/api/admin/reports');
    return shell('reports', table(['#', 'About', 'Reason', 'Reported by', 'Status', ''], r.reports.map(function (x) {
      var link = x.target_type === 'post' ? '#/post/' + x.target_id : '#/user/' + x.target_id;
      return '<tr>' + cell(x.id) + cell(x.target_type + ': <a href="' + link + '">' + esc(x.target_label || '#' + x.target_id) + '</a>') + '<td class="wrapcell">' + esc(x.reason) + '</td>' + cell(esc(x.reporter)) + cell(JJ.pill(x.status)) +
        cell(x.status === 'open' ? '<div class="row"><button class="btn ghost sm" data-act="adm-report" data-id="' + x.id + '" data-set="actioned">Mark actioned</button><button class="btn ghost sm" data-act="adm-report" data-id="' + x.id + '" data-set="dismissed">Dismiss</button></div>' : '') + '</tr>';
    }), 'No reports.'));
  },
  async emails(q) {
    var r = await JJ.get('/api/admin/emails' + (q.status ? '?status=' + encodeURIComponent(q.status) : ''));
    var f = ['', 'queued', 'failed', 'sent', 'logged'];
    return shell('emails', '<form class="card form" data-form="adm-announce"><h3>Email everyone</h3><p class="small muted">Sends to all verified, active users. Use for important news only.</p>' + JJ.field('subject', 'Subject', 'text') + JJ.area('body', 'Message', { max: 4000 }) + '<div class="formerr"></div><button class="btn" type="submit">Send to all users</button></form><div class="tabs">' +
      f.map(function (x) { return '<a href="#/admin/emails' + (x ? '?status=' + x : '') + '"' + ((q.status || '') === x ? ' aria-current="page"' : '') + '>' + (x || 'All') + '</a>'; }).join('') + '</div>' +
      table(['#', 'To', 'Subject', 'Status', 'Tries', 'When', ''], r.emails.map(function (m) {
        return '<tr>' + cell(m.id) + cell(esc(m.to_addr)) + '<td class="wrapcell">' + esc(m.subject) + (m.error ? '<div class="small" style="color:var(--bad)">' + esc(m.error) + '</div>' : '') + '</td>' + cell(JJ.pill(m.status)) + cell(m.attempts) + cell(JJ.ago(m.created_at)) + cell(m.status === 'failed' || m.status === 'logged' ? '<button class="btn ghost sm" data-act="adm-email-retry" data-id="' + m.id + '">Retry</button>' : '') + '</tr>';
      }), 'No emails.'));
  },
  async settings() {
    var s = (await JJ.get('/api/admin/settings')).settings;
    return shell('settings', '<form class="card form" data-form="adm-settings" style="max-width:560px"><h3>Platform settings</h3>' +
      JJ.field('fee_pct', 'Service fee (% taken from the freelancer when payment is released)', 'text', { value: s.fee_pct, attrs: 'inputmode="decimal"' }) + JJ.field('min_withdraw', 'Minimum withdrawal (USD)', 'text', { value: s.min_withdraw, attrs: 'inputmode="decimal"' }) + JJ.field('auto_release_days', 'Auto-release payment after delivery (days)', 'number', { value: s.auto_release_days, attrs: 'min="1" max="60"' }) +
      '<label class="check"><input type="checkbox" name="manual_withdrawals"' + (s.manual_withdrawals === '1' ? ' checked' : '') + '><span><b>Review withdrawals before sending</b><br><span class="small muted">Recommended. When off, withdrawals are sent to PayPal immediately.</span></span></label>' +
      '<label class="check"><input type="checkbox" name="signups_open"' + (s.signups_open === '1' ? ' checked' : '') + '><span><b>Allow new sign-ups</b></span></label>' +
      '<label class="check"><input type="checkbox" name="maintenance"' + (s.maintenance === '1' ? ' checked' : '') + '><span><b>Maintenance mode</b><br><span class="small muted">Users can browse but cannot make changes. Admins are not affected.</span></span></label><div class="formerr"></div><button class="btn" type="submit">Save settings</button></form>');
  },
  async audit(q) {
    var page = parseInt(q.page, 10) || 1, r = await JJ.get('/api/admin/audit?page=' + page);
    return shell('audit', table(['When', 'Who', 'Action', 'Target', 'Details', 'IP'], r.entries.map(function (e) {
      return '<tr>' + cell(JJ.dt(e.created_at)) + cell(esc(e.actor || 'system')) + cell(esc(e.action)) + cell(esc(e.target)) + '<td class="wrapcell">' + esc(e.detail) + '</td>' + cell(esc(e.ip)) + '</tr>';
    }), 'No entries.') + '<div class="pager"><button class="btn ghost sm" data-act="adm-page" data-page="' + (page - 1) + '"' + (page <= 1 ? ' disabled' : '') + '>Newer</button><button class="btn ghost sm" data-act="adm-page" data-page="' + (page + 1) + '"' + (r.entries.length < 50 ? ' disabled' : '') + '>Older</button></div>');
  },
};
function adminPage(tab, q) {
  var t = TABS.filter(function (x) { return x[0] === tab; })[0];
  if (!t || (t[2] && !isAdmin())) return shell('overview', '<div class="alert warn">You do not have access to that section.</div>');
  return PAGES[tab](q);
}
JJ.route('/admin', function (_, q) { return adminPage('overview', q); }, O);
JJ.route('/admin/:tab', function (p, q) { return adminPage(p.tab, q); }, O);

function adm(url, body, msg) { return JJ.post(url, body).then(function () { JJ.toast(msg || 'Done'); JJ.nav(); }); }
function admUrl(over) {
  var q = Object.assign({}, JJ.query(), over), p = new URLSearchParams();
  Object.keys(q).forEach(function (k) { if (q[k] && !(k === 'page' && q[k] == 1)) p.set(k, q[k]); });
  var s = p.toString(); return '/admin/' + JJ.here().split('/')[2] + (s ? '?' + s : '');
}
JJ.acts['adm-page'] = function (el) { JJ.go(admUrl({ page: el.dataset.page })); };
JJ.forms['adm-search'] = function (f, d) { JJ.go('/admin/' + f.dataset.tab + (d.q ? '?q=' + encodeURIComponent(d.q) : '')); };
JJ.acts['adm-user'] = function (el) {
  if (el.dataset.set === 'suspended' && !JJ.sure(el, 'Click again to suspend')) return;
  return adm('/api/admin/users/' + el.dataset.id, { status: el.dataset.set }, 'User updated');
};
JJ.acts['adm-role'] = function (el) {
  var role = document.getElementById('role-' + el.dataset.id).value;
  if (role === 'admin' && !JJ.sure(el, 'Make admin? Click again')) return;
  return adm('/api/admin/users/' + el.dataset.id, { role: role }, 'Role updated');
};
JJ.acts['adm-logout'] = function (el) { return adm('/api/admin/users/' + el.dataset.id + '/logout', {}, 'User logged out everywhere'); };
JJ.acts['adm-post'] = function (el) {
  if (el.dataset.set === 'removed' && !JJ.sure(el, 'Click again to remove')) return;
  return adm('/api/admin/posts/' + el.dataset.id, { status: el.dataset.set }, 'Post updated');
};
JJ.acts['adm-resolve'] = function (el) {
  var refund = el.dataset.do === 'refund';
  if (!JJ.sure(el, refund ? 'Refund client? Click again' : 'Pay freelancer? Click again')) return;
  return adm('/api/admin/orders/' + el.dataset.id + '/resolve', { action: el.dataset.do }, refund ? 'Client refunded' : 'Freelancer paid');
};
JJ.acts['adm-wd-approve'] = function (el) {
  if (!JJ.sure(el, 'Send money? Click again')) return;
  return JJ.post('/api/admin/withdrawals/' + el.dataset.id + '/approve').then(function (r) { JJ.toast(r.status === 'paid' ? 'Sent' : 'Sending (status: ' + r.status + ')'); JJ.nav(); });
};
JJ.forms['adm-wd-reject'] = function (f, d) { return adm('/api/admin/withdrawals/' + f.dataset.id + '/reject', { reason: d.reason }, 'Rejected. Money returned to the user.'); };
JJ.acts['adm-report'] = function (el) { return adm('/api/admin/reports/' + el.dataset.id, { status: el.dataset.set }, 'Report updated'); };
JJ.acts['adm-email-retry'] = function (el) { return adm('/api/admin/emails/' + el.dataset.id + '/retry', {}, 'Retrying'); };
JJ.forms['adm-announce'] = function (f, d) {
  return JJ.post('/api/admin/announce', { subject: d.subject, body: d.body }).then(function (r) { f.reset(); JJ.toast('Queued for ' + r.sent + ' people'); JJ.nav(); });
};
JJ.forms['adm-settings'] = function (f, d) {
  return JJ.post('/api/admin/settings', { fee_pct: d.fee_pct, min_withdraw: d.min_withdraw, auto_release_days: d.auto_release_days, manual_withdrawals: d.manual_withdrawals, signups_open: d.signups_open, maintenance: d.maintenance }).then(function () { JJ.toast('Settings saved'); return JJ.get('/api/config').then(function (c) { JJ.S.config = c; }); });
};
})();
