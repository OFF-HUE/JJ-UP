import { Router } from 'express';
import bcrypt from 'bcryptjs';
import { createHash, randomInt } from 'node:crypto';
import { z } from 'zod';
import { User } from '../models.js';
import { sendVerificationEmail } from '../email.js';
import { requireAuth } from '../middleware/auth.js';

const router = Router();
const CODE_TTL_MS = 10 * 60 * 1000;
const RESEND_WAIT_MS = 60 * 1000;
const MAX_CODE_ATTEMPTS = 5;

const signupSchema = z.object({
  name: z.string().trim().min(2).max(100),
  email: z.string().trim().email().max(254),
  phone: z.string().trim().max(30).optional().default(''),
  password: z.string().min(12).max(128),
  role: z.enum(['client', 'freelancer'])
});
const loginSchema = z.object({
  email: z.string().trim().email().max(254),
  password: z.string().min(1).max(128)
});
const verifySchema = z.object({
  email: z.string().trim().email().max(254),
  code: z.string().regex(/^\d{6}$/)
});

const hashCode = (email, code) =>
  createHash('sha256').update(`${email.toLowerCase()}:${code}:${process.env.SESSION_SECRET}`).digest('hex');

function publicUser(user) {
  return {
    id: user.id, name: user.name, email: user.email, phone: user.phone,
    role: user.role, headline: user.headline, skills: user.skills,
    emailVerified: Boolean(user.emailVerifiedAt)
  };
}
function makeCode() { return String(randomInt(100000, 1000000)); }

async function createAndSendCode(user) {
  const now = new Date();
  if (user.emailCodeLastSentAt && now - user.emailCodeLastSentAt < RESEND_WAIT_MS) {
    const error = new Error('Please wait before requesting another code.');
    error.status = 429;
    throw error;
  }
  const code = makeCode();
  user.emailCodeHash = hashCode(user.email, code);
  user.emailCodeExpiresAt = new Date(now.getTime() + CODE_TTL_MS);
  user.emailCodeAttempts = 0;
  user.emailCodeLastSentAt = now;
  await user.save();
  // Do not return or log the verification code to the browser/server console.
  await sendVerificationEmail(user.email, code);
}

router.post('/signup', async (req, res, next) => {
  try {
    const parsed = signupSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Please check your details. Passwords must be at least 12 characters.' });
    const { name, email, phone, password, role } = parsed.data;
    const normalizedEmail = email.toLowerCase();
    const existing = await User.findOne({ email: normalizedEmail });
    if (existing) {
      if (!existing.emailVerifiedAt) {
        try { await createAndSendCode(existing); }
        catch (e) { if (e.status === 429) return res.status(429).json({ error: e.message }); throw e; }
        return res.status(202).json({ message: 'A verification code has been sent to your email address.', requiresEmailVerification: true });
      }
      return res.status(409).json({ error: 'An account with this email already exists. Please log in.' });
    }
    const passwordHash = await bcrypt.hash(password, 12);
    const user = await User.create({ name, email: normalizedEmail, phone, passwordHash, role });
    try {
      await createAndSendCode(user);
    } catch (err) {
      await User.deleteOne({ _id: user._id });
      throw err;
    }
    res.status(201).json({ message: 'A verification code has been sent to your email address.', requiresEmailVerification: true });
  } catch (err) {
    if (err?.code === 11000) return res.status(409).json({ error: 'An account with this email already exists. Please log in.' });
    next(err);
  }
});

router.post('/verify-email', async (req, res, next) => {
  try {
    const parsed = verifySchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Enter the email address and six-digit code.' });
    const email = parsed.data.email.toLowerCase();
    const user = await User.findOne({ email }).select('+emailCodeHash +emailCodeExpiresAt +emailCodeAttempts');
    if (!user || user.emailVerifiedAt || !user.emailCodeHash) {
      return res.status(400).json({ error: 'This verification request is invalid or has expired. Please request a new code.' });
    }
    if (user.emailCodeExpiresAt < new Date()) {
      user.emailCodeHash = null; user.emailCodeExpiresAt = null; user.emailCodeAttempts = 0;
      await user.save();
      return res.status(400).json({ error: 'Your code has expired. Request a new code.' });
    }
    if (user.emailCodeAttempts >= MAX_CODE_ATTEMPTS) {
      return res.status(429).json({ error: 'Too many incorrect attempts. Request a new code.' });
    }
    user.emailCodeAttempts += 1;
    if (user.emailCodeHash !== hashCode(email, parsed.data.code)) {
      await user.save();
      return res.status(400).json({ error: 'That code is incorrect. Please try again.' });
    }
    user.emailVerifiedAt = new Date();
    user.emailCodeHash = null;
    user.emailCodeExpiresAt = null;
    user.emailCodeAttempts = 0;
    await user.save();

    req.session.regenerate((err) => {
      if (err) return next(err);
      req.session.userId = user.id;
      req.session.save((saveErr) => {
        if (saveErr) return next(saveErr);
        res.json({ user: publicUser(user), message: 'Email verified successfully.' });
      });
    });
  } catch (err) { next(err); }
});

router.post('/resend-code', async (req, res, next) => {
  try {
    const parsed = z.object({ email: z.string().trim().email().max(254) }).safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Enter a valid email address.' });
    const user = await User.findOne({ email: parsed.data.email.toLowerCase() }).select('+emailCodeLastSentAt');
    // Avoid disclosing whether an address has an account.
    if (!user || user.emailVerifiedAt) return res.json({ message: 'If the account needs verification, a code will be sent.' });
    try { await createAndSendCode(user); }
    catch (err) { if (err.status === 429) return res.status(429).json({ error: err.message }); throw err; }
    res.json({ message: 'A new verification code has been sent.' });
  } catch (err) { next(err); }
});

router.post('/login', async (req, res, next) => {
  try {
    const parsed = loginSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: 'Email or password is incorrect.' });
    const user = await User.findOne({ email: parsed.data.email.toLowerCase() }).select('+passwordHash');
    const valid = user && await bcrypt.compare(parsed.data.password, user.passwordHash);
    if (!valid) return res.status(401).json({ error: 'Email or password is incorrect.' });
    if (!user.emailVerifiedAt) return res.status(403).json({ error: 'Please verify your email before logging in.' });

    req.session.regenerate((err) => {
      if (err) return next(err);
      req.session.userId = user.id;
      req.session.save((saveErr) => {
        if (saveErr) return next(saveErr);
        res.json({ user: publicUser(user) });
      });
    });
  } catch (err) { next(err); }
});

router.get('/me', requireAuth, async (req, res, next) => {
  try {
    const user = await User.findById(req.session.userId);
    if (!user) {
      req.session.destroy(() => {});
      return res.status(401).json({ error: 'Session expired. Please log in again.' });
    }
    res.json({ user: publicUser(user) });
  } catch (err) { next(err); }
});

router.post('/logout', requireAuth, (req, res, next) => {
  req.session.destroy((err) => {
    if (err) return next(err);
    res.clearCookie('jjup.sid', {
      httpOnly: true, secure: process.env.NODE_ENV === 'production',
      sameSite: 'lax', path: '/'
    });
    res.status(204).end();
  });
});

export default router;
