# Jj Up — backend-connected signup, login, and email verification

## What is connected
- The `frontend/Jj Up.html` signup form calls `POST /api/auth/signup`.
- A six-digit code is sent through the backend's configured SMTP provider; the code is not shown in the page.
- Email verification calls `POST /api/auth/verify-email`.
- Login calls `POST /api/auth/login`.
- Refreshing the page checks `GET /api/auth/me`; logout calls `POST /api/auth/logout`.
- The backend stores user records in MongoDB and hashes passwords with bcrypt.

**Important scope note:** only signup/login/email verification and the authenticated session are connected to the backend. Marketplace posts, proposals, messages, profile edits, orders, and payments in this existing HTML are still prototype/localStorage features. Do not use this as a production marketplace yet.

## Requirements
- Node.js 20 or newer
- A MongoDB Atlas cluster (or local MongoDB)
- SMTP credentials from an email provider
- VS Code Live Server (or another local static server)

## Step 1 — Configure MongoDB and email
1. Open `backend/.env.example` and copy it to a new file named `backend/.env`.
2. Put your MongoDB connection string in `MONGODB_URI`.
3. Set `SESSION_SECRET` to a long random secret (at least 32 characters).
4. Fill in `SMTP_HOST`, `SMTP_PORT`, `SMTP_SECURE`, `SMTP_USER`, `SMTP_PASS`, and `EMAIL_FROM` with credentials from your SMTP/email provider. Do not put your normal email password here unless your provider specifically supports it; use an app password or SMTP API credentials where required.
5. Keep `.env` private. Never upload it to GitHub or send it to anyone.

## Step 2 — Start the backend on Windows
Open a terminal in VS Code and run:

```powershell
cd backend
npm install
npm run dev
```

When the database connects, the terminal should say `Jj Up API listening on port 4000`.

Open `http://localhost:4000/api/health` in your browser. Expected response:

```json
{"ok":true,"service":"jj-up-api"}
```

## Step 3 — Start the frontend
Open `frontend/Jj Up.html` with VS Code Live Server. Use this exact origin for the current configuration:

`http://localhost:5500`

If Live Server opens `http://127.0.0.1:5500` or uses another port, change `FRONTEND_ORIGIN` in `backend/.env` to match the browser address exactly, then restart the backend.

## Step 4 — Test the flow
1. Create an account with an email address you can access and a password of at least 12 characters.
2. Choose Freelancer or Client.
3. Check the email inbox and spam folder for the code.
4. Enter the six-digit code in Jj Up.
5. Log out, then log back in with the same email and password.
6. Refresh the page to check that the server session is restored.

If no email arrives, check the backend terminal for SMTP errors and verify the SMTP settings. The email service has not been live-tested with your provider yet.

## Security and production notes
The backend includes password hashing, hashed verification codes, expiry and attempt limits, rate limiting, HTTP-only session cookies, input validation, and security headers. Before public deployment, use HTTPS, review CSRF/CORS and cookie settings for the chosen domain, configure email deliverability and backups, add password reset and monitoring, and conduct a security review. Do not implement real payments until a payment provider and signed webhook verification are added.
